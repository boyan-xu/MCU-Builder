#include "board.h"
#include "main.h"
#include "oled.h"

App game;
volatile uint32_t board_loops;
volatile uint8_t board_raw_keys;
static Buttons buttons;
static Screen screen;
static uint8_t pending;
static uint32_t last_poll;

void board_begin(void) {
    HAL_Delay(100);
    buttons_init(&buttons);
    app_init(&game, HAL_GetTick());
    scores_load(game.records);
    app_refresh_best(&game);
    last_poll = HAL_GetTick() - 1;
    screen.valid = false;
    oled_begin(HAL_GetTick());
}

void board_poll(void) {
    uint32_t now = HAL_GetTick();
    board_loops++;
    if (now != last_poll) {
        last_poll = now;
        board_raw_keys = (uint8_t)((~GPIOB->IDR >> 10) & 31U);
        app_input(&game, buttons_update(&buttons, board_raw_keys, now), now);
        app_tick(&game, now);
        if (game.dirty) {
            screen_update(&screen, &game);
            game.dirty = false;
            pending |= screen.dirty_pages;
        }
    }
    bool was_online = oled_online;
    oled_service(now);
    if (!was_online && oled_online) pending = 0xFF;
    scores_service(game.records, &game.scores_dirty, !oled_busy(), now);
    if (pending && oled_submit_pages(screen.frame, pending, now)) pending = 0;
}
