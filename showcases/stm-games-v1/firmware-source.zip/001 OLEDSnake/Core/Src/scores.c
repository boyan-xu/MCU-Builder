#include "scores.h"
#include <string.h>

enum { RECORD_WORDS = 18, RECORD_BYTES = 36, RECORDS_PER_PAGE = 28 };
static uint32_t latest_address, sequence, retry_at;
static bool found, retrying;
static uint8_t next_slot;

static uint16_t crc(const uint16_t *words) {
    uint16_t result = 0xFFFF;
    for (unsigned i = 0; i < 32; i++) {
        result ^= ((words[i / 2] >> ((i % 2) * 8)) & 255U) << 8;
        for (unsigned bit = 0; bit < 8; bit++)
            result = (result << 1) ^ ((result & 0x8000U) ? 0x1021U : 0U);
    }
    return result;
}

static bool read_record(uint32_t address, uint16_t record[RECORD_WORDS]) {
    for (unsigned i = 0; i < RECORD_WORDS; i++) record[i] = scores_flash_read(address + i * 2);
    if (record[0] != 0x534E || record[1] != 1 || record[17] != 0xA55A || record[16] != crc(record))
        return false;
    for (unsigned i = 4; i < 16; i++)
        if (record[i] > 17890U || record[i] % 10U) return false;
    return true;
}

static void scan(uint16_t *values) {
    uint16_t record[RECORD_WORDS];
    uint8_t used[2] = {0};
    found = false; sequence = 0; latest_address = SCORE_FLASH_BASE;
    for (unsigned page = 0; page < 2; page++)
        for (unsigned slot = 0; slot < RECORDS_PER_PAGE; slot++) {
            uint32_t address = SCORE_FLASH_BASE + page * SCORE_PAGE_BYTES + slot * RECORD_BYTES;
            bool valid = read_record(address, record);
            for (unsigned i = 0; i < RECORD_WORDS; i++)
                if (record[i] != 0xFFFF) used[page] = slot + 1;
            if (!valid) continue;
            uint32_t candidate = record[2] | ((uint32_t)record[3] << 16);
            if (found && (int32_t)(candidate - sequence) <= 0) continue;
            found = true; sequence = candidate; latest_address = address;
            if (values) memcpy(values, record + 4, SCORE_COUNT * sizeof(*values));
        }
    next_slot = used[(latest_address - SCORE_FLASH_BASE) / SCORE_PAGE_BYTES];
}

void scores_load(uint16_t values[SCORE_COUNT]) {
    memset(values, 0, SCORE_COUNT * sizeof(*values));
    retrying = false;
    scan(values);
}

bool scores_save(const uint16_t values[SCORE_COUNT]) {
    uint16_t record[RECORD_WORDS];
    for (unsigned i = 0; i < SCORE_COUNT; i++)
        if (values[i] > 17890U || values[i] % 10U) return false;
    if (found) {
        bool same = true;
        for (unsigned i = 0; i < SCORE_COUNT; i++) {
            uint16_t old = scores_flash_read(latest_address + 8 + i * 2);
            if (values[i] < old) return false;
            same &= values[i] == old;
        }
        if (same) return true;
    }
    uint32_t page = latest_address & ~(SCORE_PAGE_BYTES - 1UL);
    unsigned next = next_slot;
    if (next == RECORDS_PER_PAGE) {
        page = page == SCORE_FLASH_BASE ? SCORE_FLASH_BASE + SCORE_PAGE_BYTES : SCORE_FLASH_BASE;
        if (!scores_flash_erase(page)) return false;
        next = 0;
    }
    uint32_t address = page + next * RECORD_BYTES;
    uint32_t next_sequence = sequence + 1;
    record[0] = 0x534E; record[1] = 1;
    record[2] = next_sequence; record[3] = next_sequence >> 16;
    memcpy(record + 4, values, SCORE_COUNT * sizeof(*values));
    record[16] = crc(record); record[17] = 0xA55A;
    /* Commit is written last; the previous page stays intact. 最后提交，保留旧页。 */
    for (unsigned i = 0; i < RECORD_WORDS; i++)
        if (!scores_flash_program(address + i * 2, record[i]) ||
            scores_flash_read(address + i * 2) != record[i]) {
            scan(0);
            return false;
        }
    sequence = next_sequence; latest_address = address; found = true;
    next_slot = next + 1;
    return true;
}

void scores_service(const uint16_t values[SCORE_COUNT], bool *dirty, bool idle, uint32_t now) {
    if (!*dirty || !idle || (retrying && (uint32_t)(now - retry_at) < 1000U)) return;
    if (scores_save(values)) { *dirty = false; retrying = false; }
    else { retrying = true; retry_at = now; }
}
