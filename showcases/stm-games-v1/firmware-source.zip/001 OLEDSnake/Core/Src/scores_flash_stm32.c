#include "scores.h"
#include "main.h"

static bool valid_address(uint32_t address) {
    return address >= SCORE_FLASH_BASE && address < SCORE_FLASH_END && !(address & 1U);
}

uint16_t scores_flash_read(uint32_t address) {
    return valid_address(address) ? *(volatile const uint16_t *)address : 0xFFFF;
}

bool scores_flash_program(uint32_t address, uint16_t value) {
    if (!valid_address(address) || scores_flash_read(address) != 0xFFFF || HAL_FLASH_Unlock() != HAL_OK)
        return false;
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
    bool ok = HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address, value) == HAL_OK;
    HAL_FLASH_Lock();
    return ok && scores_flash_read(address) == value;
}

bool scores_flash_erase(uint32_t address) {
    if ((address != SCORE_FLASH_BASE && address != SCORE_FLASH_BASE + SCORE_PAGE_BYTES) ||
        HAL_FLASH_Unlock() != HAL_OK) return false;
    FLASH_EraseInitTypeDef erase = {0};
    erase.TypeErase = FLASH_TYPEERASE_PAGES; erase.PageAddress = address; erase.NbPages = 1;
    uint32_t error;
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_PGERR | FLASH_FLAG_WRPERR);
    bool ok = HAL_FLASHEx_Erase(&erase, &error) == HAL_OK;
    HAL_FLASH_Lock();
    return ok;
}
