#include "buttons.h"
#include <string.h>
void buttons_init(Buttons *b) { memset(b, 0, sizeof(*b)); }
uint8_t buttons_update(Buttons *b, uint8_t pressed, uint32_t now) {
    uint8_t events = 0;
    pressed &= 31U;
    for (uint8_t i = 0; i < 5; i++) {
        uint8_t bit = 1U << i;
        if ((pressed ^ b->raw) & bit) {
            b->raw ^= bit;
            b->changed[i] = now;
        }
        if (((b->raw ^ b->stable) & bit) && (uint32_t)(now - b->changed[i]) >= 20) {
            b->stable ^= bit;
            if (b->stable & bit) events |= bit;
        }
    }
    return events;
}
