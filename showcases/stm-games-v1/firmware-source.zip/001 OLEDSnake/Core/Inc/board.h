#ifndef BOARD_H
#define BOARD_H
#include "app.h"
extern App game;
extern volatile uint32_t board_loops;
extern volatile uint8_t board_raw_keys;
void board_begin(void);
void board_poll(void);
#endif
