#ifndef SCORES_H
#define SCORES_H
#include <stdbool.h>
#include <stdint.h>
#define SCORE_COUNT 12U
#define SCORE_FLASH_BASE 0x0800F800UL
#define SCORE_FLASH_END  0x08010000UL
#define SCORE_PAGE_BYTES 1024U
void scores_load(uint16_t values[SCORE_COUNT]);
bool scores_save(const uint16_t values[SCORE_COUNT]);
void scores_service(const uint16_t values[SCORE_COUNT], bool *dirty, bool idle, uint32_t now);
uint16_t scores_flash_read(uint32_t address);
bool scores_flash_program(uint32_t address, uint16_t value);
bool scores_flash_erase(uint32_t address);
#endif
