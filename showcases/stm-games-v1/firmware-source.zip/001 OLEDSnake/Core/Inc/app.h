#ifndef APP_H
#define APP_H
#include "snake.h"
#include "buttons.h"
#include "scores.h"
typedef enum { APP_MENU, APP_PLAY, APP_PAUSE, APP_END, APP_MAP, APP_RECORDS } AppState;
typedef struct {
    Snake snake;
    AppState state;
    uint16_t best;
    uint16_t records[SCORE_COUNT];
    bool scores_dirty;
    uint8_t width_index, speed_index, selection;
    uint8_t map_index;
    uint32_t last_move;
    bool dirty;
} App;
extern const uint8_t app_widths[3];
extern const uint16_t app_speeds[5];
void app_init(App *a, uint32_t seed);
void app_refresh_best(App *a);
void app_input(App *a, uint8_t keys, uint32_t now);
void app_tick(App *a, uint32_t now);
#endif
