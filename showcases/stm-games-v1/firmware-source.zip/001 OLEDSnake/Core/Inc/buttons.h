#ifndef BUTTONS_H
#define BUTTONS_H
#include <stdint.h>
#define KEY_UP 1U
#define KEY_DOWN 2U
#define KEY_LEFT 4U
#define KEY_RIGHT 8U
#define KEY_OK 16U
typedef struct {
    uint8_t raw, stable;
    uint32_t changed[5];
} Buttons;
void buttons_init(Buttons *b);
uint8_t buttons_update(Buttons *b, uint8_t pressed, uint32_t now);
#endif
