#ifndef SCREEN_H
#define SCREEN_H
#include "app.h"
#define SCREEN_BYTES 1024
typedef struct {
    uint8_t frame[SCREEN_BYTES];
    AppState state;
    uint32_t revision;
    uint16_t score, best;
    uint8_t width, speed, map;
    uint8_t dirty_pages;
    SnakeCell food;
    bool valid;
} Screen;
void screen_render(const App *a, uint8_t frame[SCREEN_BYTES]);
void screen_update(Screen *screen, const App *a);
#endif
