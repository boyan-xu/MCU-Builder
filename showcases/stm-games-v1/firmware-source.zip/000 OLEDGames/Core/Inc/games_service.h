#ifndef GAMES_SERVICE_H
#define GAMES_SERVICE_H
#include <stdbool.h>
#include <stdint.h>
void games_service(uint32_t now,bool idle);
#endif
