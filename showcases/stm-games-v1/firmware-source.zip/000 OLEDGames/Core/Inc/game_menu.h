#ifndef GAME_MENU_H
#define GAME_MENU_H
#include "game.h"
void game_text(uint8_t *frame,GameOrientation orientation,unsigned x,unsigned y,const char *label);
void game_clear(uint8_t *frame,GameOrientation orientation,unsigned x,unsigned y,unsigned width,unsigned height);
void game_box(uint8_t *frame,GameOrientation orientation,int x,int y,int width,int height,bool solid);
void game_number3(uint8_t *frame,GameOrientation orientation,int x,int y,uint32_t value);
extern const uint8_t game_digits3[10][5];
char *game_decimal(char *out,uint32_t value);
int game_page_text(uint8_t *frame,int x,int page,const char *text);
#endif
