#ifndef DISPLAY_H
#define DISPLAY_H
#include <stdint.h>
#define SCREEN_BYTES 1024
uint8_t *display_frame(void);
#endif
