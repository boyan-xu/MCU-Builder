#ifndef SCORE_JOURNAL_H
#define SCORE_JOURNAL_H
#include <stdbool.h>
#include <stdint.h>
typedef struct {
    uint32_t base,commit,max_score;
} ScoreJournal;
uint32_t score_journal_load(const ScoreJournal *journal);
bool score_journal_save(const ScoreJournal *journal,uint32_t score);
#endif
