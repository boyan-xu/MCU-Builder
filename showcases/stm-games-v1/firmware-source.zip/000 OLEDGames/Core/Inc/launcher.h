#ifndef LAUNCHER_H
#define LAUNCHER_H
#include <stdbool.h>
#include "game.h"
typedef struct {
    const Game *const *games;
    size_t count, selection, first;
    int active;
    bool waiting_release, dirty;
} Launcher;
void launcher_init(Launcher *l, const Game *const *games, size_t count, uint32_t seed);
void launcher_update(Launcher *l, uint8_t pressed, uint8_t held, uint32_t now);
const uint8_t *launcher_draw(Launcher *l);
#endif
