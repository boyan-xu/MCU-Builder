#ifndef GAME_H
#define GAME_H
#include <stddef.h>
#include <stdbool.h>
#include <stdint.h>
#include "display.h"
typedef enum { GAME_LANDSCAPE, GAME_PORTRAIT } GameOrientation;
typedef enum { GAME_STAY, GAME_EXIT, GAME_PAGE_CHANGED } GameResult;
typedef struct {
    const char *name;
    GameOrientation orientation;
    void (*init)(uint32_t seed);
    void (*enter)(uint32_t now);
    GameResult (*update)(uint8_t pressed, uint8_t held, uint32_t now);
    const uint8_t *(*draw)(void);
    void (*service)(uint32_t now, bool idle);
} Game;
extern const Game *const game_registry[];
extern const size_t game_count;
#endif
