#ifndef OLED_H
#define OLED_H
#include <stdbool.h>
#include <stdint.h>
#include "display.h"
extern volatile uint32_t oled_frames, oled_errors;
extern volatile bool oled_online;
void oled_begin(uint32_t now);
void oled_service(uint32_t now);
bool oled_busy(void);
bool oled_submit(const uint8_t frame[SCREEN_BYTES], uint32_t now);
#endif
