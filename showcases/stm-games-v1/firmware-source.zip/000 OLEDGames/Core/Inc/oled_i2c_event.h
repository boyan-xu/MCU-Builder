#ifndef OLED_I2C_EVENT_H
#define OLED_I2C_EVENT_H
#include "stm32f1xx_hal.h"
/* OLED uses only 7-bit, non-DMA HAL master-transmit transactions. */
void oled_i2c_event_irq(I2C_HandleTypeDef *bus);
#endif
