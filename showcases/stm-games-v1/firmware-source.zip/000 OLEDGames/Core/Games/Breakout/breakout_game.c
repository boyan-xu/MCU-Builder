#include "breakout_game.h"
#include "breakout_highscore.h"
#include "buttons.h"
#include "game_menu.h"
#include "display.h"
#include <string.h>
BreakoutApp breakout_game_state;
static void remember(BreakoutApp *a) {
    if(a->b.mode==BO_ENDLESS && a->b.broken>a->best)a->best=a->b.broken;
}
static void request_save(BreakoutApp *a) { remember(a);if(a->best>a->saved)a->save_pending=true; }
static GameResult page(BreakoutApp *a,uint32_t now) {
    a->gate=a->dirty=a->force=true;a->last_tick=now;return GAME_PAGE_CHANGED;
}
static void init(uint32_t seed) {
    BreakoutApp *a=&breakout_game_state;memset(a,0,sizeof *a);
    a->seed=seed ? seed : 1;a->best=a->saved=breakout_highscore_load();
}
static void enter(uint32_t now) {
    BreakoutApp *a=&breakout_game_state;a->ui=BO_UI_TITLE;a->selection=0;a->now=now;page(a,now);
}
static void start(BreakoutApp *a,BreakoutMode mode,uint32_t now) {
    request_save(a);breakout_start(&a->b,mode,++a->seed+now);
    a->ui=BO_UI_GAME;a->selection=0;
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    BreakoutApp *a=&breakout_game_state;a->now=now;
    if(a->gate) {
        a->last_tick=now;if(!pressed && !held)a->gate=false;
        return GAME_STAY;
    }
    remember(a);
    if(a->ui!=BO_UI_GAME) {
        unsigned count=a->ui==BO_UI_RESULT ? 2 : 3;
        uint8_t direction=pressed&(KEY_UP|KEY_DOWN);
        if(direction==KEY_UP || direction==KEY_DOWN) {
            a->selection=(a->selection+count+(direction==KEY_UP ? -1 : 1))%count;
            a->dirty=a->force=true;
        }
        if(!(pressed&KEY_OK))return GAME_STAY;
        if(a->selection==count-1){request_save(a);return GAME_EXIT;}
        if(a->ui==BO_UI_TITLE)start(a,a->selection ? BO_ENDLESS : BO_STAGES,now);
        else if(a->ui==BO_UI_PAUSE && a->selection==0)a->ui=BO_UI_GAME;
        else start(a,a->b.mode,now);
        a->selection=0;return page(a,now);
    }
    if(pressed&KEY_OK) {
        request_save(a);a->ui=BO_UI_PAUSE;a->selection=0;return page(a,now);
    }
    BreakoutState before=a->b.state;
    if(pressed&KEY_UP){breakout_launch(&a->b);a->dirty=a->force=true;}
    uint32_t elapsed=now-a->last_tick;
    if(elapsed>100){a->last_tick=now-100;elapsed=100;}
    while(elapsed>=20 && (a->b.state==BO_PLAY || a->b.state==BO_READY)) {
        int32_t oldx=a->b.paddle_x;
        breakout_step(&a->b,held,20);a->last_tick+=20;elapsed-=20;
        if(a->b.state==BO_PLAY || oldx!=a->b.paddle_x)a->dirty=true;
        if(a->b.state!=before)break;
    }
    remember(a);
    if(a->b.state==BO_WON || a->b.state==BO_OVER) {
        request_save(a);a->ui=BO_UI_RESULT;a->selection=0;return page(a,now);
    }
    if(before==BO_PLAY && a->b.state==BO_READY)return page(a,now);
    return GAME_STAY;
}
static void pixel(unsigned x,unsigned y) {
    if(x<64 && y<128)display_frame()[((63-x)/8)*128+y]|=(uint8_t)(1U<<((63-x)%8));
}
static void box(int x,int y,int w,int h,bool solid) { game_box(display_frame(),GAME_PORTRAIT,x,y,w,h,solid); }
static void text(unsigned x,unsigned y,const char *s) { game_text(display_frame(),GAME_PORTRAIT,x,y,s); }
static void number(unsigned x,unsigned y,uint32_t value) { game_number3(display_frame(),GAME_PORTRAIT,x,y,value); }
static void menu_line(unsigned y,unsigned i,const char *label,const BreakoutApp *a) {
    text(0,y,a->selection==i ? ">" : " ");text(7,y,label);
}
static const uint8_t *draw(void) {
    BreakoutApp *a=&breakout_game_state;
    if(!a->dirty)return NULL;
    if(!a->force && a->now-a->last_draw<40)return NULL;
    uint8_t *frame=display_frame();
    memset(frame,0,SCREEN_BYTES);
    if(a->ui==BO_UI_TITLE) {
        text(8,10,"BREAKOUT");text(0,31,"BEST");number(0,43,a->best);
        menu_line(66,0,"STAGES",a);menu_line(82,1,"ENDLESS",a);menu_line(98,2,"EXIT",a);
    } else if(a->ui==BO_UI_GAME) {
        Breakout *b=&a->b;
        text(0,0,"N");number(6,1,b->broken);text(48,0,"L");number(55,1,b->lives);
        text(0,8,b->mode==BO_ENDLESS ? "B" : "S");number(6,9,b->mode==BO_ENDLESS ? a->best : b->stage);
        for(unsigned r=0;r<BO_ROWS;r++)for(unsigned c=0;c<BO_COLS;c++)if(b->bricks[r][c]) {
            int x=1+9*c,y=BO_TOP+8*r+b->scroll;box(x,y,8,5,false);
            if(b->bricks[r][c]==2){pixel(x+3,y+2);pixel(x+4,y+2);}
        }
        for(unsigned x=0;x<64;x+=4)pixel(x,BO_DANGER_Y);
        box(b->paddle_x/BO_UNIT,BO_PADDLE_Y,b->paddle_width,3,true);
        for(unsigned i=0;i<3;i++)if(b->balls[i].active)box(b->balls[i].x/BO_UNIT,b->balls[i].y/BO_UNIT,2,2,true);
        for(unsigned i=0;i<2;i++)if(b->drops[i].type) {
            int x=b->drops[i].x/BO_UNIT,y=b->drops[i].y/BO_UNIT;
            if(b->drops[i].type==BO_WIDE)box(x,y,5,3,false);
            else {pixel(x+1,y);pixel(x,y+1);pixel(x+2,y+1);pixel(x+1,y+2);}
        }
        if(b->state==BO_READY)text(5,103,"UP LAUNCH");
    } else if(a->ui==BO_UI_PAUSE) {
        text(14,10,"PAUSE");text(0,30,"BROKEN");number(0,42,a->b.broken);
        menu_line(64,0,"CONTINUE",a);menu_line(80,1,"NEW GAME",a);menu_line(96,2,"EXIT",a);
    } else {
        text(a->b.state==BO_WON ? 11 : 5,12,a->b.state==BO_WON ? "YOU WIN" : "GAME OVER");
        text(0,32,"BROKEN");number(0,44,a->b.broken);text(0,56,"BEST");number(0,68,a->best);
        menu_line(86,0,"RETRY",a);menu_line(102,1,"EXIT",a);
    }
    if(a->save_error)text(2,120,"SAVE ERROR");
    a->last_draw=a->now;a->dirty=a->force=false;return frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;BreakoutApp *a=&breakout_game_state;
    if(!idle || !a->save_pending)return;
    a->save_pending=false;bool okay=breakout_highscore_save(a->best);
    if(okay)a->saved=a->best;
    a->save_error=!okay;a->dirty=a->force=true;
}
const Game breakout_game={"BREAKOUT",GAME_PORTRAIT,init,enter,update,draw,service};
