#include "breakout_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={BREAKOUT_HIGHSCORE_BASE,BREAKOUT_HIGHSCORE_COMMIT,UINT32_MAX};
uint32_t breakout_highscore_load(void) {return score_journal_load(&journal);}
bool breakout_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
