#ifndef BREAKOUT_H
#define BREAKOUT_H
#include <stdbool.h>
#include <stdint.h>
#define BO_COLS 7
#define BO_ROWS 13
#define BO_TOP 16
#define BO_PADDLE_Y 120
#define BO_DANGER_Y 112
#define BO_UNIT 1000
typedef enum { BO_STAGES, BO_ENDLESS } BreakoutMode;
typedef enum { BO_READY, BO_PLAY, BO_WON, BO_OVER } BreakoutState;
typedef enum { BO_WIDE=1, BO_MULTI=2 } BreakoutItem;
typedef struct { int32_t x,y; int16_t vx,vy; bool active; } BreakoutBall;
typedef struct { int32_t x,y; uint8_t type; } BreakoutDrop;
typedef struct {
    uint8_t bricks[BO_ROWS][BO_COLS];
    BreakoutBall balls[3]; BreakoutDrop drops[2];
    BreakoutMode mode; BreakoutState state;
    uint32_t random,broken,descent_ms,wide_ms;
    int32_t paddle_x;
    uint8_t stage,lives,paddle_width,scroll;
} Breakout;
void breakout_start(Breakout *b,BreakoutMode mode,uint32_t seed);
void breakout_launch(Breakout *b);
void breakout_step(Breakout *b,uint8_t held,uint32_t ms);
unsigned breakout_bricks(const Breakout *b);
unsigned breakout_speed(const Breakout *b);
void breakout_hit(Breakout *b,unsigned row,unsigned col);
void breakout_collect(Breakout *b,BreakoutItem item);
#endif
