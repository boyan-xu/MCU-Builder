#ifndef BREAKOUT_HIGHSCORE_H
#define BREAKOUT_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define BREAKOUT_HIGHSCORE_BASE 0x0800D000U
#define BREAKOUT_HIGHSCORE_PAGE 1024U
#define BREAKOUT_HIGHSCORE_COMMIT 0xB4EAC0DEU
uint32_t breakout_highscore_load(void);
bool breakout_highscore_save(uint32_t score);
#endif
