#include "breakout.h"
#include "buttons.h"
#include <string.h>
static uint32_t random_next(Breakout *b) {
    uint32_t x=b->random; x^=x<<13; x^=x>>17; x^=x<<5;
    return b->random=x;
}
unsigned breakout_speed(const Breakout *b) {
    unsigned n=b->mode==BO_STAGES ? (b->stage-1U)*4U : (b->broken/50)*2;
    return 32+(n>16 ? 16 : n);
}
unsigned breakout_bricks(const Breakout *b) {
    unsigned n=0;
    for(unsigned r=0;r<BO_ROWS;r++)for(unsigned c=0;c<BO_COLS;c++)n+=b->bricks[r][c]!=0;
    return n;
}
static void random_row(Breakout *b,unsigned row) {
    unsigned count=0;
    for(unsigned c=0;c<BO_COLS;c++) {
        uint8_t v=0;
        if(random_next(b)%100<70) { v=random_next(b)%10==0 ? 2 : 1; count++; }
        b->bricks[row][c]=v;
    }
    if(!count)b->bricks[row][random_next(b)%BO_COLS]=1;
}
static void reset_ball(Breakout *b) {
    memset(b->balls,0,sizeof b->balls);memset(b->drops,0,sizeof b->drops);
    b->paddle_width=16;b->wide_ms=0;b->descent_ms=0;
    if(b->paddle_x>48*BO_UNIT)b->paddle_x=48*BO_UNIT;
    b->balls[0]=(BreakoutBall){b->paddle_x+7*BO_UNIT,118*BO_UNIT,0,0,true};
    b->state=BO_READY;
}
static void stage_layout(Breakout *b) {
    memset(b->bricks,0,sizeof b->bricks);b->scroll=0;
    for(unsigned r=0;r<8;r++)for(unsigned c=0;c<BO_COLS;c++) {
        bool set=false;
        switch(b->stage) {
        case 1:set=r<4;break;
        case 2:set=r<6 && ((r+c)%2==0);break;
        case 3:{ unsigned d=r>3 ? r-3 : 3-r; set=r<7 && c>=d && c<7-d;break; }
        case 4:set=(r+c)%2==0;break;
        default:set=true;break;
        }
        b->bricks[r][c]=set;
    }
}
void breakout_start(Breakout *b,BreakoutMode mode,uint32_t seed) {
    memset(b,0,sizeof *b);b->mode=mode;b->random=seed ? seed : 0xB4EA123U;
    b->stage=1;b->lives=3;b->paddle_x=24*BO_UNIT;
    if(mode==BO_ENDLESS)for(unsigned r=0;r<6;r++)random_row(b,r);
    else stage_layout(b);
    reset_ball(b);
}
void breakout_launch(Breakout *b) {
    if(b->state!=BO_READY)return;
    b->balls[0].vx=12;b->balls[0].vy=-(int)breakout_speed(b);b->state=BO_PLAY;
}
static void drop_item(Breakout *b,unsigned row,unsigned col) {
    if(random_next(b)%5)return;
    unsigned type=1+random_next(b)%2;
    for(unsigned i=0;i<2;i++)if(!b->drops[i].type) {
        b->drops[i]=(BreakoutDrop){(3+9*(int)col)*BO_UNIT,(BO_TOP+8*(int)row+b->scroll)*BO_UNIT,(uint8_t)type};
        return;
    }
}
static void remove_brick(Breakout *b,unsigned r,unsigned c,uint8_t *queue,unsigned *tail) {
    uint8_t v=b->bricks[r][c];if(!v)return;
    b->bricks[r][c]=0;if(b->broken!=UINT32_MAX)b->broken++;
    drop_item(b,r,c);
    if(v==2)queue[(*tail)++]=(uint8_t)(r*BO_COLS+c);
}
void breakout_hit(Breakout *b,unsigned row,unsigned col) {
    if(row>=BO_ROWS || col>=BO_COLS)return;
    uint8_t queue[BO_ROWS*BO_COLS];unsigned head=0,tail=0;
    remove_brick(b,row,col,queue,&tail);
    while(head<tail) {
        unsigned cell=queue[head++],r=cell/BO_COLS,c=cell%BO_COLS;
        if(random_next(b)&1U)for(unsigned x=0;x<BO_COLS;x++)remove_brick(b,r,x,queue,&tail);
        else for(unsigned y=0;y<BO_ROWS;y++)remove_brick(b,y,c,queue,&tail);
    }
}
void breakout_collect(Breakout *b,BreakoutItem item) {
    if(item==BO_WIDE) {
        b->paddle_width=24;b->wide_ms=15000;
        if(b->paddle_x>40*BO_UNIT)b->paddle_x=40*BO_UNIT;
    } else if(item==BO_MULTI) {
        BreakoutBall original={0};bool found=false;
        for(unsigned i=0;i<3;i++)if(b->balls[i].active){original=b->balls[i];found=true;break;}
        if(!found)return;
        for(unsigned i=0;i<3;i++)if(!b->balls[i].active) {
            b->balls[i]=original;b->balls[i].vx=(i&1 ? -1 : 1)*(int)(breakout_speed(b)*3/4);
            b->balls[i].vy=-(int)breakout_speed(b);
        }
    }
}
static void lose_life(Breakout *b) {
    if(b->lives)b->lives--;
    reset_ball(b);
    if(!b->lives){b->state=BO_OVER;b->balls[0].active=false;}
}
static bool overlap(int32_t x,int32_t y,int left,int top,int width,int height) {
    return x<(left+width)*BO_UNIT && x+2*BO_UNIT>left*BO_UNIT &&
           y<(top+height)*BO_UNIT && y+2*BO_UNIT>top*BO_UNIT;
}
static void move_ball(Breakout *b,BreakoutBall *ball,uint32_t ms) {
    int32_t dx=ball->vx*(int32_t)ms,dy=ball->vy*(int32_t)ms;
    unsigned ax=(unsigned)(dx<0 ? -dx : dx),ay=(unsigned)(dy<0 ? -dy : dy);
    unsigned steps=((ax>ay ? ax : ay)+BO_UNIT-1)/BO_UNIT;if(!steps)steps=1;
    for(unsigned s=0;s<steps && ball->active;s++) {
        int32_t oldx=ball->x,oldy=ball->y;
        ball->x+=ball->vx*(int32_t)ms/(int)steps;ball->y+=ball->vy*(int32_t)ms/(int)steps;
        if(ball->x<0){ball->x=-ball->x;ball->vx=-ball->vx;}
        if(ball->x>62*BO_UNIT){ball->x=124*BO_UNIT-ball->x;ball->vx=-ball->vx;}
        if(ball->y<BO_TOP*BO_UNIT){ball->y=2*BO_TOP*BO_UNIT-ball->y;ball->vy=-ball->vy;}
        if(ball->vy>0 && oldy+2*BO_UNIT<=BO_PADDLE_Y*BO_UNIT && ball->y+2*BO_UNIT>=BO_PADDLE_Y*BO_UNIT &&
           ball->x+2*BO_UNIT>b->paddle_x && ball->x<b->paddle_x+b->paddle_width*BO_UNIT) {
            int offset=(ball->x+BO_UNIT-b->paddle_x-b->paddle_width*BO_UNIT/2)/BO_UNIT;
            int vx=offset*(int)breakout_speed(b)*3/(2*b->paddle_width);
            if(vx>-6 && vx<6)vx=ball->vx<0 ? -6 : 6;
            ball->vx=vx;ball->vy=-(int)breakout_speed(b);ball->y=118*BO_UNIT;
        }
        bool hit=false;
        for(unsigned r=0;r<BO_ROWS && !hit;r++)for(unsigned c=0;c<BO_COLS;c++)if(b->bricks[r][c]) {
            int left=1+9*c,top=BO_TOP+8*r+b->scroll;
            if(!overlap(ball->x,ball->y,left,top,8,5))continue;
            if(oldx+2*BO_UNIT<=left*BO_UNIT || oldx>=(left+8)*BO_UNIT){ball->vx=-ball->vx;ball->x=oldx;}
            else {ball->vy=-ball->vy;ball->y=oldy;}
            breakout_hit(b,r,c);hit=true;break;
        }
        if(ball->y>=128*BO_UNIT)ball->active=false;
    }
}
void breakout_step(Breakout *b,uint8_t held,uint32_t ms) {
    if(b->state!=BO_PLAY && b->state!=BO_READY)return;
    /* Each call is one bounded simulation step; the adapter owns catch-up. */
    if(ms>20)ms=20;
    uint8_t direction=held&(KEY_LEFT|KEY_RIGHT);
    if(direction==KEY_LEFT)b->paddle_x-=80*(int32_t)ms;
    if(direction==KEY_RIGHT)b->paddle_x+=80*(int32_t)ms;
    if(b->paddle_x<0)b->paddle_x=0;
    int32_t right=(64-b->paddle_width)*BO_UNIT;
    if(b->paddle_x>right)b->paddle_x=right;
    if(b->state==BO_READY){b->balls[0].x=b->paddle_x+7*BO_UNIT;return;}
    if(b->wide_ms) {
        if(b->wide_ms<=ms){b->wide_ms=0;b->paddle_width=16;}
        else b->wide_ms-=ms;
    }
    for(unsigned i=0;i<3;i++)if(b->balls[i].active)move_ball(b,&b->balls[i],ms);
    if(!breakout_bricks(b)) {
        if(b->mode==BO_ENDLESS)random_row(b,0);
        else {
            if(b->stage==5){b->state=BO_WON;return;}
            b->stage++;stage_layout(b);reset_ball(b);return;
        }
    }
    if(b->mode==BO_ENDLESS) {
        unsigned increase=b->broken/50;unsigned interval=increase>=5 ? 500 : 1000-increase*100;
        b->descent_ms+=ms;
        if(b->descent_ms>=interval) {
            b->descent_ms-=interval;
            if(++b->scroll==8) {
                memmove(b->bricks[1],b->bricks[0],(BO_ROWS-1)*BO_COLS);
                b->scroll=0;random_row(b,0);
            }
        }
        int bottom=-1;
        for(unsigned r=0;r<BO_ROWS;r++)for(unsigned c=0;c<BO_COLS;c++)
            if(b->bricks[r][c] && BO_TOP+8*r+b->scroll+5>=BO_DANGER_Y)bottom=(int)r;
        if(bottom>=0) {
            unsigned first=bottom>=2 ? (unsigned)(bottom-2) : 0;
            for(unsigned r=first;r<BO_ROWS;r++)memset(b->bricks[r],0,BO_COLS);
            lose_life(b);return;
        }
    }
    unsigned alive=0;for(unsigned i=0;i<3;i++)alive+=b->balls[i].active;
    if(!alive){lose_life(b);return;}
    for(unsigned i=0;i<2;i++)if(b->drops[i].type) {
        BreakoutDrop *d=&b->drops[i];int32_t oldy=d->y;d->y+=24*(int32_t)ms;
        unsigned width=d->type==BO_WIDE ? 5 : 3;
        if(oldy<123*BO_UNIT && d->y+3*BO_UNIT>=BO_PADDLE_Y*BO_UNIT && d->x+(int32_t)width*BO_UNIT>b->paddle_x && d->x<b->paddle_x+b->paddle_width*BO_UNIT) {
            breakout_collect(b,(BreakoutItem)d->type);d->type=0;
        } else if(d->y>=128*BO_UNIT)d->type=0;
    }
}
