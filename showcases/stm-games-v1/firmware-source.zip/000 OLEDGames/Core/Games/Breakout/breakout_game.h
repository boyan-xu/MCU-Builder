#ifndef BREAKOUT_GAME_H
#define BREAKOUT_GAME_H
#include "game.h"
#include "breakout.h"
typedef enum { BO_UI_TITLE, BO_UI_GAME, BO_UI_PAUSE, BO_UI_RESULT } BreakoutUI;
typedef struct {
    Breakout b; BreakoutUI ui;
    uint32_t best,saved,seed,now,last_tick,last_draw;
    uint8_t selection;
    bool dirty,force,gate,save_pending,save_error;
} BreakoutApp;
extern BreakoutApp breakout_game_state;
extern const Game breakout_game;
#endif
