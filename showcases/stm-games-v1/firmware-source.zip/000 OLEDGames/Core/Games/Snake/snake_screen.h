#ifndef SNAKE_SCREEN_H
#define SNAKE_SCREEN_H
#include "snake_app.h"
#define SNAKE_SCREEN_BYTES 1024
typedef struct {
    uint8_t frame[SNAKE_SCREEN_BYTES];
    SnakeAppState state;
    uint32_t revision;
    uint16_t score, best;
    uint8_t width, speed, map;
    uint8_t dirty_pages;
    SnakeCell food;
    bool valid;
} SnakeScreen;
void snake_screen_render(const SnakeApp *a, uint8_t frame[SNAKE_SCREEN_BYTES]);
void snake_screen_update(SnakeScreen *screen, const SnakeApp *a);
#endif
