#ifndef SNAKE_APP_H
#define SNAKE_APP_H
#include "snake.h"
#include "buttons.h"
#include "snake_scores.h"
typedef enum { SNAKE_APP_MENU, SNAKE_APP_PLAY, SNAKE_APP_PAUSE, SNAKE_APP_END, SNAKE_APP_MAP, SNAKE_APP_RECORDS } SnakeAppState;
typedef struct {
    Snake snake;
    SnakeAppState state;
    uint16_t best;
    uint16_t records[SNAKE_SCORE_COUNT];
    bool scores_dirty;
    uint8_t width_index, speed_index, selection;
    uint8_t map_index;
    uint32_t last_move;
    bool dirty;
} SnakeApp;
extern const uint8_t snake_app_widths[3];
extern const uint16_t snake_app_speeds[5];
void snake_app_init(SnakeApp *a, uint32_t seed);
void snake_app_refresh_best(SnakeApp *a);
void snake_app_input(SnakeApp *a, uint8_t keys, uint32_t now);
void snake_app_tick(SnakeApp *a, uint32_t now);
#endif
