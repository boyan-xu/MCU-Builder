#include "snake_app.h"
#include <string.h>
const uint8_t snake_app_widths[3] = {2, 4, 8};
const uint16_t snake_app_speeds[5] = {400, 280, 200, 140, 90};

void snake_app_refresh_best(SnakeApp *a) {
    a->best = a->records[a->map_index * 3U + a->width_index];
    if (a->state == SNAKE_APP_MENU || a->state == SNAKE_APP_RECORDS)
        for (unsigned map = 0; map < SNAKE_MAP_COUNT; map++)
            if (a->records[map * 3U + a->width_index] > a->best)
                a->best = a->records[map * 3U + a->width_index];
}

static void new_game(SnakeApp *a, uint32_t now) {
    a->best = a->records[a->map_index * 3U + a->width_index];
    snake_init_map(&a->snake, snake_app_widths[a->width_index], a->map_index, a->snake.random ^ now);
    a->state = SNAKE_APP_PLAY;
    a->selection = 0;
    a->last_move = now;
    a->dirty = true;
}

void snake_app_init(SnakeApp *a, uint32_t seed) {
    memset(a, 0, sizeof(*a));
    a->width_index = 1;
    a->speed_index = 2;
    a->state = SNAKE_APP_MENU;
    a->dirty = true;
    snake_init(&a->snake, 4, seed);
}

void snake_app_input(SnakeApp *a, uint8_t keys, uint32_t now) {
    if (!keys) return;
    if (a->state == SNAKE_APP_RECORDS) {
        if (keys & KEY_OK) {
            a->state = SNAKE_APP_MENU;
            a->selection = 3;
            snake_app_refresh_best(a);
            a->dirty = true;
        }
        return;
    }
    if (a->state == SNAKE_APP_PLAY) {
        if (keys & KEY_OK) {
            a->state = SNAKE_APP_PAUSE;
            a->selection = 0;
            a->dirty = true;
        } else {
            switch (keys) {
            case KEY_UP: snake_turn(&a->snake, SNAKE_UP); break;
            case KEY_DOWN: snake_turn(&a->snake, SNAKE_DOWN); break;
            case KEY_LEFT: snake_turn(&a->snake, SNAKE_LEFT); break;
            case KEY_RIGHT: snake_turn(&a->snake, SNAKE_RIGHT); break;
            default: break;
            }
        }
        return;
    }
    if (a->state == SNAKE_APP_MAP) {
        uint8_t old = a->selection;
        if (keys & KEY_OK) {
            if (a->selection < SNAKE_MAP_COUNT) {
                a->map_index = a->selection;
                new_game(a, now);
            } else {
                a->state = SNAKE_APP_MENU;
                a->selection = 0;
                a->dirty = true;
            }
        } else if (keys == KEY_UP) {
            if (a->selection == SNAKE_MAP_COUNT) a->selection = a->map_index;
            else if (a->selection >= 2) a->selection -= 2;
        } else if (keys == KEY_DOWN) {
            if (a->selection < 2) a->selection += 2;
            else a->selection = SNAKE_MAP_COUNT;
        } else if (keys == KEY_LEFT && a->selection < SNAKE_MAP_COUNT) {
            a->selection &= (uint8_t)~1U;
        } else if (keys == KEY_RIGHT && a->selection < SNAKE_MAP_COUNT) {
            a->selection |= 1U;
        }
        if (a->state == SNAKE_APP_MAP && a->selection < SNAKE_MAP_COUNT) a->map_index = a->selection;
        snake_app_refresh_best(a);
        a->dirty |= old != a->selection;
        return;
    }
    SnakeAppState old_state = a->state;
    uint8_t old_selection = a->selection, old_speed = a->speed_index, old_width = a->width_index;
    const uint8_t count = a->state == SNAKE_APP_MENU || a->state == SNAKE_APP_PAUSE ? 4 : 2;
    if (keys & KEY_OK) {
        if (a->state == SNAKE_APP_MENU) {
            if (a->selection == 0) {
                a->state = SNAKE_APP_MAP;
                a->selection = a->map_index;
            } else if (a->selection == 3) {
                a->state = SNAKE_APP_RECORDS;
            }
        } else if (a->state == SNAKE_APP_PAUSE) {
            if (a->selection == 0) {
                a->state = SNAKE_APP_PLAY;
                a->last_move = now;
            } else if (a->selection == 2) {
                new_game(a, now);
            } else if (a->selection == 3) {
                a->state = SNAKE_APP_MENU;
                a->selection = 0;
            }
        } else if (a->selection == 0) {
            new_game(a, now);
        } else {
            a->state = SNAKE_APP_MENU;
            a->selection = 0;
        }
    } else if (keys == KEY_UP) {
        a->selection = (a->selection + count - 1) % count;
    } else if (keys == KEY_DOWN) {
        a->selection = (a->selection + 1) % count;
    } else if (keys == KEY_LEFT || keys == KEY_RIGHT) {
        uint8_t *value = 0;
        uint8_t maximum = 0;
        if (a->state != SNAKE_APP_END && a->selection == 1) {
            value = &a->speed_index;
            maximum = 4;
        } else if (a->state == SNAKE_APP_MENU && a->selection == 2) {
            value = &a->width_index;
            maximum = 2;
        }
        if (value) {
            if (keys == KEY_LEFT && *value > 0) (*value)--;
            if (keys == KEY_RIGHT && *value < maximum) (*value)++;
        }
    }
    snake_app_refresh_best(a);
    a->dirty |= a->state != old_state || a->selection != old_selection ||
                a->speed_index != old_speed || a->width_index != old_width;
}

void snake_app_tick(SnakeApp *a, uint32_t now) {
    if (a->state != SNAKE_APP_PLAY || (uint32_t)(now - a->last_move) < snake_app_speeds[a->speed_index])
        return;
    /* No catch-up burst after a slow screen transfer. 显示延迟后不连续补走。 */
    a->last_move = now;
    SnakeResult result = snake_step(&a->snake);
    uint16_t *best = &a->records[a->map_index * 3U + a->width_index];
    if (a->snake.score > *best) {
        *best = a->snake.score;
        a->scores_dirty = true;
    }
    a->best = *best;
    if (result == SNAKE_LOST || result == SNAKE_WON) {
        a->state = SNAKE_APP_END;
        a->selection = 0;
    }
    a->dirty = true;
}
