#include "snake_game.h"
#include "snake_screen.h"
#include "game_menu.h"
SnakeApp snake_game_state;
static SnakeScreen screen;
static void init(uint32_t seed) {
    snake_app_init(&snake_game_state,seed);
    snake_scores_load(snake_game_state.records);snake_app_refresh_best(&snake_game_state);
}
static void enter(uint32_t now) {
    snake_game_state.state=SNAKE_APP_MENU;snake_game_state.selection=0;
    snake_game_state.last_move=now;snake_game_state.dirty=true;
    snake_app_refresh_best(&snake_game_state);screen.valid=false;
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    (void)held;SnakeApp *a=&snake_game_state;SnakeAppState before=a->state;
    if(a->state==SNAKE_APP_MENU && (pressed==KEY_UP || pressed==KEY_DOWN)) {
        a->selection=pressed==KEY_UP ? (a->selection+4)%5 : (a->selection+1)%5;
        a->dirty=true;return GAME_STAY;
    }
    if(a->state==SNAKE_APP_MENU && a->selection==4) {
        if(pressed&KEY_OK)return GAME_EXIT;
        return GAME_STAY;
    }
    snake_app_input(a,pressed,now);snake_app_tick(a,now);
    return before!=a->state ? GAME_PAGE_CHANGED : GAME_STAY;
}
static const uint8_t *draw(void) {
    SnakeApp *a=&snake_game_state;if(!a->dirty)return NULL;
    snake_screen_update(&screen,a);
    if(a->state==SNAKE_APP_MENU) {
        game_clear(screen.frame,GAME_LANDSCAPE,0,48,128,8);
        game_text(screen.frame,GAME_LANDSCAPE,0,48,a->selection==4 ? "> EXIT" : "  EXIT");
    }
    a->dirty=false;return screen.frame;
}
static void service(uint32_t now,bool idle) {
    snake_scores_service(snake_game_state.records,&snake_game_state.scores_dirty,idle,now);
}
const Game snake_game={"SNAKE",GAME_LANDSCAPE,init,enter,update,draw,service};
