#include "snake.h"
#include <string.h>

static void occupy(Snake *s, SnakeCell c, bool value) {
    unsigned n = c.y * s->cols + c.x;
    uint8_t mask = 1U << (n % 8);
    if (value) s->occupied[n / 8] |= mask;
    else s->occupied[n / 8] &= (uint8_t)~mask;
}

bool snake_map_wall(uint8_t map, uint8_t cols, uint8_t rows, uint8_t x, uint8_t y) {
    if (map == SNAKE_MAP_BAR) return y == rows / 2;
    if (map == SNAKE_MAP_CROSS) return y == rows / 2 || x == cols / 2;
    if (map != SNAKE_MAP_LS) return false;
    unsigned lx = (cols * 2U + 2U) / 5U, ly = (rows * 2U + 2U) / 5U;
    bool lower = (x < lx && y == rows - ly) || (x == lx - 1 && y >= rows - ly);
    unsigned rx = cols - 1U - x, ry = rows - 1U - y;
    return lower || (rx < lx && ry == rows - ly) || (rx == lx - 1 && ry >= rows - ly);
}

bool snake_place_food(Snake *s) {
    const uint16_t total = s->cols * s->rows;
    if (s->length >= total - s->blocked_count) return false;
    s->random ^= s->random << 13;
    s->random ^= s->random >> 17;
    s->random ^= s->random << 5;
    uint16_t choice = s->random % (total - s->blocked_count - s->length);
    for (uint16_t cell = 0; cell < total; cell++) {
        if ((s->occupied[cell / 8] | s->walls[cell / 8]) & (1U << (cell % 8))) continue;
        if (choice-- == 0) {
            s->food = (SnakeCell){cell % s->cols, cell / s->cols};
            return true;
        }
    }
    return false;
}

void snake_init(Snake *s, uint8_t width, uint32_t seed) {
    snake_init_map(s, width, SNAKE_MAP_OPEN, seed);
}

void snake_init_map(Snake *s, uint8_t width, uint8_t map, uint32_t seed) {
    memset(s, 0, sizeof(*s));
    s->width = (width == 2 || width == 8) ? width : 4;
    s->cols = 128 / s->width;
    s->rows = 56 / s->width;
    s->map = map < SNAKE_MAP_COUNT ? map : SNAKE_MAP_OPEN;
    for (unsigned y = 0; y < s->rows; y++)
        for (unsigned x = 0; x < s->cols; x++)
            if (snake_map_wall(s->map, s->cols, s->rows, x, y)) {
                unsigned n = y * s->cols + x;
                s->walls[n / 8] |= 1U << (n % 8);
                s->blocked_count++;
            }
    s->length = 3;
    s->direction = SNAKE_RIGHT;
    s->random = seed ? seed : 0x12345678U;
    for (uint8_t i = 0; i < 3; i++) {
        snake_set_cell(s, i, (SnakeCell){s->cols / (s->map ? 4 : 2) - i, s->rows / (s->map ? 4 : 2)});
        occupy(s, snake_cell(s, i), true);
    }
    snake_place_food(s);
}

bool snake_turn(Snake *s, SnakeDirection direction) {
    if (s->over || s->turned || direction > SNAKE_RIGHT ||
        direction == s->direction || direction == (s->direction ^ 1))
        return false;
    s->direction = direction;
    s->turned = true;
    return true;
}

SnakeResult snake_step(Snake *s) {
    if (s->over) return s->won ? SNAKE_WON : SNAKE_LOST;
    SnakeCell head = snake_cell(s, 0);
    switch (s->direction) {
    case SNAKE_UP: head.y = head.y ? head.y - 1 : s->rows - 1; break;
    case SNAKE_DOWN: head.y = head.y + 1 == s->rows ? 0 : head.y + 1; break;
    case SNAKE_LEFT: head.x = head.x ? head.x - 1 : s->cols - 1; break;
    case SNAKE_RIGHT: head.x = head.x + 1 == s->cols ? 0 : head.x + 1; break;
    }
    bool eating = head.x == s->food.x && head.y == s->food.y;
    /* A moving tail leaves its cell unless food grows the snake. 尾格本次可离开。 */
    SnakeCell tail = snake_cell(s, s->length - 1);
    unsigned n = head.y * s->cols + head.x;
    if (snake_wall(s, head) || ((s->occupied[n / 8] & (1U << (n % 8))) &&
        (eating || head.x != tail.x || head.y != tail.y))) {
        s->over = true;
        return SNAKE_LOST;
    }
    if (eating) {
        s->length++;
        s->score += 10;
    }
    if (!eating) occupy(s, tail, false);
    s->head_index = s->head_index ? s->head_index - 1U : SNAKE_CAPACITY - 1U;
    s->body[s->head_index] = head;
    occupy(s, head, true);
    s->removed_tail = tail;
    s->grew = eating;
    s->revision++;
    s->turned = false;
    if (eating && !snake_place_food(s)) {
        s->won = s->over = true;
        return SNAKE_WON;
    }
    return eating ? SNAKE_ATE : SNAKE_MOVED;
}
