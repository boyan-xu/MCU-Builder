#ifndef SNAKE_H
#define SNAKE_H
#include <stdbool.h>
#include <stdint.h>

#define SNAKE_CAPACITY (64U * 28U)
typedef enum { SNAKE_UP, SNAKE_DOWN, SNAKE_LEFT, SNAKE_RIGHT } SnakeDirection;
typedef enum { SNAKE_MOVED, SNAKE_ATE, SNAKE_LOST, SNAKE_WON } SnakeResult;
typedef struct { uint8_t x, y; } SnakeCell;
enum { SNAKE_MAP_OPEN, SNAKE_MAP_BAR, SNAKE_MAP_LS, SNAKE_MAP_CROSS, SNAKE_MAP_COUNT };
typedef struct {
    SnakeCell body[SNAKE_CAPACITY];
    uint16_t head_index;
    uint8_t occupied[(SNAKE_CAPACITY + 7) / 8];
    uint8_t walls[(SNAKE_CAPACITY + 7) / 8];
    uint16_t blocked_count;
    uint8_t map;
    uint32_t revision;
    SnakeCell removed_tail;
    bool grew;
    SnakeCell food;
    uint16_t length, score;
    uint8_t width, cols, rows;
    SnakeDirection direction;
    bool turned, over, won;
    uint32_t random;
} Snake;

static inline SnakeCell snake_cell(const Snake *s, uint16_t index) {
    index += s->head_index;
    if (index >= SNAKE_CAPACITY) index -= SNAKE_CAPACITY;
    return s->body[index];
}
static inline void snake_set_cell(Snake *s, uint16_t index, SnakeCell cell) {
    index += s->head_index;
    if (index >= SNAKE_CAPACITY) index -= SNAKE_CAPACITY;
    s->body[index] = cell;
}

void snake_init(Snake *s, uint8_t width, uint32_t seed);
void snake_init_map(Snake *s, uint8_t width, uint8_t map, uint32_t seed);
bool snake_map_wall(uint8_t map, uint8_t cols, uint8_t rows, uint8_t x, uint8_t y);
static inline bool snake_wall(const Snake *s, SnakeCell c) {
    unsigned n = c.y * s->cols + c.x;
    return (s->walls[n / 8] & (1U << (n % 8))) != 0;
}
bool snake_turn(Snake *s, SnakeDirection direction);
SnakeResult snake_step(Snake *s);
bool snake_place_food(Snake *s);
#endif
