#ifndef SNAKE_FONT5X7_H
#define SNAKE_FONT5X7_H
#include "font5x7.h"
static inline const uint8_t *oled_glyph(unsigned char c) {
    if(!((c>='0' && c<='9') || (c>='A' && c<='Z') || c==' ' || c=='!' || c=='/' || c==':' || c=='>'))c='?';
    return oled_font[c-32];
}
#endif
