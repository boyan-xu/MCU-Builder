#ifndef SNAKE_GAME_H
#define SNAKE_GAME_H
#include "game.h"
#include "snake_app.h"
extern SnakeApp snake_game_state;
extern const Game snake_game;
#endif
