#include "game_menu.h"
#include "snake_screen.h"
#include "snake_font5x7.h"
#include <string.h>

static uint8_t cell(uint8_t *frame, SnakeCell c, uint8_t width, bool hollow, bool erase) {
    unsigned x = c.x * width, y = 8U + c.y * width;
    if (x >= 128 || y >= 64) return 0;
    /* Widths 2/4/8 align every cell inside one OLED page. */
    uint8_t full = ((1U << width) - 1U) << (y % 8);
    uint8_t edge = (1U | (1U << (width - 1))) << (y % 8);
    uint8_t *out = frame + (y / 8) * 128 + x;
    for (unsigned col = 0; col < width; col++) {
        if (erase) out[col] &= (uint8_t)~full;
        else out[col] |= hollow && col && col != width - 1U ? edge : full;
    }
    return 1U << (y / 8);
}

static int text(uint8_t *frame, int x, int page, const char *s) { return game_page_text(frame,x,page,s); }

static int number(uint8_t *frame, int x, int page, uint16_t value) { char digits[6];game_decimal(digits,value);return text(frame,x,page,digits); }

static void number_right(uint8_t *frame, int right, int page, uint16_t value) {
    unsigned digits = 1;
    for (unsigned n = value; n >= 10; n /= 10) digits++;
    number(frame, right - (int)(digits * 6 - 2), page, value);
}

static const char *const map_names[] = {"OPEN", "BAR", "TWO L", "CROSS"};

static void records(uint8_t *frame, const SnakeApp *a) {
    text(frame, 0, 0, "RECORDS");
    text(frame, 0, 1, "MAP");
    text(frame, 44, 1, "2PX"); text(frame, 76, 1, "4PX"); text(frame, 108, 1, "8PX");
    for (unsigned map = 0; map < SNAKE_MAP_COUNT; map++) {
        text(frame, 0, map + 2, map_names[map]);
        for (unsigned width = 0; width < 3; width++)
            number_right(frame, 60 + width * 32, map + 2, a->records[map * 3 + width]);
    }
    text(frame, 0, 7, "OK BACK");
}

static void speed_row(uint8_t *frame, bool selected, uint8_t speed) {
    text(frame, 0, 3, selected ? ">" : " ");
    int x = text(frame, 12, 3, "SPEED: ");
    x = number(frame, x, 3, speed + 1);
    text(frame, x, 3, " / 5");
}

static void row(uint8_t *frame, int page, bool selected, const char *label) {
    text(frame, 0, page, selected ? ">" : " ");
    text(frame, 12, page, label);
}

static void point(uint8_t *frame, unsigned x, unsigned y) {
    if (x < 128 && y < 64) frame[(y / 8) * 128 + x] |= 1U << (y % 8);
}

static void map_selector(const SnakeApp *a, uint8_t *frame) {
    unsigned selected = a->selection < SNAKE_MAP_COUNT ? a->selection : a->map_index;
    int x = text(frame, 0, 0, "MAP ");
    x = number(frame, x, 0, selected + 1);
    x = text(frame, x, 0, ":");
    text(frame, x, 0, map_names[selected]);
    x = text(frame, 68, 0, "BEST:");
    number(frame, x, 0, a->records[selected * 3U + a->width_index]);
    for (unsigned map = 0; map < SNAKE_MAP_COUNT; map++) {
        unsigned bx = (map % 2) * 65, by = (map / 2) * 24 + 9;
        if (a->selection == map) {
            for (unsigned x = bx; x <= bx + 62; x++) { point(frame, x, by); point(frame, x, by + 22); }
            for (unsigned y = by; y <= by + 22; y++) { point(frame, bx, y); point(frame, bx + 62, y); }
        }
        number(frame, bx + 3, map < 2 ? 2 : 5, map + 1);
        unsigned px = bx + 15, py = by + 3;
        for (unsigned x = 0; x < 44; x++)
            for (unsigned y = 0; y < 18; y++)
                if (snake_map_wall(map, 44, 18, x, y)) point(frame, px + x, py + y);
        for (unsigned x = 0; x < 46; x += 3) { point(frame, px - 1 + x, py - 1); point(frame, px - 1 + x, py + 18); }
        for (unsigned y = 0; y < 20; y += 3) { point(frame, px - 1, py - 1 + y); point(frame, px + 44, py - 1 + y); }
    }
    row(frame, 7, a->selection == SNAKE_MAP_COUNT, "BACK");
    text(frame, 48, 7, "OK SELECT");
}

static void score_line(const SnakeApp *a, uint8_t *frame) {
    memset(frame, 0, 128);
    int x = text(frame, 0, 0, "S:");
    x = number(frame, x, 0, a->snake.score);
    x = text(frame, x, 0, " B:");
    x = number(frame, x, 0, a->best);
    x = text(frame, x, 0, " V:");
    number(frame, x, 0, a->speed_index + 1);
}

void snake_screen_update(SnakeScreen *screen, const SnakeApp *a) {
    const Snake *s = &a->snake;
    uint32_t moves = s->revision - screen->revision;
    screen->dirty_pages = 0;
    if (screen->valid && screen->state == SNAKE_APP_PLAY && a->state == SNAKE_APP_PLAY &&
        screen->width == s->width && screen->map == s->map && moves <= 1) {
        bool food_changed = screen->food.x != s->food.x || screen->food.y != s->food.y;
        if (moves && !s->grew) screen->dirty_pages |= cell(screen->frame, s->removed_tail, s->width, false, true);
        if (food_changed) screen->dirty_pages |= cell(screen->frame, screen->food, s->width, false, true);
        if (moves) screen->dirty_pages |= cell(screen->frame, snake_cell(s, 0), s->width, false, false);
        if (food_changed) screen->dirty_pages |= cell(screen->frame, s->food, s->width, true, false);
        if (screen->score != s->score || screen->best != a->best || screen->speed != a->speed_index) {
            score_line(a, screen->frame);
            screen->dirty_pages |= 1;
        }
    } else {
        /* SnakeScreen changes or skipped moves need a fresh local image, not a full OLED send. */
        snake_screen_render(a, screen->frame);
        screen->dirty_pages = 0xFF;
    }
    screen->valid = true;
    screen->state = a->state;
    screen->width = s->width;
    screen->map = s->map;
    screen->revision = s->revision;
    screen->food = s->food;
    screen->score = s->score;
    screen->best = a->best;
    screen->speed = a->speed_index;
}

void snake_screen_render(const SnakeApp *a, uint8_t frame[SNAKE_SCREEN_BYTES]) {
    memset(frame, 0, SNAKE_SCREEN_BYTES);
    if (a->state == SNAKE_APP_PLAY) {
        score_line(a, frame);
        const Snake *s = &a->snake;
        if (s->blocked_count)
            for (unsigned y = 0; y < s->rows; y++)
                for (unsigned x = 0; x < s->cols; x++)
                    if (snake_wall(s, (SnakeCell){x, y})) cell(frame, (SnakeCell){x, y}, s->width, false, false);
        for (uint16_t i = 0; i < s->length; i++)
            cell(frame, snake_cell(s, i), s->width, false, false);
        cell(frame, s->food, s->width, true, false);
    } else if (a->state == SNAKE_APP_RECORDS) {
        records(frame, a);
    } else if (a->state == SNAKE_APP_MAP) {
        map_selector(a, frame);
    } else if (a->state == SNAKE_APP_MENU) {
        number(frame, text(frame, 0, 0, "SNAKE  BEST:"), 0, a->best);
        row(frame, 2, a->selection == 0, "START");
        speed_row(frame, a->selection == 1, a->speed_index);
        row(frame, 4, a->selection == 2, "WIDTH: ");
        int x = number(frame, 54, 4, snake_app_widths[a->width_index]);
        text(frame, x, 4, " PX");
        row(frame, 5, a->selection == 3, "RECORDS");
        text(frame, 0, 6, "UP/DN SELECT L/R SET");
        text(frame, 0, 7, "OK SELECT EDGES WRAP");
    } else if (a->state == SNAKE_APP_PAUSE) {
        text(frame, 0, 0, "PAUSED");
        row(frame, 2, a->selection == 0, "RESUME");
        speed_row(frame, a->selection == 1, a->speed_index);
        row(frame, 4, a->selection == 2, "NEW GAME");
        row(frame, 5, a->selection == 3, "MAIN MENU");
        text(frame, 0, 7, "UP/DN L/R OK");
    } else {
        text(frame, 0, 0, a->snake.won ? "YOU WIN!" : "GAME OVER");
        number(frame, text(frame, 0, 2, "SCORE: "), 2, a->snake.score);
        number(frame, text(frame, 0, 3, "BEST:  "), 3, a->best);
        row(frame, 5, a->selection == 0, "PLAY AGAIN");
        row(frame, 6, a->selection == 1, "MAIN MENU");
    }
}
