#ifndef SNAKE_SCORES_H
#define SNAKE_SCORES_H
#include <stdbool.h>
#include <stdint.h>
#define SNAKE_SCORE_COUNT 12U
#define SNAKE_SCORE_FLASH_BASE 0x0800E800UL
#define SNAKE_SCORE_FLASH_END  0x0800F000UL
#define SNAKE_SCORE_PAGE_BYTES 1024U
void snake_scores_load(uint16_t values[SNAKE_SCORE_COUNT]);
bool snake_scores_save(const uint16_t values[SNAKE_SCORE_COUNT]);
void snake_scores_service(const uint16_t values[SNAKE_SCORE_COUNT], bool *dirty, bool idle, uint32_t now);
uint16_t snake_scores_flash_read(uint32_t address);
bool snake_scores_flash_program(uint32_t address, uint16_t value);
bool snake_scores_flash_erase(uint32_t address);
#endif
