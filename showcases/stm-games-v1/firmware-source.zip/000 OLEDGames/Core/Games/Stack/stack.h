#ifndef STACK_H
#define STACK_H
#include <stdbool.h>
#include <stdint.h>
#define STACK_ROWS 18
typedef struct { uint8_t x,w; } StackRow;
typedef struct {
    StackRow rows[STACK_ROWS];
    uint32_t score;
    int32_t x;
    int16_t cut_x,cut_y;
    uint16_t perfect_ms,milestone_ms,number_ms,cut_ms;
    uint8_t top,count,width,streak,cut_w;
    int8_t direction;
    bool over,grew;
} Stack;
void stack_start(Stack *s);
bool stack_drop(Stack *s);
void stack_step(Stack *s,uint32_t ms);
unsigned stack_speed(const Stack *s);
unsigned stack_top_y(const Stack *s);
const char *stack_word(const Stack *s);
#endif
