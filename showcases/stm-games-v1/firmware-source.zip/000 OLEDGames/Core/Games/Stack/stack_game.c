#include "stack_game.h"
#include "stack_highscore.h"
#include "buttons.h"
#include "game_menu.h"
#include <string.h>
StackApp stack_game_state;
_Static_assert(sizeof(StackApp)<=384,"Stack RAM budget");
static void request_save(StackApp *a) {if(a->best>a->saved)a->save_pending=true;}
static GameResult page(StackApp *a,uint32_t now) {
    a->gate=a->dirty=a->force=true;a->last_tick=now;return GAME_PAGE_CHANGED;
}
static void clear_effects(StackApp *a) {
    a->s.perfect_ms=a->s.number_ms=a->s.milestone_ms=a->s.cut_ms=a->best_ms=0;
}
static void init(uint32_t seed) {
    (void)seed;memset(&stack_game_state,0,sizeof stack_game_state);
    stack_game_state.best=stack_game_state.saved=stack_highscore_load();
}
static void enter(uint32_t now) {
    StackApp *a=&stack_game_state;a->ui=STACK_TITLE;a->selection=0;a->now=now;
    clear_effects(a);page(a,now);
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    StackApp *a=&stack_game_state;a->now=now;
    if(a->gate) {
        a->last_tick=now;
        if(!pressed && !held && !a->start_pending){a->gate=false;a->armed=true;}
        return GAME_STAY;
    }
    if(!pressed && !held)a->armed=true;
    if(a->ui!=STACK_PLAY) {
        unsigned count=a->ui==STACK_PAUSE ? 3 : 2;
        if(pressed&KEY_OK) {
            if(a->selection==count-1){request_save(a);clear_effects(a);return GAME_EXIT;}
            if(a->ui==STACK_PAUSE && !a->selection)a->ui=STACK_PLAY;
            else {request_save(a);stack_start(&a->s);a->best_ms=0;a->ui=STACK_PLAY;a->start_pending=a->save_pending;}
            a->selection=0;return page(a,now);
        }
        uint8_t direction=(pressed|held)&(KEY_UP|KEY_DOWN);
        if((pressed&(KEY_UP|KEY_DOWN)) && (direction==KEY_UP || direction==KEY_DOWN)) {
            a->selection=(a->selection+count+(direction==KEY_UP ? -1 : 1))%count;
            a->dirty=a->force=true;
        }
        a->last_tick=now;return GAME_STAY;
    }
    if(pressed&KEY_OK) {a->ui=STACK_PAUSE;a->selection=0;return page(a,now);}
    uint32_t elapsed=now-a->last_tick;
    if(elapsed>100){a->last_tick=now-100;elapsed=100;}
    while(elapsed>=20) {
        stack_step(&a->s,20);a->best_ms=a->best_ms>20 ? a->best_ms-20 : 0;
        a->last_tick+=20;elapsed-=20;a->dirty=true;
    }
    if(a->armed && (pressed&KEY_UP)) {
        a->armed=false;bool okay=stack_drop(&a->s);
        if(a->s.score>a->best) {a->best=a->s.score;a->best_ms=160;}
        a->dirty=a->force=true;
        if(!okay) {request_save(a);a->ui=STACK_RESULT;a->selection=0;return page(a,now);}
    }
    return GAME_STAY;
}
static void pixel(uint8_t *f,int x,int y) {
    if(x>=0 && x<64 && y>=0 && y<128)f[((63-x)/8)*128+y]|=(uint8_t)(1U<<((63-x)%8));
}
static void box(uint8_t *f,int x,int y,int w,int h,bool solid) { game_box(f,GAME_PORTRAIT,x,y,w,h,solid); }
static void text(uint8_t *f,int x,int y,const char *s) {game_text(f,GAME_PORTRAIT,x,y,s);}
static void center(uint8_t *f,int y,const char *s) {text(f,(64-(int)strlen(s)*6)/2,y,s);}
static void number(uint8_t *f,int x,int y,uint32_t value) { game_number3(f,GAME_PORTRAIT,x,y,value); }
static void menu(uint8_t *f,unsigned y,unsigned i,const char *s,const StackApp *a) {
    text(f,0,y,a->selection==i ? ">" : " ");text(f,7,y,s);
}
static const uint8_t *draw(void) {
    StackApp *a=&stack_game_state;
    if(!a->dirty || (!a->force && a->now-a->last_draw<40))return NULL;
    uint8_t *f=display_frame();memset(f,0,SCREEN_BYTES);
    if(a->ui==STACK_PLAY) {
        Stack *s=&a->s;int top=(int)stack_top_y(s);
        text(f,0,0,"N");number(f,8,1+(s->number_ms>80 ? 2 : s->number_ms ? 1 : 0),s->score);
        text(f,0,10,"B");number(f,8,11+(a->best_ms>80 ? 2 : a->best_ms ? 1 : 0),a->best);
        if(s->milestone_ms)center(f,23,stack_word(s));
        for(unsigned i=0;i<s->count;i++) {
            StackRow row=s->rows[(s->top+STACK_ROWS-i)%STACK_ROWS];
            box(f,row.x,top+6*(int)i,row.w,5,i==0 && s->perfect_ms && ((s->perfect_ms/60)&1));
        }
        box(f,(s->x+500)/1000,top-6,s->width,5,true);
        if(s->cut_ms)box(f,s->cut_x,s->cut_y,s->cut_w,5,false);
        if(s->perfect_ms) {
            StackRow row=s->rows[s->top];int d=2+(300-s->perfect_ms)/50;
            center(f,top-18,"PERFECT");if(s->grew)center(f,top-30,"+WIDTH");
            for(int side=-1;side<=1;side+=2) {
                int x=side<0 ? row.x-d : row.x+row.w-1+d;
                pixel(f,x,top+2);pixel(f,x,top-d/2);pixel(f,x-side,top+4+d/2);
            }
        }
    } else if(a->ui==STACK_TITLE) {
        center(f,12,"STACK");text(f,0,32,"BEST");number(f,0,44,a->best);
        menu(f,66,0,"PLAY",a);menu(f,82,1,"EXIT",a);center(f,106,"UP DROP");center(f,116,"OK PAUSE");
    } else if(a->ui==STACK_PAUSE) {
        center(f,12,"PAUSE");text(f,0,32,"SCORE");number(f,0,44,a->s.score);
        menu(f,66,0,"CONTINUE",a);menu(f,82,1,"NEW GAME",a);menu(f,98,2,"EXIT",a);
    } else {
        center(f,12,"GAME OVER");text(f,0,32,"SCORE");number(f,0,44,a->s.score);
        text(f,0,56,"BEST");number(f,0,68,a->best);menu(f,86,0,"RETRY",a);menu(f,102,1,"EXIT",a);
    }
    if(a->save_error)center(f,120,"SAVE ERROR");
    a->dirty=a->force=false;a->last_draw=a->now;return f;
}
static void service(uint32_t now,bool idle) {
    (void)now;StackApp *a=&stack_game_state;
    if(!idle || !a->save_pending || (a->ui==STACK_PLAY && !a->start_pending))return;
    a->save_pending=false;bool okay=stack_highscore_save(a->best);
    if(okay)a->saved=a->best;
    a->save_error=!okay;a->dirty=a->force=true;a->start_pending=false;
}
const Game stack_game={"STACK",GAME_PORTRAIT,init,enter,update,draw,service};
