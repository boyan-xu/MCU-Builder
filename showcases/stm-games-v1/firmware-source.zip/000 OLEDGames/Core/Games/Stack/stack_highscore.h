#ifndef STACK_HIGHSCORE_H
#define STACK_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define STACK_HIGHSCORE_BASE 0x0800C000U
#define STACK_HIGHSCORE_PAGE 1024U
#define STACK_HIGHSCORE_COMMIT 0x57AC10DEU
uint32_t stack_highscore_load(void);
bool stack_highscore_save(uint32_t score);
#endif
