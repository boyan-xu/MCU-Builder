#include "stack.h"
#include <string.h>
void stack_start(Stack *s) {
    memset(s,0,sizeof *s);s->rows[0]=(StackRow){8,48};
    s->width=48;s->count=1;s->direction=1;
}
unsigned stack_speed(const Stack *s) { return s->score>=80 ? 60 : 20+5*(s->score/10); }
unsigned stack_top_y(const Stack *s) { return s->score>=8 ? 68 : 116-6*s->score; }
const char *stack_word(const Stack *s) {
    static const char *const words[]={"GOOD","GREAT","SUPER","AWESOME","AMAZING"};
    return words[s->score>=10 ? (s->score/10-1)%5 : 0];
}
bool stack_drop(Stack *s) {
    if(s->over)return false;
    StackRow old=s->rows[s->top];int x=(s->x+500)/1000;
    int delta=x-old.x,left=x>old.x ? x : old.x;
    int right=x+s->width<old.x+old.w ? x+s->width : old.x+old.w;
    s->grew=false;s->perfect_ms=0;
    s->cut_ms=450;s->cut_y=(int16_t)stack_top_y(s)-6;
    s->cut_x=(int16_t)(delta<0 ? x : old.x+old.w);
    s->cut_w=(uint8_t)(delta<0 ? old.x-x : x+s->width-old.x-old.w);
    bool perfect=delta>=-1 && delta<=1;
    if(right<=left && !perfect) {s->over=true;s->cut_x=x;s->cut_w=s->width;return false;}
    unsigned width=(unsigned)(right-left);
    if(perfect) {
        left=old.x;width=old.w;s->cut_ms=0;s->perfect_ms=300;
        if(++s->streak==3) {
            s->streak=0;
            if(width<48) {
                unsigned bigger=width+2;if(bigger>48)bigger=48;
                left-=(int)(bigger-width)/2;width=bigger;
                if(left<0)left=0;
                if(left+(int)width>64)left=64-(int)width;
                s->grew=true;
            }
        }
    } else s->streak=0;
    if(s->score<UINT32_MAX)s->score++;
    if(s->score%10==0)s->milestone_ms=900;
    if(s->score>8)s->cut_y+=6;
    s->number_ms=160;s->top=(s->top+1)%STACK_ROWS;
    if(s->count<STACK_ROWS)s->count++;
    s->rows[s->top]=(StackRow){(uint8_t)left,(uint8_t)width};s->width=(uint8_t)width;
    s->direction=(s->score&1) ? -1 : 1;
    s->x=s->direction>0 ? 0 : (64-(int)width)*1000;
    return true;
}
static uint16_t remaining(uint16_t value,uint32_t ms) { return ms>=value ? 0 : (uint16_t)(value-ms); }
void stack_step(Stack *s,uint32_t ms) {
    s->perfect_ms=remaining(s->perfect_ms,ms);s->milestone_ms=remaining(s->milestone_ms,ms);
    s->number_ms=remaining(s->number_ms,ms);
    if(s->cut_ms) {s->cut_ms=remaining(s->cut_ms,ms);s->cut_y+=(int16_t)(ms>1000 ? 50 : ms/20);}
    if(s->over)return;
    int32_t limit=(64-s->width)*1000;
    int32_t x=s->x+s->direction*(int32_t)(stack_speed(s)*(ms>1000 ? 1000 : ms));
    while(x<0 || x>limit) {
        if(x<0) {x=-x;s->direction=1;}
        if(x>limit) {x=2*limit-x;s->direction=-1;}
    }
    s->x=x;
}
