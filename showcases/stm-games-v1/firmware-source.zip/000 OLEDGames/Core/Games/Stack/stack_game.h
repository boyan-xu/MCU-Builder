#ifndef STACK_GAME_H
#define STACK_GAME_H
#include "game.h"
#include "stack.h"
typedef enum { STACK_TITLE,STACK_PLAY,STACK_PAUSE,STACK_RESULT } StackUI;
typedef struct {
    Stack s;
    uint32_t best,saved,last_tick,now,last_draw;
    StackUI ui;
    uint16_t best_ms;
    uint8_t selection;
    bool gate,armed,dirty,force,save_pending,save_error,start_pending;
} StackApp;
extern StackApp stack_game_state;
extern const Game stack_game;
#endif
