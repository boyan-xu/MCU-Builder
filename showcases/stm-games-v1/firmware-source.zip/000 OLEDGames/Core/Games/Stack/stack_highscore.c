#include "stack_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={STACK_HIGHSCORE_BASE,STACK_HIGHSCORE_COMMIT,UINT32_MAX};
uint32_t stack_highscore_load(void) {return score_journal_load(&journal);}
bool stack_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
