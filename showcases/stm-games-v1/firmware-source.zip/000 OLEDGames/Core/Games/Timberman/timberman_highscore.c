#include "timberman_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={TM_HIGHSCORE_BASE,TM_HIGHSCORE_COMMIT,999999};
uint32_t timberman_highscore_load(void) {return score_journal_load(&journal);}
bool timberman_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
