#include "timberman_game.h"
#include "timberman_highscore.h"
#include "display.h"
#include "buttons.h"
#include "game_menu.h"
#include <string.h>
TimbermanApp timberman_game_state;
static GameResult page(TimbermanApp *a,TimbermanPage p) {
    a->page=p;a->selection=0;a->gate=a->dirty=true;
    return GAME_PAGE_CHANGED;
}
void timberman_app_init(TimbermanApp *a,uint32_t seed) {
    memset(a,0,sizeof *a);a->seed=seed;a->best=a->saved=timberman_highscore_load();
}
void timberman_app_enter(TimbermanApp *a,uint32_t now) {
    a->now=a->last_tick=now;page(a,TM_TITLE);
}
static GameResult over(TimbermanApp *a) {
    if(a->t.score>a->best)a->best=a->t.score;
    if(a->best>a->saved)a->save_pending=true;
    return page(a,TM_OVER);
}
GameResult timberman_app_update(TimbermanApp *a,uint8_t p,uint8_t h,uint32_t now) {
    uint32_t elapsed=now-a->last_tick;a->last_tick=a->now=now;
    if(a->gate) {
        if(!(p|h)){a->gate=false;a->armed=true;}
        return GAME_STAY;
    }
    if(a->page!=TM_PLAY) {
        unsigned count=a->page==TM_PAUSE?3:2;
        uint8_t dir=(p|h)&(KEY_UP|KEY_DOWN);
        if((p&dir) && (dir==KEY_UP || dir==KEY_DOWN)) {
            a->selection=(uint8_t)((a->selection+count+(dir==KEY_UP?-1:1))%count);
            a->gate=a->dirty=true;
        }
        if(!(p&KEY_OK))return GAME_STAY;
        if(a->selection==count-1)return GAME_EXIT;
        if(a->page!=TM_PAUSE || a->selection==1) {
            timberman_start(&a->t,++a->seed);a->animation=0;
        }
        return page(a,TM_PLAY);
    }
    timberman_tick(&a->t,elapsed);
    if(a->t.over)return over(a);
    if(p&KEY_OK)return page(a,TM_PAUSE);
    if(a->animation) {
        a->animation=elapsed>=a->animation?0:(uint16_t)(a->animation-elapsed);
        if(!a->animation)a->dirty=true;
    }
    uint8_t dir=(p|h)&(KEY_LEFT|KEY_RIGHT|KEY_UP|KEY_DOWN);
    if(!dir)a->armed=true;
    else if(p&dir) {
        bool allowed=a->armed && (dir==KEY_LEFT || dir==KEY_RIGHT);a->armed=false;
        if(allowed) {
            timberman_chop(&a->t,dir==KEY_LEFT?TM_LEFT:TM_RIGHT);
            a->animation=80;a->dirty=true;
            if(a->t.over)return over(a);
        }
    }
    if(a->t.started && now-a->last_draw>=50)a->dirty=true;
    return GAME_STAY;
}
void timberman_app_service(TimbermanApp *a,bool idle) {
    if(!idle || !a->save_pending || a->page==TM_PLAY || a->page==TM_PAUSE)return;
    a->save_pending=false;a->save_failed=!timberman_highscore_save(a->best);
    if(!a->save_failed)a->saved=a->best;
    a->dirty=true;
}
static void box(uint8_t *f,unsigned x,unsigned y,unsigned w,unsigned h) {
    /* Internal rectangles and the rule-bounded time bar all fit 64x128. */
    for(unsigned c=0;c<w;c++) {
        unsigned col=63-x-c;uint8_t *out=f+(col/8)*128+y,mask=(uint8_t)(1U<<(col%8));
        for(unsigned r=0;r<h;r++)out[r]|=mask;
    }
}
static void text(uint8_t *f,unsigned x,unsigned y,const char *s) {game_text(f,GAME_PORTRAIT,x,y,s);}
static __attribute__((noipa)) void choice(uint8_t *f,bool selected,unsigned y,const char *label) {
    if(selected)text(f,5,y,">");
    text(f,17,y,label);
}
static void number(uint8_t *f,unsigned x,unsigned y,uint32_t n) {game_number3(f,GAME_PORTRAIT,x,y,n);}
static void person(uint8_t *f,const TimbermanApp *a) {
    static const uint8_t parts[10][4]={
        {3,0,10,2},{5,2,6,6},{4,9,8,9},{4,18,2,7},{10,18,2,7},{11,11,6,2},
        {13,9,1,8},{12,9,5,1},{16,5,1,8},{15,4,4,4}
    };
    for(unsigned i=0;i<8;i++) {
        const uint8_t *p=parts[i<6?i:i+(a->animation?2:0)];
        unsigned x=a->t.side==TM_RIGHT?53-p[0]-p[2]:11+p[0];
        box(f,x,94+p[1],p[2],p[3]);
    }
}
void timberman_render(const TimbermanApp *a,uint8_t f[1024]) {
    memset(f,0,1024);
    if(a->page==TM_TITLE) {
        text(f,5,8,"TIMBERMAN");text(f,20,27,"BEST");number(f,14,39,a->best);
        choice(f,a->selection==0,68,"START");
        choice(f,a->selection==1,84,"EXIT");
        text(f,8,108,"L/R CHOP");text(f,8,119,"OK PAUSE");return;
    }
    text(f,2,3,"S");number(f,14,3,a->t.score);
    game_box(f,GAME_PORTRAIT,1,17,62,6,false);
    box(f,2,18,a->t.remaining*60/TM_TIME,4);
    for(unsigned i=0;i<TM_SEGMENTS;i++) {
        unsigned y=28+(TM_SEGMENTS-1-i)*11;
        box(f,27,y,10,11);game_clear(f,GAME_PORTRAIT,29+(i%3),y+2,2,5);
        if(a->t.branch[i]==TM_LEFT)box(f,12,y+5,15,3);
        if(a->t.branch[i]==TM_RIGHT)box(f,37,y+5,15,3);
    }
    person(f,a);box(f,0,119,64,1);
    if(a->animation && a->page==TM_PLAY){box(f,a->t.side==TM_LEFT?3:57,110,3,2);box(f,7,114,1,1);}
    if(a->page==TM_PLAY && !a->t.started)text(f,5,121,"L/R START");
    if(a->page==TM_PAUSE || a->page==TM_OVER) {
        game_clear(f,GAME_PORTRAIT,1,27,62,89);
        box(f,1,27,62,1);box(f,1,115,62,1);
        text(f,a->page==TM_PAUSE?17:5,32,a->page==TM_PAUSE?"PAUSE":"GAME OVER");
        if(a->page==TM_OVER) {
            text(f,5,45,a->t.timeout?"TIME UP":"BRANCH!");text(f,20,55,"BEST");number(f,14,65,a->best);
        }
        if(a->page==TM_PAUSE) {
            choice(f,a->selection==0,54,"CONTINUE");
            choice(f,a->selection==1,72,"NEW GAME");
            choice(f,a->selection==2,90,"EXIT");
        } else {
            choice(f,a->selection==0,83,"RETRY");
            choice(f,a->selection==1,100,"EXIT");
        }
    }
    if(a->save_failed)text(f,2,118,"SAVE ERROR");
}
static void init(uint32_t seed) {timberman_app_init(&timberman_game_state,seed);}
static void enter(uint32_t now) {timberman_app_enter(&timberman_game_state,now);}
static GameResult update(uint8_t p,uint8_t h,uint32_t now) {return timberman_app_update(&timberman_game_state,p,h,now);}
static const uint8_t *draw(void) {
    TimbermanApp *a=&timberman_game_state;
    if(!a->dirty)return NULL;
    uint8_t *f=display_frame();timberman_render(a,f);
    a->last_draw=a->now;a->dirty=false;return f;
}
static void service(uint32_t now,bool idle) {(void)now;timberman_app_service(&timberman_game_state,idle);}
const Game timberman_game={"TIMBERMAN",GAME_PORTRAIT,init,enter,update,draw,service};
