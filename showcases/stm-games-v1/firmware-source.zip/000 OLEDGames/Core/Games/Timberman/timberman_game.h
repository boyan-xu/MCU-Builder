#ifndef TIMBERMAN_GAME_H
#define TIMBERMAN_GAME_H
#include "timberman.h"
#include "game.h"
typedef enum {TM_TITLE,TM_PLAY,TM_PAUSE,TM_OVER} TimbermanPage;
typedef struct {
    TimbermanState t;
    uint32_t best,saved,seed,now,last_tick,last_draw;
    uint16_t animation;
    uint8_t selection;
    TimbermanPage page;
    bool gate,armed,dirty,save_pending,save_failed;
} TimbermanApp;
extern TimbermanApp timberman_game_state;
extern const Game timberman_game;
void timberman_app_init(TimbermanApp *a,uint32_t seed);
void timberman_app_enter(TimbermanApp *a,uint32_t now);
GameResult timberman_app_update(TimbermanApp *a,uint8_t pressed,uint8_t held,uint32_t now);
void timberman_app_service(TimbermanApp *a,bool idle);
void timberman_render(const TimbermanApp *a,uint8_t frame[1024]);
#endif
