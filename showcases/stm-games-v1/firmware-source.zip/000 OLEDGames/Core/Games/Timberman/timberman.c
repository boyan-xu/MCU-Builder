#include "timberman.h"
#include <string.h>
static uint8_t next_branch(TimbermanState *s,uint8_t previous) {
    s->seed^=s->seed<<13;s->seed^=s->seed>>17;s->seed^=s->seed<<5;
    return previous?TM_NONE:(uint8_t)(s->seed%3);
}
void timberman_start(TimbermanState *s,uint32_t seed) {
    memset(s,0,sizeof *s);s->seed=seed?seed:1;s->remaining=TM_TIME;s->side=TM_LEFT;
    for(unsigned i=3;i<TM_SEGMENTS;i++)s->branch[i]=next_branch(s,s->branch[i-1]);
}
bool timberman_chop(TimbermanState *s,uint8_t side) {
    if(s->over || (side!=TM_LEFT && side!=TM_RIGHT))return false;
    s->side=side;s->started=true;
    if(s->branch[0]==side || s->branch[1]==side){s->over=true;return false;}
    memmove(s->branch,s->branch+1,TM_SEGMENTS-1);
    s->branch[TM_SEGMENTS-1]=next_branch(s,s->branch[TM_SEGMENTS-2]);
    uint32_t difficulty=s->score/5;if(difficulty>150)difficulty=150;
    s->remaining+=300-difficulty;if(s->remaining>TM_TIME)s->remaining=TM_TIME;
    if(s->score<TM_MAX_SCORE)s->score++;
    return true;
}
void timberman_tick(TimbermanState *s,uint32_t elapsed) {
    if(!s->started || s->over)return;
    if(elapsed>=s->remaining){s->remaining=0;s->over=s->timeout=true;}
    else s->remaining-=elapsed;
}
