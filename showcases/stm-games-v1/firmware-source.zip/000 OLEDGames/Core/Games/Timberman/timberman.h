#ifndef TIMBERMAN_H
#define TIMBERMAN_H
#include <stdbool.h>
#include <stdint.h>
#define TM_SEGMENTS 8U
#define TM_MAX_SCORE 999999U
#define TM_TIME 5000U
enum { TM_NONE, TM_LEFT, TM_RIGHT };
typedef struct {
    uint32_t seed, score, remaining;
    uint8_t branch[TM_SEGMENTS], side;
    bool started, over, timeout;
} TimbermanState;
void timberman_start(TimbermanState *s,uint32_t seed);
bool timberman_chop(TimbermanState *s,uint8_t side);
void timberman_tick(TimbermanState *s,uint32_t elapsed);
#endif
