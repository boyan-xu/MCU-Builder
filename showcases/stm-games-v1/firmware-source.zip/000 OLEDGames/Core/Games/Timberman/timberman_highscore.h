#ifndef TIMBERMAN_HIGHSCORE_H
#define TIMBERMAN_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define TM_HIGHSCORE_BASE 0x0800B800U
#define TM_HIGHSCORE_PAGE 1024U
#define TM_HIGHSCORE_COMMIT 0x71BECAFEU
uint32_t timberman_highscore_load(void);
bool timberman_highscore_save(uint32_t score);
#endif
