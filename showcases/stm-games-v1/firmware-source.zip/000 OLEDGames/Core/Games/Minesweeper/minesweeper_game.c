#include "minesweeper_game.h"
#include "display.h"
MinesweeperApp minesweeper_game_state;
static void init(uint32_t seed){minesweeper_init(&minesweeper_game_state,seed);}
static void enter(uint32_t now){minesweeper_enter(&minesweeper_game_state,now);}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    MinesweeperPage before=minesweeper_game_state.page;
    minesweeper_update(&minesweeper_game_state,pressed,held,now);
    if(minesweeper_game_state.exit_requested)return GAME_EXIT;
    /* PLAY and loss own their gate so held keys cannot freeze clock or blasts. */
    return before!=minesweeper_game_state.page && minesweeper_game_state.page!=MS_PLAY && minesweeper_game_state.page!=MS_LOST?GAME_PAGE_CHANGED:GAME_STAY;
}
static const uint8_t *draw(void) {
    if(!minesweeper_game_state.dirty)return NULL;
    uint8_t *frame=display_frame();
    minesweeper_render(&minesweeper_game_state,frame);minesweeper_game_state.dirty=false;return frame;
}
const Game minesweeper_game={"MINESWEEPER",GAME_LANDSCAPE,init,enter,update,draw,NULL};
