#ifndef MINESWEEPER_GAME_H
#define MINESWEEPER_GAME_H
#include "game.h"
#include "minesweeper.h"
extern MinesweeperApp minesweeper_game_state;
extern const Game minesweeper_game;
#endif
