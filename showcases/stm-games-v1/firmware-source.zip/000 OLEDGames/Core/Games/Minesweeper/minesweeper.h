#ifndef MINESWEEPER_H
#define MINESWEEPER_H
#include <stdbool.h>
#include <stdint.h>
#define MS_MAX_ROWS 16
#define MS_MAX_COLS 30
#define MS_MAX_CELLS (MS_MAX_ROWS * MS_MAX_COLS)
#define MS_MINE 16U
#define MS_OPEN 32U
#define MS_FLAG 64U
#define MS_QUESTION 128U
typedef enum { MS_TITLE, MS_PLAY, MS_PAUSE, MS_WON, MS_LOST, MS_CUSTOM } MinesweeperPage;
typedef struct {
    uint8_t cells[MS_MAX_CELLS];
    uint32_t rng, elapsed_ms, last_ms, ui_ms;
    uint16_t mines, flags, opened, exploded;
    uint16_t blast_cells[64], blast_ms;
    uint8_t blast_count;
    uint8_t rows, cols, row, col, view_row, view_col, selection;
    MinesweeperPage page;
    bool action, started, gate, dirty, exit_requested;
} MinesweeperApp;
void minesweeper_init(MinesweeperApp *a, uint32_t seed);
void minesweeper_enter(MinesweeperApp *a, uint32_t now);
bool minesweeper_start(MinesweeperApp *a, unsigned rows, unsigned cols, unsigned mines, uint32_t now);
void minesweeper_update(MinesweeperApp *a, uint8_t pressed, uint8_t held, uint32_t now);
void minesweeper_render(const MinesweeperApp *a, uint8_t frame[1024]);
#endif
