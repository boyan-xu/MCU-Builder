#include "minesweeper.h"
#include "buttons.h"
#include "game_menu.h"
#include <string.h>

static uint32_t random_next(MinesweeperApp *a) {
    uint32_t x=a->rng ? a->rng : 0x9e3779b9U;
    x^=x<<13;x^=x>>17;x^=x<<5;return a->rng=x;
}
static unsigned blast_start(unsigned rank){return rank?360U+(rank-1U)*120U:0;}
static unsigned blast_end(const MinesweeperApp *a){return a->blast_count?blast_start(a->blast_count-1U)+360U:0;}
static bool blasting(const MinesweeperApp *a){return a->page==MS_LOST && a->blast_ms<blast_end(a);}
static unsigned blast_key(const MinesweeperApp *a,unsigned index){
    int dy=(int)(index/a->cols)-a->row,dx=(int)(index%a->cols)-a->col;
    return (unsigned)((dy<0?-dy:dy)+(dx<0?-dx:dx))*MS_MAX_CELLS+index;
}
static void begin_blast(MinesweeperApp *a,unsigned first){
    a->blast_ms=0;a->blast_count=1;a->blast_cells[0]=(uint16_t)first;
    for(unsigned r=a->view_row;r<a->view_row+8U;r++)for(unsigned c=a->view_col;c<a->view_col+8U;c++){
        unsigned cell=r*a->cols+c;
        if(cell==first || !(a->cells[cell]&MS_MINE))continue;
        unsigned n=a->blast_count++,key=blast_key(a,cell);
        while(n>1 && blast_key(a,a->blast_cells[n-1])>key){a->blast_cells[n]=a->blast_cells[n-1];n--;}
        a->blast_cells[n]=(uint16_t)cell;
    }
}
void minesweeper_enter(MinesweeperApp *a,uint32_t now) {
    a->page=MS_TITLE;a->selection=0;a->action=false;a->started=false;
    a->elapsed_ms=0;a->ui_ms=0;a->last_ms=now;a->exit_requested=false;a->gate=true;a->dirty=true;
    a->blast_count=0;a->blast_ms=0;
}
void minesweeper_init(MinesweeperApp *a,uint32_t seed) {
    memset(a,0,sizeof(*a));a->rng=seed;a->rows=8;a->cols=8;a->mines=10;
    minesweeper_enter(a,0);
}
bool minesweeper_start(MinesweeperApp *a,unsigned rows,unsigned cols,unsigned mines,uint32_t now) {
    if(rows<8 || rows>MS_MAX_ROWS || cols<8 || cols>MS_MAX_COLS || !mines || mines>rows*cols-9)return false;
    uint32_t rng=a->rng;memset(a,0,sizeof(*a));a->rng=rng;
    a->rows=rows;a->cols=cols;a->mines=mines;a->exploded=UINT16_MAX;
    a->last_ms=now;a->page=MS_PLAY;a->gate=true;a->dirty=true;return true;
}
static void place_mines(MinesweeperApp *a,uint32_t now,uint16_t choices[MS_MAX_CELLS]) {
    unsigned count=0;
    a->rng^=now;
    for(unsigned r=0;r<a->rows;r++)for(unsigned c=0;c<a->cols;c++)
        if(!(r+1>=a->row && r<=a->row+1U && c+1>=a->col && c<=a->col+1U))
            choices[count++]=(uint16_t)(r*a->cols+c);
    for(unsigned n=0;n<a->mines;n++) {
        unsigned pick=random_next(a)%count;a->cells[choices[pick]]|=MS_MINE;
        choices[pick]=choices[--count];
    }
    for(int r=0;r<a->rows;r++)for(int c=0;c<a->cols;c++) {
        unsigned i=(unsigned)(r*a->cols+c);if(a->cells[i]&MS_MINE)continue;
        unsigned neighbors=0;
        for(int y=r-1;y<=r+1;y++)for(int x=c-1;x<=c+1;x++)
            if(y>=0 && y<a->rows && x>=0 && x<a->cols)
                neighbors+=(a->cells[y*a->cols+x]&MS_MINE)!=0;
        a->cells[i]|=(uint8_t)neighbors;
    }
    a->started=true;
}
static void open_cell(MinesweeperApp *a,uint32_t now) {
    unsigned first=a->row*a->cols+a->col;
    if(a->cells[first]&(MS_FLAG|MS_OPEN))return;
    uint16_t queue[MS_MAX_CELLS];
    if(!a->started)place_mines(a,now,queue);
    if(a->cells[first]&MS_MINE){a->exploded=first;a->page=MS_LOST;begin_blast(a,first);return;}
    unsigned head=0,tail=0;
    a->cells[first]=(a->cells[first]&15U)|MS_OPEN;a->opened++;
    if(!(a->cells[first]&15U))queue[tail++]=(uint16_t)first;
    while(head<tail) {
        unsigned i=queue[head++];int r=(int)(i/a->cols),c=(int)(i%a->cols);
        for(int y=r-1;y<=r+1;y++)for(int x=c-1;x<=c+1;x++) {
            if(y<0 || y>=a->rows || x<0 || x>=a->cols)continue;
            unsigned n=(unsigned)(y*a->cols+x);
            if(a->cells[n]&(MS_OPEN|MS_FLAG|MS_MINE))continue;
            a->cells[n]=(a->cells[n]&15U)|MS_OPEN;a->opened++;
            if(!(a->cells[n]&15U))queue[tail++]=(uint16_t)n;
        }
    }
    if(a->opened==a->rows*a->cols-a->mines)a->page=MS_WON;
}
static void mark_cell(MinesweeperApp *a,uint8_t mark) {
    uint8_t *cell=&a->cells[a->row*a->cols+a->col];if(*cell&MS_OPEN)return;
    if(mark==MS_FLAG && !(*cell&MS_FLAG) && a->flags==a->mines)return;
    if(*cell&MS_FLAG)a->flags--;
    uint8_t next=(*cell&mark)?0:mark;*cell=(*cell&31U)|next;
    if(next==MS_FLAG)a->flags++;
}
static uint8_t scroll_axis(unsigned pos,unsigned view,unsigned count) {
    if(pos<view)view=pos;
    if(pos>=view+8)view=pos-7;
    if(view && pos==view)view--;
    if(view+8<count && pos==view+7)view++;
    return (uint8_t)view;
}
void minesweeper_update(MinesweeperApp *a,uint8_t pressed,uint8_t held,uint32_t now) {
    uint32_t delta=now-a->last_ms;a->last_ms=now;
    bool was_blasting=blasting(a);
    if(was_blasting){
        unsigned before=a->blast_ms,end=blast_end(a);
        a->blast_ms=(uint16_t)(delta>=end-before?end:before+delta);
        if(before/60U!=a->blast_ms/60U || a->blast_ms==end)a->dirty=true;
        if(a->blast_ms==end && held && !pressed)a->gate=true;
    }
    unsigned phase=a->ui_ms/250U;
    a->ui_ms=(a->ui_ms+delta%1000U)%1000U;
    unsigned next_phase=a->ui_ms/250U;
    if((a->page==MS_CUSTOM && a->selection<3 && phase/2!=next_phase/2) ||
       (a->page==MS_PLAY && (a->rows>8 || a->cols>8) && phase!=next_phase))a->dirty=true;
    if(a->page==MS_PLAY && a->started) {
        uint32_t previous=a->elapsed_ms/1000U;
        a->elapsed_ms=delta>UINT32_MAX-a->elapsed_ms?UINT32_MAX:a->elapsed_ms+delta;
        if(a->elapsed_ms/1000U!=previous)a->dirty=true;
    }
    if(a->gate){if(!held)a->gate=false;return;}
    if(!pressed)return;
    a->gate=true;
    if((pressed&(pressed-1U)) || held!=pressed)return;
    a->dirty=true;
    if(a->page==MS_TITLE) {
        if(pressed==KEY_UP)a->selection=(a->selection+4)%5;
        else if(pressed==KEY_DOWN)a->selection=(a->selection+1)%5;
        else if(pressed==KEY_OK) {
            if(a->selection<3) {
                static const uint8_t rows[3]={8,16,16},cols[3]={8,16,30},mines[3]={10,40,99};
                minesweeper_start(a,rows[a->selection],cols[a->selection],mines[a->selection],now);
            } else if(a->selection==3){a->page=MS_CUSTOM;a->selection=0;a->ui_ms=0;}
            else a->exit_requested=true;
        }
    } else if(a->page==MS_CUSTOM) {
        if(pressed==KEY_UP)a->selection=(a->selection+4)%5;
        else if(pressed==KEY_DOWN)a->selection=(a->selection+1)%5;
        else if(pressed==KEY_OK) {
            if(a->selection==3)minesweeper_start(a,a->rows,a->cols,a->mines,now);
            else if(a->selection==4){a->page=MS_TITLE;a->selection=3;}
        } else if(pressed==KEY_LEFT || pressed==KEY_RIGHT) {
            int step=pressed==KEY_RIGHT?1:-1;
            if(a->selection==0 && (step>0?a->rows<MS_MAX_ROWS:a->rows>8))a->rows+=step;
            if(a->selection==1 && (step>0?a->cols<MS_MAX_COLS:a->cols>8))a->cols+=step;
            unsigned max=a->rows*a->cols-9;
            if(a->mines>max)a->mines=max;
            if(a->selection==2 && (step>0?a->mines<max:a->mines>1))a->mines+=step;
        }
        a->ui_ms=0;
    } else if(a->page==MS_PAUSE) {
        if(pressed==KEY_UP)a->selection=(a->selection+2)%3;
        else if(pressed==KEY_DOWN)a->selection=(a->selection+1)%3;
        else if(pressed==KEY_OK) {
            if(a->selection==0)a->page=MS_PLAY;
            else if(a->selection==1)minesweeper_start(a,a->rows,a->cols,a->mines,now);
            else a->exit_requested=true;
        }
    } else if(a->page==MS_WON || a->page==MS_LOST) {
        if(pressed==KEY_OK){
            if(was_blasting)a->blast_ms=(uint16_t)blast_end(a);
            else minesweeper_start(a,a->rows,a->cols,a->mines,now);
        }
        else if(pressed==KEY_DOWN)a->exit_requested=true;
    } else if(a->page==MS_PLAY) {
        if(a->action) {
            if(pressed==KEY_DOWN){a->page=MS_PAUSE;a->selection=0;}
            else if(pressed==KEY_OK || pressed==KEY_UP || pressed==KEY_LEFT) {
                a->action=false;
                if(pressed==KEY_OK)open_cell(a,now);
                else mark_cell(a,pressed==KEY_UP?MS_FLAG:MS_QUESTION);
            }
        } else {
            if(pressed==KEY_OK)a->action=true;
            else if(pressed==KEY_UP && a->row)a->row--;
            else if(pressed==KEY_DOWN && a->row+1<a->rows)a->row++;
            else if(pressed==KEY_LEFT && a->col)a->col--;
            else if(pressed==KEY_RIGHT && a->col+1<a->cols)a->col++;
            a->view_row=scroll_axis(a->row,a->view_row,a->rows);
            a->view_col=scroll_axis(a->col,a->view_col,a->cols);
        }
    }
}

static void pixel(uint8_t *f,unsigned x,unsigned y) {if(x<128 && y<64)f[y/8*128+x]|=(uint8_t)(1U<<(y%8));}
static void box(uint8_t *f,unsigned x,unsigned y,unsigned width,unsigned height) {
    game_box(f,GAME_LANDSCAPE,(int)x,(int)y,(int)width,(int)height,false);
}
static void arrow(uint8_t *f,unsigned x,unsigned y,uint8_t direction) {
    for(unsigned n=0;n<3;n++) {
        if(direction==KEY_UP)pixel(f,x+n,y+1);
        else if(direction==KEY_DOWN)pixel(f,x+n,y);
        else if(direction==KEY_LEFT)pixel(f,x+1,y+n);
        else pixel(f,x,y+n);
    }
    pixel(f,x+(direction==KEY_LEFT?0:1),y+(direction==KEY_UP?0:1));
}
static void text(uint8_t *f,unsigned x,unsigned y,const char *s){game_text(f,GAME_LANDSCAPE,x,y,s);}
static char *number(char *p,unsigned value) { return game_decimal(p,value); }
static void small(uint8_t *f,unsigned x,unsigned y,unsigned glyph) {
    static const uint8_t bits[][5]={
        {0,0,0,0,0},{7,1,7,1,7},
        {7,1,3,0,2},{6,6,4,4,4},{2,7,2,7,2},{5,5,2,5,5}
    };
    const uint8_t *shape=glyph>0 && glyph<9?game_digits3[glyph]:bits[glyph?glyph-8:0];
    for(unsigned r=0;r<5;r++)for(unsigned c=0;c<3;c++)if(shape[r]&(4U>>c))pixel(f,x+c,y+r);
}
static void blast_pixel(uint8_t *f,int x,int y){if(x>=0 && x<64 && y>=0 && y<64)pixel(f,(unsigned)x,(unsigned)y);}
static void draw_blast(uint8_t *f,int x,int y,unsigned phase){
    /* One quadrant per phase; mirror it to keep the original procedural shapes. */
    static const uint16_t rows[5][8]={
        {15,15,15,15,0,0,0,0},
        {127,3,5,9,1,1,1,0},
        {128,64,32,16,8,4,2,1},
        {0,256,0,0,0,64,0,0},
        {0,0,0,0,0,0,128,0}
    };
    if(phase>=5)return;
    for(int dy=0;dy<8;dy++)for(unsigned bits=rows[phase][dy],dx=0;bits;bits>>=1,dx++)
        if(bits&1)for(int sy=-1;sy<=1;sy+=2)for(int sx=-1;sx<=1;sx+=2)
            blast_pixel(f,x+sx*(int)dx,y+sy*dy);
}
static void key_guide(uint8_t *f,bool action) {
    static const uint8_t icons[10][7]={
        {8,28,62,8,8,8,0},{8,8,8,62,28,8,0},{8,24,62,24,8,0,0},
        {8,12,62,12,8,0,0},{0,28,34,34,34,28,0},
        {32,60,62,60,32,32,32},{62,2,4,8,0,8,0},{62,34,34,34,34,34,62},
        {0,62,0,62,0,62,0},{8,16,62,17,9,1,30}
    };
    static const uint8_t x[5]={90,72,90,108,90},y[5]={23,36,36,36,49};
    static const uint8_t move[5]={0,2,4,3,1},act[5]={5,6,7,0,8};
    for(unsigned k=0;k<5;k++) {
        box(f,x[k],y[k],11,11);if(action && k==3)continue;
        unsigned icon=action?act[k]:move[k];
        for(unsigned r=0;r<7;r++)for(unsigned c=0;c<7;c++)
            if(icons[icon][r]&(64U>>c))pixel(f,x[k]+2+c,y[k]+2+r);
    }
}
void minesweeper_render(const MinesweeperApp *a,uint8_t frame[1024]) {
    memset(frame,0,1024);char label[16],*p;
    bool active=blasting(a);
    if(a->page==MS_TITLE || a->page==MS_PAUSE || a->page==MS_CUSTOM) {
        bool pause=a->page==MS_PAUSE;
        text(frame,22,0,pause?"PAUSED":"MINESWEEPER");
        static const char *const title[]={"8X8    10","16X16  40","16X30  99","CUSTOM","EXIT"};
        static const char *const paused[]={"CONTINUE","NEW GAME","EXIT"};
        static const char *const custom[]={"ROWS","COLS","MINES","START","BACK"};
        for(unsigned i=0;i<(pause?3U:5U);i++){
            unsigned y=a->page==MS_CUSTOM?12+i*10:16+i*8;
            if(a->page!=MS_CUSTOM)text(frame,12,y,i==a->selection?">":" ");
            text(frame,24,y,pause?paused[i]:a->page==MS_CUSTOM?custom[i]:title[i]);
            if(a->page==MS_CUSTOM) {
                if(i==a->selection)box(frame,12,y-2,105,11);
                if(i<3) {
                    unsigned value=i==0?a->rows:i==1?a->cols:a->mines;
                    if(i!=a->selection || a->ui_ms<500){number(label,value);text(frame,78,y,label);}
                    if(i==a->selection) {
                        if(value>(i<2?8U:1U))arrow(frame,68,y+2,KEY_LEFT);
                        if(value<(i==0?MS_MAX_ROWS:i==1?MS_MAX_COLS:(unsigned)(a->rows*a->cols-9)))arrow(frame,102,y+2,KEY_RIGHT);
                    }
                }
            }
        }
        if(a->page!=MS_CUSTOM)text(frame,4,56,"UP/DOWN  OK SELECT");
        return;
    }
    for(unsigned n=0;n<8;n++)for(unsigned i=0;i<64;i++){pixel(frame,n*8,i);pixel(frame,i,n*8);}
    for(unsigned r=0;r<8;r++)for(unsigned c=0;c<8;c++) {
        unsigned index=(r+a->view_row)*a->cols+c+a->view_col;
        uint8_t cell=a->cells[index];unsigned glyph=0;
        bool revealed=a->page==MS_LOST && !active;
        if(active && (cell&MS_MINE))for(unsigned n=0;n<a->blast_count;n++)
            if(a->blast_cells[n]==index && a->blast_ms>=blast_start(n)+300U)revealed=true;
        if(revealed && (cell&MS_MINE))glyph=12;
        else if(a->page==MS_LOST && !active && (cell&MS_FLAG))glyph=13;
        else if(cell&MS_OPEN)glyph=cell&15U;
        else if(cell&MS_FLAG)glyph=11;
        else if(cell&MS_QUESTION)glyph=10;
        else {pixel(frame,c*8+3,r*8+3);pixel(frame,c*8+4,r*8+4);}
        small(frame,c*8+3,r*8+2,glyph);
    }
    box(frame,0,0,64,64);
    unsigned x=(a->col-a->view_col)*8,y=(a->row-a->view_row)*8;box(frame,x,y,8,8);
    if(a->action)for(unsigned dy=1;dy<7;dy++)for(unsigned dx=1;dx<7;dx++)
        frame[(y+dy)/8*128+x+dx]^=(uint8_t)(1U<<((y+dy)%8));
    if(active)for(unsigned n=0;n<a->blast_count;n++){
        unsigned start=blast_start(n);if(a->blast_ms<start || a->blast_ms>=start+300U)continue;
        unsigned cell=a->blast_cells[n];
        draw_blast(frame,(int)(cell%a->cols-a->view_col)*8+4,(int)(cell/a->cols-a->view_row)*8+4,(a->blast_ms-start)/60U);
    }
    unsigned offset=a->ui_ms/250U;if(offset==3)offset=1;
    if(a->view_col){game_clear(frame,GAME_LANDSCAPE,0,0,4,64);arrow(frame,offset,31,KEY_LEFT);}
    if(a->view_col+8<a->cols){game_clear(frame,GAME_LANDSCAPE,60,0,4,64);arrow(frame,60+offset,31,KEY_RIGHT);}
    if(a->view_row){game_clear(frame,GAME_LANDSCAPE,0,0,64,4);arrow(frame,31,offset,KEY_UP);}
    if(a->view_row+8<a->rows){game_clear(frame,GAME_LANDSCAPE,0,60,64,4);arrow(frame,31,60+offset,KEY_DOWN);}
    unsigned seconds=a->elapsed_ms/1000U,minutes=seconds/60U;
    p=label;
    if(minutes>=60){p=number(p,minutes/60);*p++=':';minutes%=60;}
    *p++=(char)('0'+minutes/10);*p++=(char)('0'+minutes%10);*p++=':';
    *p++=(char)('0'+seconds/10%6);*p++=(char)('0'+seconds%10);*p=0;text(frame,66,0,label);
    label[0]='F';p=number(label+1,a->flags);*p++='/';number(p,a->mines);text(frame,66,8,label);
    if(a->page==MS_WON || a->page==MS_LOST) {
        text(frame,66,24,a->page==MS_WON?"YOU WIN":active?"BOOM":"MINE HIT");
        text(frame,66,40,active?"OK SKIP":"OK NEW");text(frame,66,52,"DOWN EXIT");return;
    }
    text(frame,66,16,a->action?"ACT":"MOVE");
    p=number(label,a->row+1);*p++=',';number(p,a->col+1);text(frame,96,16,label);
    key_guide(frame,a->action);
}
