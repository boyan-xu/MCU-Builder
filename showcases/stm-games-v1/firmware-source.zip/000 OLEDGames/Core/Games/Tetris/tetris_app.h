#ifndef TETRIS_APP_H
#define TETRIS_APP_H
#include "tetris.h"
#include "buttons.h"
typedef enum { TETRIS_APP_MENU, TETRIS_APP_PLAY, TETRIS_APP_PAUSE, TETRIS_APP_END } TetrisAppState;
typedef struct {
    Tetris tetris;
    TetrisAppState state;
    uint32_t last_fall, last_repeat, soft_at, seed;
    uint32_t best_score;
    uint8_t direction;
    bool repeating, soft_held, dirty;
    bool save_pending, save_failed;
} TetrisApp;
void tetris_app_init(TetrisApp *a, uint32_t seed);
void tetris_app_input(TetrisApp *a, uint8_t pressed, uint8_t held, uint32_t now);
void tetris_app_tick(TetrisApp *a, uint32_t now);
#endif
