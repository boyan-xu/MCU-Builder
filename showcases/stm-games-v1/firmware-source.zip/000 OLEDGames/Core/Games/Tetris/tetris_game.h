#ifndef TETRIS_GAME_H
#define TETRIS_GAME_H
#include "game.h"
#include "tetris_app.h"
extern TetrisApp tetris_game_state;
extern const Game tetris_game;
#endif
