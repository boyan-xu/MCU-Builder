#ifndef TETRIS_HIGHSCORE_H
#define TETRIS_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define TETRIS_HIGHSCORE_BASE 0x0800F000U
#define TETRIS_HIGHSCORE_PAGE_SIZE 1024U
uint32_t tetris_highscore_load(void);
bool tetris_highscore_save(uint32_t score);
#endif
