#include "tetris_game.h"
#include "tetris_screen.h"
#include "tetris_highscore.h"
#include "game_menu.h"
TetrisApp tetris_game_state;
static TetrisScreen screen;
static uint8_t selection;
static void init(uint32_t seed) { tetris_app_init(&tetris_game_state,seed);tetris_game_state.best_score=tetris_highscore_load(); }
static void enter(uint32_t now) {
    tetris_game_state.state=TETRIS_APP_MENU;selection=0;
    tetris_game_state.direction=0;tetris_game_state.repeating=false;tetris_game_state.soft_held=false;
    tetris_game_state.last_fall=now;tetris_game_state.dirty=true;screen.valid=false;
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    TetrisApp *a=&tetris_game_state;TetrisAppState before=a->state;
    if(a->state!=TETRIS_APP_PLAY) {
        unsigned count=a->state==TETRIS_APP_PAUSE ? 3 : 2;
        if(pressed==KEY_UP || pressed==KEY_DOWN) {
            selection=pressed==KEY_UP ? (selection+count-1)%count : (selection+1)%count;
            a->dirty=true;return GAME_STAY;
        }
        if(pressed&KEY_OK) {
            if(selection==count-1)return GAME_EXIT;
            if(a->state==TETRIS_APP_PAUSE && selection==1)a->state=TETRIS_APP_MENU;
        } else return GAME_STAY;
    }
    tetris_app_input(a,pressed,held,now);tetris_app_tick(a,now);
    if(before!=a->state) { selection=0;return GAME_PAGE_CHANGED; }
    return GAME_STAY;
}
static const uint8_t *draw(void) {
    TetrisApp *a=&tetris_game_state;if(!a->dirty)return NULL;
    tetris_screen_update(&screen,a);
    if(a->state!=TETRIS_APP_PLAY) {
        unsigned y=a->state==TETRIS_APP_END ? 97 : 56;
        game_clear(screen.frame,GAME_PORTRAIT,0,y,64,a->state==TETRIS_APP_MENU ? 24 : 34);
        game_text(screen.frame,GAME_PORTRAIT,0,y,selection==0 ? "> " : "  ");
        game_text(screen.frame,GAME_PORTRAIT,12,y,a->state==TETRIS_APP_MENU ? "START" : a->state==TETRIS_APP_PAUSE ? "RESUME" : "RETRY");
        if(a->state==TETRIS_APP_PAUSE) {
            game_text(screen.frame,GAME_PORTRAIT,0,y+12,selection==1 ? "> RESTART" : "  RESTART");
            game_text(screen.frame,GAME_PORTRAIT,0,y+24,selection==2 ? "> EXIT" : "  EXIT");
        } else game_text(screen.frame,GAME_PORTRAIT,0,y+12,selection==1 ? "> EXIT" : "  EXIT");
    }
    a->dirty=false;return screen.frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;
    if(!idle)return;
    if(tetris_game_state.save_pending) {
        tetris_game_state.save_pending=false;
        tetris_game_state.save_failed=!tetris_highscore_save(tetris_game_state.best_score);
        tetris_game_state.dirty=true;
    }
}
const Game tetris_game={"TETRIS",GAME_PORTRAIT,init,enter,update,draw,service};
