#ifndef TETRIS_SCREEN_H
#define TETRIS_SCREEN_H
#include "tetris_app.h"
#define TETRIS_SCREEN_BYTES 1024
typedef struct {
    uint8_t frame[TETRIS_SCREEN_BYTES];
    Tetris previous;
    TetrisAppState state;
    bool valid;
} TetrisScreen;
void tetris_screen_render(const TetrisApp *a, uint8_t frame[TETRIS_SCREEN_BYTES]);
void tetris_screen_update(TetrisScreen *s, const TetrisApp *a);
void tetris_screen_pixel(uint8_t frame[TETRIS_SCREEN_BYTES], unsigned x, unsigned y);
#endif
