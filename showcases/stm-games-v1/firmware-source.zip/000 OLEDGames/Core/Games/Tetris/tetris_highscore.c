#include "tetris_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={TETRIS_HIGHSCORE_BASE,0x54455431U,UINT32_MAX};
uint32_t tetris_highscore_load(void) {return score_journal_load(&journal);}
bool tetris_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
