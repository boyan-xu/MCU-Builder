#include "tetris.h"
#include <string.h>
static const uint16_t shapes[PIECE_COUNT][4] = {
    {0x00f0,0x4444,0x0f00,0x2222}, {0x0066,0x0066,0x0066,0x0066},
    {0x0072,0x0262,0x0270,0x0232}, {0x0036,0x0462,0x0360,0x0231},
    {0x0063,0x0264,0x0630,0x0132}, {0x0071,0x0226,0x0470,0x0322},
    {0x0074,0x0622,0x0170,0x0223}
};
uint16_t tetris_mask(uint8_t piece,uint8_t rotation) {
    return piece < PIECE_COUNT ? shapes[piece][rotation & 3U] : 0;
}
bool tetris_fits(const Tetris *t,uint8_t piece,uint8_t rotation,int x,int y) {
    uint16_t mask=tetris_mask(piece,rotation);
    if (!mask) return false;
    for (int row=0;row<4;row++) for (int col=0;col<4;col++) {
        if (!(mask & (1U << (row*4+col)))) continue;
        int bx=x+col, by=y+row;
        if (bx<0 || bx>=TETRIS_COLS || by<0 || by>=TETRIS_ROWS ||
            (t->rows[by] & (1U << bx))) return false;
    }
    return true;
}
static uint8_t draw(Tetris *t) {
    uint32_t r=t->random;
    r^=r<<13; r^=r>>17; r^=r<<5;
    t->random=r;
    return r % PIECE_COUNT;
}
static void spawn(Tetris *t) {
    t->piece=t->next; t->next=draw(t);
    t->rotation=0; t->x=3; t->y=0;
    t->over=!tetris_fits(t,t->piece,0,t->x,t->y);
}
void tetris_init(Tetris *t,uint32_t seed) {
    memset(t,0,sizeof(*t)); t->random=seed ? seed : 0x6d2b79f5U;
    t->next=draw(t); spawn(t);
}
bool tetris_move(Tetris *t,int direction) {
    if (t->over || direction < -1 || direction > 1 ||
        !tetris_fits(t,t->piece,t->rotation,t->x+direction,t->y)) return false;
    t->x+=direction; return true;
}
bool tetris_rotate(Tetris *t) {
    uint8_t rotation=(t->rotation+1U)&3U;
    if (t->over || !tetris_fits(t,t->piece,rotation,t->x,t->y)) return false;
    t->rotation=rotation; return true;
}
uint32_t tetris_level(const Tetris *t) { return t->lines/10U; }
uint16_t tetris_interval(const Tetris *t) {
    static const uint16_t ms[]={800,717,633,550,467,383,300,217,133,100,50};
    uint32_t level=tetris_level(t);
    return ms[level<10 ? level : 10];
}
void tetris_drop(Tetris *t,bool manual) {
    if (t->over) return;
    if (tetris_fits(t,t->piece,t->rotation,t->x,t->y+1)) {
        t->y++; if (manual) t->score++;
        return;
    }
    uint16_t mask=tetris_mask(t->piece,t->rotation);
    for (int row=0;row<4;row++) for (int col=0;col<4;col++)
        if (mask & (1U << (row*4+col))) t->rows[t->y+row] |= 1U << (t->x+col);
    unsigned cleared=0; int out=TETRIS_ROWS-1;
    for (int row=TETRIS_ROWS-1;row>=0;row--)
        if (t->rows[row]==1023U) cleared++;
        else t->rows[out--]=t->rows[row];
    while (out>=0) t->rows[out--]=0;
    static const uint16_t points[]={0,40,100,300,1200};
    t->score+=points[cleared]*(tetris_level(t)+1U);
    t->lines+=cleared;
    spawn(t);
}
