#include "tetris_app.h"
#include <string.h>
void tetris_app_init(TetrisApp *a,uint32_t seed) {
    memset(a,0,sizeof(*a)); a->seed=seed; a->state=TETRIS_APP_MENU; a->dirty=true;
}
static void dropped(TetrisApp *a,bool manual,uint32_t now) {
    tetris_drop(&a->tetris,manual); a->last_fall=now; a->dirty=true;
    if (a->tetris.over) {
        a->state=TETRIS_APP_END;
        if(a->tetris.score>a->best_score) {
            a->best_score=a->tetris.score;a->save_pending=true;
        }
    }
}
void tetris_app_input(TetrisApp *a,uint8_t pressed,uint8_t held,uint32_t now) {
    if (pressed & KEY_OK) {
        if (a->state==TETRIS_APP_MENU || a->state==TETRIS_APP_END) {
            tetris_init(&a->tetris,a->seed^now); a->state=TETRIS_APP_PLAY;
            a->save_failed=false;
        } else a->state=a->state==TETRIS_APP_PLAY ? TETRIS_APP_PAUSE : TETRIS_APP_PLAY;
        a->last_fall=now; a->last_repeat=now; a->soft_at=now;
        a->direction=0; a->repeating=false; a->soft_held=false;
        a->dirty=true; return;
    }
    if (a->state!=TETRIS_APP_PLAY) return;
    uint8_t direction=held&(KEY_LEFT|KEY_RIGHT);
    if (direction==(KEY_LEFT|KEY_RIGHT)) direction=0;
    bool move=false;
    if (direction!=a->direction) {
        a->direction=direction; a->last_repeat=now; a->repeating=false;
        move=direction!=0;
    } else if (direction && (uint32_t)(now-a->last_repeat)>=(a->repeating ? 100U : 300U)) {
        move=true; a->last_repeat=now; a->repeating=true;
    }
    if (move && tetris_move(&a->tetris,direction==KEY_LEFT ? -1 : 1)) a->dirty=true;
    if ((pressed&KEY_UP) && tetris_rotate(&a->tetris)) a->dirty=true;
    if (held&KEY_DOWN) {
        if (!a->soft_held || (uint32_t)(now-a->soft_at)>=50U) {
            dropped(a,true,now); a->soft_at=now;
        }
        a->soft_held=true;
    } else a->soft_held=false;
}
void tetris_app_tick(TetrisApp *a,uint32_t now) {
    if (a->state==TETRIS_APP_PLAY && (uint32_t)(now-a->last_fall)>=tetris_interval(&a->tetris))
        dropped(a,false,now);
}
