#ifndef TETRIS_H
#define TETRIS_H
#include <stdbool.h>
#include <stdint.h>
#define TETRIS_COLS 10
#define TETRIS_ROWS 20
enum { PIECE_I, PIECE_O, PIECE_T, PIECE_S, PIECE_Z, PIECE_J, PIECE_L, PIECE_COUNT };
typedef struct {
    uint16_t rows[TETRIS_ROWS];
    uint32_t score, lines, random;
    uint8_t piece, next, rotation;
    int8_t x, y;
    bool over;
} Tetris;
uint16_t tetris_mask(uint8_t piece, uint8_t rotation);
bool tetris_fits(const Tetris *t, uint8_t piece, uint8_t rotation, int x, int y);
void tetris_init(Tetris *t, uint32_t seed);
bool tetris_move(Tetris *t, int direction);
bool tetris_rotate(Tetris *t);
void tetris_drop(Tetris *t, bool manual);
uint32_t tetris_level(const Tetris *t);
uint16_t tetris_interval(const Tetris *t);
#endif
