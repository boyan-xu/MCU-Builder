#include "tower_defense_scores.h"
#include "score_journal.h"
static const ScoreJournal journal={TD_SCORE_BASE,TD_SCORE_COMMIT,TD_SCORE_MASK};
uint32_t td_scores_load(void) {return score_journal_load(&journal);}
bool td_scores_save(uint32_t stars) {
    if(stars>TD_SCORE_MASK)return false;
    uint32_t best=score_journal_load(&journal),merged=best;
    for(unsigned i=0;i<10;i++) {
        unsigned shift=i*2,old=(best>>shift)&3,value=(stars>>shift)&3;
        if(value>old)merged=(merged&~(3U<<shift))|(value<<shift);
    }
    return score_journal_save(&journal,merged);
}
