#include "tower_defense_game.h"
#include "tower_defense_scores.h"
#include "buttons.h"
#include "game_menu.h"
#include "display.h"
#include <string.h>
TdApp td_game_state;
_Static_assert(sizeof(TdApp)+SCREEN_BYTES<=1536,"Tower Defense state plus shared frame budget");
static void request_save(TdApp *a){if(a->stars!=a->saved)a->save_pending=true;}
static GameResult page(TdApp *a,uint32_t now) {
    a->gate=a->dirty=a->force=true;a->last_tick=now;a->selection=0;a->notice=0;return GAME_PAGE_CHANGED;
}
static void init(uint32_t seed) {
    (void)seed;memset(&td_game_state,0,sizeof td_game_state);
    td_game_state.stars=td_game_state.saved=td_scores_load();
}
static void enter(uint32_t now) {
    TdApp *a=&td_game_state;a->ui=TD_UI_LEVELS;a->now=now;page(a,now);
}
static void start(TdApp *a,unsigned level) {
    td_start(&a->battle,level);a->ui=TD_UI_EDIT;a->x=a->y=0;a->button=TD_NONE;
}
static int enemy_at(const TdApp *a,unsigned ordinal) {
    for(unsigned i=0;i<TD_ENEMIES;i++)if(a->battle.enemies[i].active) {
        int x,y;td_enemy_xy(&a->battle,i,&x,&y);
        if(x/8==a->x && y/8==a->y){if(!ordinal)return i;ordinal--;}
    }
    return -1;
}
static unsigned enemy_count(const TdApp *a) {
    unsigned count=0;while(enemy_at(a,count)>=0)count++;return count;
}
static unsigned menu_count(const TdApp *a) {
    switch(a->ui) {
        case TD_UI_LEVELS:return TD_LEVELS+1;
        case TD_UI_BUILD:case TD_UI_RESULT:return 4;
        case TD_UI_TOWER:return 3;
        case TD_UI_ENEMIES:return enemy_count(a)+1;
        default:return 5;
    }
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    TdApp *a=&td_game_state;TdBattle *b=&a->battle;a->now=now;
    if(a->gate){a->last_tick=now;if(!pressed && !held)a->gate=false;return GAME_STAY;}
    if(a->ui==TD_UI_PLAY) {
        if(pressed==KEY_OK){a->ui=TD_UI_EDIT;a->button=TD_NONE;return page(a,now);}
        uint32_t elapsed=now-a->last_tick;if(elapsed>200){elapsed=200;a->last_tick=now-200;}
        while(elapsed>=50 && b->state==TD_FIGHT){td_step(b);a->last_tick+=50;elapsed-=50;a->dirty=true;}
        if(b->state==TD_WON || b->state==TD_LOST) {
            unsigned stars=td_stars(b),shift=b->level*2;
            if(stars>((a->stars>>shift)&3))a->stars=(a->stars&~(3U<<shift))|(stars<<shift);
            if(!a->save_error)request_save(a);
            a->ui=TD_UI_RESULT;return page(a,now);
        }
        if(b->state==TD_READY){a->ui=TD_UI_EDIT;a->button=1;return page(a,now);}
        return GAME_STAY;
    }
    if(a->ui==TD_UI_EDIT) {
        if(pressed==KEY_UP || pressed==KEY_DOWN || pressed==KEY_LEFT || pressed==KEY_RIGHT) {
            if(a->button!=TD_NONE) {
                if(pressed==KEY_LEFT){a->button=TD_NONE;a->x=11;}
                else if(pressed==KEY_UP || pressed==KEY_DOWN)a->button^=1;
            } else if(pressed==KEY_UP && a->y)a->y--;
            else if(pressed==KEY_DOWN && a->y<7)a->y++;
            else if(pressed==KEY_LEFT && a->x)a->x--;
            else if(pressed==KEY_RIGHT){if(a->x<11)a->x++;else a->button=a->y<5 ? 0 : 1;}
            a->notice=0;a->dirty=a->force=true;
        }
        if(pressed!=KEY_OK)return GAME_STAY;
        if(a->button==0){a->ui=TD_UI_MENU;return page(a,now);}
        if(a->button==1) {
            if(b->state==TD_READY)td_next_wave(b);
            a->ui=TD_UI_PLAY;return page(a,now);
        }
        unsigned cell=a->y*12+a->x;
        if(enemy_count(a))a->ui=TD_UI_ENEMIES;
        else if(td_tower_at(b,cell)>=0)a->ui=TD_UI_TOWER;
        else if(!td_road(b->level,cell))a->ui=TD_UI_BUILD;
        else {a->notice=1;a->dirty=a->force=true;return GAME_STAY;}
        return page(a,now);
    }
    unsigned count=menu_count(a);
    if(pressed==KEY_UP || pressed==KEY_DOWN) {
        a->selection=(a->selection+count+(pressed==KEY_UP ? -1 : 1))%count;
        a->notice=0;a->dirty=a->force=true;
    }
    if(pressed!=KEY_OK)return GAME_STAY;
    unsigned selected=a->selection;
    if(a->ui==TD_UI_LEVELS) {
        if(selected==TD_LEVELS){request_save(a);return GAME_EXIT;}
        request_save(a);start(a,selected);
    } else if(a->ui==TD_UI_BUILD || a->ui==TD_UI_TOWER) {
        if(selected==count-1)a->ui=TD_UI_EDIT;
        else {
            int tower=td_tower_at(b,a->y*12+a->x);bool okay;
            if(a->ui==TD_UI_BUILD)okay=td_build(b,a->y*12+a->x,selected);
            else okay=selected==0 ? td_upgrade(b,tower) : td_sell(b,tower);
            if(!okay){a->notice=2;a->dirty=a->force=true;return GAME_STAY;}
            a->ui=TD_UI_EDIT;
        }
    } else if(a->ui==TD_UI_ENEMIES) {
        int target=enemy_at(a,selected);if(target>=0)b->focus=target;
        a->ui=TD_UI_EDIT;
    } else if(a->ui==TD_UI_MENU) {
        request_save(a);
        if(selected==4)return GAME_EXIT;
        if(selected==1)start(a,b->level);
        else if(selected==2)a->ui=TD_UI_LEVELS;
        else {if(selected==3)b->focus=TD_NONE;a->ui=TD_UI_EDIT;}
    } else if(a->ui==TD_UI_RESULT) {
        request_save(a);
        if(selected==3)return GAME_EXIT;
        if(selected==2 || (selected==0 && b->level==9))a->ui=TD_UI_LEVELS;
        else start(a,b->level+(selected==0));
    }
    return page(a,now);
}
static void pixel(int x,int y) {if(x>=0 && x<128 && y>=0 && y<64)display_frame()[(y/8)*128+x]|=1U<<(y%8);}
static void box(int x,int y,int w,int h,bool solid) { game_box(display_frame(),GAME_LANDSCAPE,x,y,w,h,solid); }
static void text(unsigned x,unsigned y,const char *s){game_text(display_frame(),GAME_LANDSCAPE,x,y,s);}
static void number(unsigned x,unsigned y,uint32_t value) { game_number3(display_frame(),GAME_LANDSCAPE,x,y,value); }
static void line(int x,int y,int tx,int ty,bool dotted) {
    int dx=tx>x ? tx-x : x-tx,dy=ty>y ? y-ty : ty-y,sx=x<tx ? 1 : -1,sy=y<ty ? 1 : -1,error=dx+dy;
    unsigned step=0;
    for(;;){if(!dotted || !(step++&1))pixel(x,y);if(x==tx && y==ty)break;int e=error*2;if(e>=dy){error+=dy;x+=sx;}if(e<=dx){error+=dx;y+=sy;}}
}
static void crosshair(int x,int y) {
    for(int i=0;i<3;i++){pixel(x-4+i,y-4);pixel(x+4-i,y-4);pixel(x-4+i,y+4);pixel(x+4-i,y+4);pixel(x-4,y-4+i);pixel(x+4,y-4+i);pixel(x-4,y+4-i);pixel(x+4,y+4-i);}
}
static void battle_draw(const TdApp *a) {
    uint8_t *frame=display_frame();
    const TdBattle *b=&a->battle;unsigned length=td_path_length(b->level);
    for(unsigned i=0;i+1<length;i++) {
        unsigned c=td_path_cell(b->level,i),n=td_path_cell(b->level,i+1);
        line((c%12)*8+4,(c/12)*8+4,(n%12)*8+4,(n/12)*8+4,true);
    }
    unsigned entry=td_path_cell(b->level,0),end=td_path_cell(b->level,length-1);
    text((entry%12)*8+1,(entry/12)*8,"E");text((end%12)*8+1,(end/12)*8,"B");
    for(unsigned i=0;i<TD_TOWERS;i++)if(b->towers[i].level) {
        const TdTower *t=&b->towers[i];int x=(t->cell%12)*8+4,y=(t->cell/12)*8+3;
        if(t->type==TD_RAPID){box(x-2,y-2,5,5,false);line(x,y,x,y-3,false);}
        else if(t->type==TD_CANNON){box(x-3,y-2,7,5,false);box(x-1,y-1,3,3,true);}
        else {line(x-2,y-2,x+2,y+2,false);line(x-2,y+2,x+2,y-2,false);line(x,y-3,x,y+3,false);}
        for(unsigned j=0;j<t->level;j++)pixel(x-2+j*2,y+4);
        if(t->fx) {
            if(t->type==TD_CANNON) {
                if(t->fx&TD_CANNON_FLIGHT)box(t->fx_x-1,t->fx_y-1,2,2,true);
                else {int r=6-t->fx;for(int d=-r;d<=r;d++){int e=r-(d<0 ? -d : d);pixel(t->fx_x+d,t->fx_y+e);pixel(t->fx_x+d,t->fx_y-e);}}
            } else line(x,y,t->fx_x,t->fx_y,t->type==TD_FROST);
        }
    }
    for(unsigned i=0;i<TD_ENEMIES;i++)if(b->enemies[i].active) {
        const TdEnemy *e=&b->enemies[i];int x,y;td_enemy_xy(b,i,&x,&y);
        if(e->type==1){line(x-2,y,x,y-2,false);line(x,y-2,x+2,y,false);line(x+2,y,x,y+2,false);line(x,y+2,x-2,y,false);}
        else box(x-(e->type==3 ? 3 : 1),y-(e->type==3 ? 3 : 1),e->type==3 ? 7 : 3,e->type==3 ? 7 : 3,e->type==0);
        if(e->slow){pixel(x-1,y-3);pixel(x+1,y-3);}
        if(b->focus==i)crosshair(x,y);
    }
    if(a->ui==TD_UI_EDIT && a->button==TD_NONE)box(a->x*8,a->y*8,8,8,false);
    game_clear(frame,GAME_LANDSCAPE,96,0,32,64);line(96,0,96,63,false);
    text(98,0,a->save_error ? "SAVE?" : a->ui==TD_UI_PLAY ? "FIGHT" : "PAUSE");
    text(98,9,"H");number(106,10,b->hp);text(98,18,"$");number(106,19,b->money);
    text(98,27,"W");number(106,28,b->wave);number(116,28,td_levels[b->level].waves);
    text(98,35,a->notice==1 ? "ROAD" : b->focus==TD_NONE ? "AUTO" : "LOCK");
    if(a->ui==TD_UI_EDIT){
        box(97,43,31,10,a->button==0);box(97,54,31,10,a->button==1);
        if(a->button==0)game_clear(frame,GAME_LANDSCAPE,98,44,29,8);
        if(a->button==1)game_clear(frame,GAME_LANDSCAPE,98,55,29,8);
        text(101,45,"MENU");text(107,56,"GO");
        if(a->button!=TD_NONE){int y=a->button==0 ? 48 : 59;pixel(98,y-1);pixel(99,y);pixel(98,y+1);}
    } else text(98,47,"OK");
}
static const uint8_t *draw(void) {
    TdApp *a=&td_game_state;if(!a->dirty || (!a->force && a->now-a->last_draw<100))return NULL;
    uint8_t *frame=display_frame();
    memset(frame,0,SCREEN_BYTES);
    if(a->ui==TD_UI_EDIT || a->ui==TD_UI_PLAY)battle_draw(a);
    else {
        const char *title=a->ui==TD_UI_LEVELS ? "TOWER DEFENSE" : a->ui==TD_UI_BUILD ? "BUILD" : a->ui==TD_UI_TOWER ? "TOWER" : a->ui==TD_UI_MENU ? "MENU - PAUSED" : a->ui==TD_UI_ENEMIES ? "LOCK ENEMY" : a->battle.state==TD_WON ? "YOU WIN" : "BASE LOST";
        text(3,1,title);
        if(a->ui==TD_UI_RESULT){text(78,1,"STAR");number(104,2,td_stars(&a->battle));}
        unsigned count=menu_count(a),first=a->selection<5 ? 0 : a->selection-4;
        for(unsigned i=first;i<count && i<first+5;i++) {
            unsigned y=14+(i-first)*8;text(1,y,a->selection==i ? ">" : " ");
            if(a->ui==TD_UI_LEVELS) {
                if(i==TD_LEVELS)text(10,y,"EXIT");
                else {text(10,y,"LEVEL");number(46,y+1,i+1);text(66,y,"STARS");number(101,y+1,(a->stars>>(i*2))&3);}
            } else if(a->ui==TD_UI_BUILD) {
                static const char *const labels[]={"RAPID","CANNON","FROST","BACK"};text(10,y,labels[i]);
                if(i<3){text(61,y,"$");number(70,y+1,td_cost(i,1));}
            } else if(a->ui==TD_UI_TOWER) {
                int t=td_tower_at(&a->battle,a->y*12+a->x);const TdTower *tower=&a->battle.towers[t];
                text(10,y,i==0 ? (tower->level==3 ? "MAX LEVEL" : "UPGRADE") : i==1 ? "SELL" : "BACK");
                if(i<2){text(80,y,"$");number(88,y+1,i==0 ? td_cost(tower->type,tower->level+1) : tower->spent/2);}
            } else if(a->ui==TD_UI_ENEMIES) {
                int e=enemy_at(a,i);if(e<0)text(10,y,"BACK");
                else {text(10,y,"ENEMY");number(46,y+1,e+1);text(65,y,"HP");number(80,y+1,a->battle.enemies[e].hp);}
            } else if(a->ui==TD_UI_MENU) {
                static const char *const labels[]={"BACK","RESTART","LEVEL SELECT","CLEAR TARGET","EXIT"};text(10,y,labels[i]);
            } else {
                static const char *const labels[]={"NEXT LEVEL","RETRY","LEVEL SELECT","EXIT"};text(10,y,labels[i]);
            }
        }
        text(1,56,a->notice ? "NO CASH / MAX / FULL" : "UP/DOWN OK SELECT");
    }
    if(a->save_error && a->ui!=TD_UI_EDIT && a->ui!=TD_UI_PLAY){game_clear(frame,GAME_LANDSCAPE,0,56,128,8);text(0,56,"SAVE FAILED");}
    a->dirty=a->force=false;a->last_draw=a->now;return frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;TdApp *a=&td_game_state;if(!idle || !a->save_pending)return;
    a->save_pending=false;bool okay=td_scores_save(a->stars);if(okay)a->saved=a->stars;
    a->save_error=!okay;a->dirty=a->force=true;
}
const Game tower_defense_game={"TOWER DEFENSE",GAME_LANDSCAPE,init,enter,update,draw,service};
