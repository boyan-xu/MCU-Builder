#include "tower_defense.h"
#include <string.h>
static unsigned distance(unsigned a,unsigned b) {return a>b ? a-b : b-a;}
uint8_t td_path_length(unsigned level) {
    if(level>=TD_LEVELS)return 0;
    const TdLevel *l=&td_levels[level];unsigned n=1;
    for(unsigned i=1;i<l->count;i++)n+=distance(l->points[i]%12,l->points[i-1]%12)+distance(l->points[i]/12,l->points[i-1]/12);
    return n;
}
uint8_t td_path_cell(unsigned level,unsigned step) {
    if(level>=TD_LEVELS)return TD_NONE;
    const TdLevel *l=&td_levels[level];unsigned c=l->points[0];
    if(!step)return c;
    for(unsigned i=1;i<l->count;i++) {
        unsigned to=l->points[i];int delta=c%12==to%12 ? (to>c ? 12 : -12) : (to>c ? 1 : -1);
        unsigned length=distance(c%12,to%12)+distance(c/12,to/12);
        if(step<=length)return (int)c+delta*(int)step;
        step-=length;c=to;
    }
    return TD_NONE;
}
bool td_road(unsigned level,unsigned cell) {
    if(cell>=TD_CELLS)return false;
    unsigned n=td_path_length(level);for(unsigned i=0;i<n;i++)if(td_path_cell(level,i)==cell)return true;
    return false;
}
void td_start(TdBattle *b,unsigned level) {
    memset(b,0,sizeof *b);b->level=level<TD_LEVELS ? level : 0;
    b->hp=100;b->money=td_levels[b->level].money;b->focus=TD_NONE;b->state=TD_READY;
}
int td_tower_at(const TdBattle *b,unsigned cell) {
    for(unsigned i=0;i<TD_TOWERS;i++)if(b->towers[i].level && b->towers[i].cell==cell)return i;
    return -1;
}
unsigned td_cost(unsigned type,unsigned level) {
    static const uint8_t base[3]={35,55,45};
    if(type>TD_FROST || level<1 || level>3)return 0;
    return level==1 ? base[type] : (base[type]*(level+2))/5;
}
bool td_build(TdBattle *b,unsigned cell,unsigned type) {
    unsigned cost=td_cost(type,1);
    if(!cost || b->state>TD_FIGHT || cell>=TD_CELLS || td_road(b->level,cell) || td_tower_at(b,cell)>=0 || b->money<cost)return false;
    for(unsigned i=0;i<TD_TOWERS;i++)if(!b->towers[i].level) {
        b->towers[i]=(TdTower){.spent=cost,.cell=cell,.type=type,.level=1};b->money-=cost;return true;
    }
    return false;
}
bool td_upgrade(TdBattle *b,unsigned tower) {
    if(tower>=TD_TOWERS || b->state>TD_FIGHT)return false;
    TdTower *t=&b->towers[tower];unsigned cost=td_cost(t->type,t->level+1);
    if(!t->level || !cost || b->money<cost)return false;
    t->level++;t->spent+=cost;b->money-=cost;return true;
}
bool td_sell(TdBattle *b,unsigned tower) {
    if(tower>=TD_TOWERS || b->state>TD_FIGHT || !b->towers[tower].level)return false;
    b->money+=b->towers[tower].spent/2;memset(&b->towers[tower],0,sizeof b->towers[tower]);return true;
}
bool td_next_wave(TdBattle *b) {
    if(b->state!=TD_READY || b->wave>=td_levels[b->level].waves)return false;
    b->wave++;b->spawned=0;b->spawn_tick=0;b->state=TD_FIGHT;return true;
}
void td_enemy_xy(const TdBattle *b,unsigned enemy,int *x,int *y) {
    const TdEnemy *e=&b->enemies[enemy];unsigned step=e->progress/256;
    unsigned c=td_path_cell(b->level,step),next=td_path_cell(b->level,step+1);
    if(c==TD_NONE)c=td_path_cell(b->level,td_path_length(b->level)-1);
    *x=(c%12)*8+4;*y=(c/12)*8+4;
    if(next!=TD_NONE){int fraction=e->progress%256;*x+=((int)(next%12)-(int)(c%12))*fraction/32;*y+=((int)(next/12)-(int)(c/12))*fraction/32;}
}
static bool in_range(const TdBattle *b,const TdTower *t,unsigned enemy) {
    int x,y;td_enemy_xy(b,enemy,&x,&y);x-=(t->cell%12)*8+4;y-=(t->cell/12)*8+4;
    int range=(t->type==TD_CANNON ? 26 : 22)+4*t->level;return x*x+y*y<=range*range;
}
int td_target(const TdBattle *b,unsigned tower) {
    if(tower>=TD_TOWERS || !b->towers[tower].level)return -1;
    const TdTower *t=&b->towers[tower];int best=-1;unsigned rank=0;
    for(unsigned i=0;i<TD_ENEMIES;i++)if(b->enemies[i].active && in_range(b,t,i)) {
        unsigned r=(t->type==TD_FROST && !b->enemies[i].slow ? 2 : 0)+(b->focus==i ? 1 : 0);
        if(best<0 || r>rank || (r==rank && b->enemies[i].progress>b->enemies[best].progress)){best=i;rank=r;}
    }
    return best;
}
static void remove_enemy(TdBattle *b,unsigned i,bool killed) {
    for(unsigned j=0;j<TD_TOWERS;j++) {
        TdTower *t=&b->towers[j];
        if(t->level && t->type==TD_CANNON && (t->fx&TD_CANNON_FLIGHT) && t->shot_target==i) {
            int x,y;td_enemy_xy(b,i,&x,&y);t->aim_x=x;t->aim_y=y;t->shot_target=TD_NONE;
        }
    }
    if(killed){unsigned money=b->money+(b->enemies[i].type==3 ? 36 : 12);b->money=money>9999 ? 9999 : money;}
    b->enemies[i].active=0;if(b->focus==i)b->focus=TD_NONE;
}
static void hit(TdBattle *b,unsigned i,unsigned damage,bool slow) {
    TdEnemy *e=&b->enemies[i];if(e->type==2 && damage>1)damage=(damage+1)/2;
    if(e->hp<=damage)remove_enemy(b,i,true);else {e->hp-=damage;if(slow)e->slow=60;}
}
static void cannon_flight(TdBattle *b,TdTower *t) {
    if(t->shot_target<TD_ENEMIES && b->enemies[t->shot_target].active) {
        int x,y;td_enemy_xy(b,t->shot_target,&x,&y);t->aim_x=x;t->aim_y=y;
    }
    int dx=(int)t->aim_x-t->fx_x,dy=(int)t->aim_y-t->fx_y;
    unsigned span=distance(t->aim_x,t->fx_x),vertical=distance(t->aim_y,t->fx_y);
    if(vertical>span)span=vertical;
    if(span>4){t->fx_x+=dx*4/(int)span;t->fx_y+=dy*4/(int)span;}
    else {t->fx_x=t->aim_x;t->fx_y=t->aim_y;}
    unsigned age=(t->fx&127U)+1;
    /* Keep the shell visible across the 100ms drawing interval, even at close range. */
    if(t->fx_x==t->aim_x && t->fx_y==t->aim_y && age>=3) {
        t->fx=4;
        for(unsigned i=0;i<TD_ENEMIES;i++)if(b->enemies[i].active) {
            int x,y;td_enemy_xy(b,i,&x,&y);x-=t->fx_x;y-=t->fx_y;
            if(x*x+y*y<=144)hit(b,i,t->shot_damage,false);
        }
    } else t->fx=TD_CANNON_FLIGHT|age;
}
void td_step(TdBattle *b) {
    if(b->state!=TD_FIGHT)return;
    const TdLevel *l=&td_levels[b->level];unsigned wave=b->wave ? b->wave-1 : 0;
    unsigned count=l->enemies+3*wave;
    if(b->spawn_tick)b->spawn_tick--;
    if(!b->spawn_tick && b->spawned<count)for(unsigned i=0;i<TD_ENEMIES;i++)if(!b->enemies[i].active) {
        unsigned pattern=(b->spawned+b->level)%6;
        unsigned type=pattern<(wave>=3 ? 1U : wave ? 2U : 3U) ? 0 : pattern<4 ? 1 : 2;
        if((b->level==4 || b->level==9) && b->wave==l->waves && b->spawned==count-1)type=3;
        unsigned phase=wave*300/(l->waves-1);
        unsigned hp=(l->health+2*b->wave)*(100+65*phase/100+25*phase*phase/10000)/100;
        hp=type==1 ? hp*3/4 : type==2 ? hp*2 : type==3 ? hp*8 : hp;
        unsigned gap=l->gap>wave+4 ? l->gap-wave : 4;
        b->enemies[i]=(TdEnemy){.hp=hp,.type=type,.active=1};b->spawned++;b->spawn_tick=gap;break;
    }
    for(unsigned i=0;i<TD_TOWERS;i++) {
        TdTower *t=&b->towers[i];if(!t->level)continue;
        if(t->type==TD_CANNON && (t->fx&TD_CANNON_FLIGHT))cannon_flight(b,t);
        else if(t->fx)t->fx--;
        if(t->cooldown)t->cooldown--;
        if(t->type==TD_CANNON && t->fx)continue;
        if(t->cooldown)continue;
        int target=td_target(b,i);if(target<0)continue;
        int x,y;td_enemy_xy(b,target,&x,&y);t->fx_x=x;t->fx_y=y;t->fx=4;
        t->cooldown=(t->type==TD_RAPID ? 10 : t->type==TD_CANNON ? 22 : 18)-t->level;
        unsigned damage=(t->type==TD_RAPID ? 4 : t->type==TD_CANNON ? 9 : 2)*t->level;
        if(t->type==TD_CANNON) {
            t->aim_x=x;t->aim_y=y;t->shot_target=target;t->shot_damage=damage;
            t->fx_x=(t->cell%12)*8+4;t->fx_y=(t->cell/12)*8+3;t->fx=TD_CANNON_FLIGHT;
        } else hit(b,target,damage,t->type==TD_FROST);
    }
    unsigned active=0;
    for(unsigned i=0;i<TD_ENEMIES;i++)if(b->enemies[i].active) {
        TdEnemy *e=&b->enemies[i];unsigned speed=e->type==1 ? 60 : e->type==2 ? 26 : e->type==3 ? 20 : 36;
        if(e->slow){speed/=2;e->slow--;}
        e->progress+=speed;
        if(e->progress>=(td_path_length(b->level)-1)*256U) {
            unsigned damage=e->type==3 ? 25 : 5;b->hp=b->hp>damage ? b->hp-damage : 0;
            remove_enemy(b,i,false);if(!b->hp){b->state=TD_LOST;b->focus=TD_NONE;return;}
        } else active++;
    }
    bool shells=false;
    for(unsigned i=0;i<TD_TOWERS;i++)if(b->towers[i].level && b->towers[i].type==TD_CANNON && b->towers[i].fx)shells=true;
    if(!active && b->spawned>=count && !shells) {
        b->state=b->wave==l->waves ? TD_WON : TD_READY;
        for(unsigned i=0;i<TD_TOWERS;i++)b->towers[i].fx=0;
    }
}
unsigned td_stars(const TdBattle *b) {return b->state!=TD_WON ? 0 : b->hp>=90 ? 3 : b->hp>=50 ? 2 : 1;}
