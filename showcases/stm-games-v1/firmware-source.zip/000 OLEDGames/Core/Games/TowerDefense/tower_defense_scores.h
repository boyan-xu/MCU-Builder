#ifndef TOWER_DEFENSE_SCORES_H
#define TOWER_DEFENSE_SCORES_H
#include <stdbool.h>
#include <stdint.h>
#define TD_SCORE_BASE 0x0800C800U
#define TD_SCORE_PAGE 1024U
#define TD_SCORE_MASK 0xFFFFFU
#define TD_SCORE_COMMIT 0x7D57A401U
uint32_t td_scores_load(void);
bool td_scores_save(uint32_t stars);
#endif
