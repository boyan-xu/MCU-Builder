#ifndef TOWER_DEFENSE_H
#define TOWER_DEFENSE_H
#include <stdbool.h>
#include <stdint.h>
#define TD_LEVELS 10
#define TD_COLS 12
#define TD_CELLS 96
#define TD_ENEMIES 24
#define TD_TOWERS 12
#define TD_NONE 255
#define TD_CANNON_FLIGHT 128U
typedef enum { TD_READY, TD_FIGHT, TD_WON, TD_LOST } TdState;
typedef enum { TD_RAPID, TD_CANNON, TD_FROST } TdType;
typedef struct { uint16_t progress, hp, slow; uint8_t type, active; } TdEnemy;
typedef struct {
    uint16_t spent;
    uint8_t cell,type,level,cooldown,fx,fx_x,fx_y;
    uint8_t aim_x,aim_y,shot_target,shot_damage;
} TdTower;
typedef struct {
    uint8_t points[8], count, waves, enemies, gap, health;
    uint16_t money;
} TdLevel;
typedef struct {
    TdEnemy enemies[TD_ENEMIES];
    TdTower towers[TD_TOWERS];
    uint16_t money, spawn_tick;
    uint8_t level,wave,hp,spawned,focus;
    TdState state;
} TdBattle;
extern const TdLevel td_levels[TD_LEVELS];
uint8_t td_path_length(unsigned level);
uint8_t td_path_cell(unsigned level,unsigned step);
bool td_road(unsigned level,unsigned cell);
void td_start(TdBattle *b,unsigned level);
int td_tower_at(const TdBattle *b,unsigned cell);
unsigned td_cost(unsigned type,unsigned level);
bool td_build(TdBattle *b,unsigned cell,unsigned type);
bool td_upgrade(TdBattle *b,unsigned tower);
bool td_sell(TdBattle *b,unsigned tower);
bool td_next_wave(TdBattle *b);
void td_enemy_xy(const TdBattle *b,unsigned enemy,int *x,int *y);
int td_target(const TdBattle *b,unsigned tower);
void td_step(TdBattle *b);
unsigned td_stars(const TdBattle *b);
#endif
