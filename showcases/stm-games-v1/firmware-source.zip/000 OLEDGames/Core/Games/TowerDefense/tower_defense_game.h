#ifndef TOWER_DEFENSE_GAME_H
#define TOWER_DEFENSE_GAME_H
#include "game.h"
#include "tower_defense.h"
typedef enum {TD_UI_LEVELS,TD_UI_EDIT,TD_UI_PLAY,TD_UI_BUILD,TD_UI_TOWER,TD_UI_MENU,TD_UI_ENEMIES,TD_UI_RESULT} TdUI;
typedef struct {
    TdBattle battle;
    uint32_t stars,saved,now,last_tick,last_draw;
    TdUI ui;
    uint8_t x,y,button,selection,notice;
    bool dirty,force,gate,save_pending,save_error;
} TdApp;
extern TdApp td_game_state;
extern const Game tower_defense_game;
#endif
