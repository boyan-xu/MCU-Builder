#include "game2048_game.h"
#include "game2048_highscore.h"
#include "display.h"
Game2048App game2048_game_state;
static void init(uint32_t seed) {
    game2048_app_init(&game2048_game_state,seed);
    game2048_game_state.best=game2048_game_state.saved_best=game2048_highscore_load();
}
static void enter(uint32_t now){game2048_app_enter(&game2048_game_state,now);}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    Game2048Page before=game2048_game_state.page;
    game2048_app_update(&game2048_game_state,pressed,held,now);
    if(game2048_game_state.exit_requested)return GAME_EXIT;
    return before!=game2048_game_state.page?GAME_PAGE_CHANGED:GAME_STAY;
}
static const uint8_t *draw(void) {
    if(!game2048_game_state.dirty)return NULL;
    uint8_t *frame=display_frame();
    game2048_render(&game2048_game_state,frame);game2048_game_state.dirty=false;return frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;
    if(!idle || game2048_game_state.page==GAME2048_PLAYING || !game2048_game_state.save_requested)return;
    game2048_game_state.save_requested=false;
    game2048_game_state.save_failed=!game2048_highscore_save(game2048_game_state.best);
    if(!game2048_game_state.save_failed)game2048_game_state.saved_best=game2048_game_state.best;
    game2048_game_state.dirty=true;
}
const Game game2048_game={"2048",GAME_LANDSCAPE,init,enter,update,draw,service};
