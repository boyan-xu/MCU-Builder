#ifndef GAME2048_GAME_H
#define GAME2048_GAME_H
#include "game.h"
#include "game2048.h"
extern Game2048App game2048_game_state;
extern const Game game2048_game;
#endif
