#include "game2048.h"
#include "game_menu.h"
#include <string.h>

enum { SLIDE_MS=160, MERGE_MS=100, SPAWN_MS=100, FRAME_MS=40 };
static uint32_t random_next(Game2048App *a) {
    uint32_t x=a->rng;x^=x<<13;x^=x>>17;x^=x<<5;return a->rng=x;
}
static unsigned spawn_tile(Game2048App *a) {
    uint8_t empty[16];unsigned count=0;
    for(unsigned r=0;r<4;r++)for(unsigned c=0;c<4;c++)
        if(!a->cells[r][c])empty[count++]=(uint8_t)(r*4+c);
    if(!count)return 16;
    unsigned cell=empty[random_next(a)%count];
    a->cells[cell/4][cell%4]=random_next(a)%10==0?4U:2U;
    return cell;
}
bool game2048_spawn(Game2048App *a) {return spawn_tile(a)<16;}
bool game2048_has_moves(const Game2048App *a) {
    for(unsigned r=0;r<4;r++)for(unsigned c=0;c<4;c++) {
        uint32_t v=a->cells[r][c];
        if(!v)return true;
        if(v<=UINT32_MAX/2 && ((r<3 && v==a->cells[r+1][c]) || (c<3 && v==a->cells[r][c+1])))return true;
    }
    return false;
}
static bool move_tiles(Game2048App *a,uint8_t direction,bool animate) {
    if(direction!=KEY_LEFT && direction!=KEY_RIGHT && direction!=KEY_UP && direction!=KEY_DOWN)return false;
    Game2048Animation next={0};
    if(animate)memcpy(next.before,a->cells,sizeof(a->cells));
    bool changed=false;uint32_t points=0;
    for(unsigned line=0;line<4;line++) {
        uint32_t *cells[4],values[4]={0},out[4]={0};uint8_t source[4],indices[4];unsigned count=0,n=0;
        for(unsigned i=0;i<4;i++) {
            unsigned pos=(direction==KEY_RIGHT || direction==KEY_DOWN)?3-i:i;
            unsigned index=(direction==KEY_LEFT || direction==KEY_RIGHT)?line*4+pos:pos*4+line;
            indices[i]=(uint8_t)index;cells[i]=&a->cells[index/4][index%4];
            if(*cells[i]){source[count]=(uint8_t)index;values[count++]=*cells[i];}
        }
        for(unsigned i=0;i<count;i++) {
            uint32_t v=values[i];unsigned destination=indices[n];
            if(animate)next.target[source[i]]=(uint8_t)destination;
            if(i+1<count && v==values[i+1] && v<=UINT32_MAX/2) {
                if(animate){next.target[source[i+1]]=(uint8_t)destination;next.merged|=(uint16_t)(1U<<destination);}
                v*=2;i++;points=UINT32_MAX-points<v?UINT32_MAX:points+v;
            }
            out[n++]=v;
        }
        for(unsigned i=0;i<4;i++)if(*cells[i]!=out[i]){*cells[i]=out[i];changed=true;}
    }
    if(changed) {
        a->score=UINT32_MAX-a->score<points?UINT32_MAX:a->score+points;
        if(animate){next.phase=GAME2048_ANIM_SLIDE;a->animation=next;}
    }
    return changed;
}
bool game2048_move(Game2048App *a,uint8_t direction) {return move_tiles(a,direction,false);}
static void page(Game2048App *a,Game2048Page next) {
    a->page=next;a->selection=0;a->gate=31;a->dirty=true;
}
static void save_boundary(Game2048App *a) {
    if(a->best>a->saved_best || a->save_failed)a->save_requested=true;
}
void game2048_app_enter(Game2048App *a,uint32_t now) {
    (void)now;a->exit_requested=false;memset(&a->animation,0,sizeof(a->animation));page(a,GAME2048_TITLE);
}
void game2048_app_init(Game2048App *a,uint32_t seed) {
    memset(a,0,sizeof(*a));a->rng=seed?seed:1;game2048_app_enter(a,0);
}
static void new_game(Game2048App *a,uint32_t now) {
    memset(a->cells,0,sizeof(a->cells));memset(&a->animation,0,sizeof(a->animation));
    a->score=0;a->won=false;
    unsigned first=spawn_tile(a),second=spawn_tile(a);
    a->animation.spawned=(uint16_t)((1U<<first)|(1U<<second));
    a->animation.phase=GAME2048_ANIM_SPAWN;a->animation.tick=now;page(a,GAME2048_PLAYING);
}
static void finish_move(Game2048App *a) {
    a->gate=31;
    if(!a->won)for(unsigned r=0;r<4;r++)for(unsigned c=0;c<4;c++)
        if(a->cells[r][c]>=2048){a->won=true;save_boundary(a);page(a,GAME2048_WON);return;}
    if(!game2048_has_moves(a)){save_boundary(a);page(a,GAME2048_OVER);}
}
static void animation_step(Game2048App *a,uint32_t now) {
    Game2048Animation *m=&a->animation;
    uint32_t delta=now-m->tick;m->tick=now;
    unsigned old_frame=m->elapsed/FRAME_MS;Game2048AnimPhase old_phase=m->phase;
    while(delta && m->phase!=GAME2048_ANIM_NONE) {
        unsigned duration=m->phase==GAME2048_ANIM_SLIDE?SLIDE_MS:m->phase==GAME2048_ANIM_MERGE?MERGE_MS:SPAWN_MS;
        unsigned left=duration-m->elapsed;
        if(delta<left){m->elapsed+=(uint16_t)delta;break;}
        delta-=left;m->elapsed=0;
        if(m->phase==GAME2048_ANIM_SLIDE)m->phase=m->merged?GAME2048_ANIM_MERGE:GAME2048_ANIM_SPAWN;
        else if(m->phase==GAME2048_ANIM_MERGE)m->phase=GAME2048_ANIM_SPAWN;
        else {m->phase=GAME2048_ANIM_NONE;finish_move(a);}
    }
    if(m->phase!=old_phase || m->elapsed/FRAME_MS!=old_frame)a->dirty=true;
}
void game2048_app_update(Game2048App *a,uint8_t pressed,uint8_t held,uint32_t now) {
    if(a->gate) {
        if(a->animation.phase)a->animation.tick=now;
        if(held)return;
        a->gate=0;pressed=0;
    }
    if(a->exit_requested)return;
    if(a->page==GAME2048_PLAYING) {
        if(pressed&KEY_OK){a->animation.tick=now;save_boundary(a);page(a,GAME2048_PAUSED);return;}
        /* Discard presses even on the update that finishes an animation. */
        if(a->animation.phase){animation_step(a,now);return;}
        uint8_t directions=(pressed|held)&(KEY_UP|KEY_DOWN|KEY_LEFT|KEY_RIGHT);
        if(directions&(directions-1U))return;
        if(move_tiles(a,pressed,true)) {
            unsigned cell=spawn_tile(a);a->animation.spawned=(uint16_t)(1U<<cell);a->animation.tick=now;
            if(a->score>a->best)a->best=a->score;
            a->dirty=true;
        } else if(!game2048_has_moves(a)){save_boundary(a);page(a,GAME2048_OVER);}
        return;
    }
    if(a->animation.phase)a->animation.tick=now;
    bool can_continue=a->page==GAME2048_PAUSED || a->page==GAME2048_WON;
    unsigned count=can_continue?3:2;
    if(pressed==KEY_UP || pressed==KEY_DOWN) {
        a->selection=(uint8_t)((a->selection+(pressed==KEY_UP?count-1:1))%count);a->dirty=true;
    } else if(pressed&KEY_OK) {
        if(can_continue && a->selection==0) {
            if(a->animation.phase || game2048_has_moves(a)){a->animation.tick=now;page(a,GAME2048_PLAYING);}
            else {save_boundary(a);page(a,GAME2048_OVER);}
        } else if(a->selection==(can_continue?1U:0U))new_game(a,now);
        else {save_boundary(a);memset(&a->animation,0,sizeof(a->animation));page(a,GAME2048_TITLE);a->exit_requested=true;}
    }
}
static void number(uint32_t value,char *out) {game_decimal(out,value);}
static void pixel(uint8_t *frame,int x,int y,bool set) {
    if(x<0 || x>=64 || y<0 || y>=64)return;
    uint8_t *p=&frame[(y/8)*128+x],mask=(uint8_t)(1U<<(y%8));
    if(set)*p|=mask;else *p&=(uint8_t)~mask;
}
static void square(uint8_t *frame,int x,int y,unsigned size,bool fill,bool set) {
    if(set)game_box(frame,GAME_LANDSCAPE,x,y,(int)size,(int)size,fill);
    else game_clear(frame,GAME_LANDSCAPE,(unsigned)x,(unsigned)y,size,size);
}
static void tile_text(uint8_t *frame,int x,int y,uint32_t value,bool inverse) {
    static const uint8_t exponent_glyph[5]={2,5,0,0,0};
    char label[11];number(value,label);
    if(value>9999) {
        unsigned exponent=0;uint32_t v=value;while(v>1){exponent++;v>>=1;}
        label[0]='2';label[1]='^';number(exponent,label+2);
    }
    unsigned length=(unsigned)strlen(label);x+=(15-(int)(length*4-1))/2;y+=5;
    for(unsigned i=0;i<length;i++) {
        const uint8_t *glyph=label[i]=='^'?exponent_glyph:game_digits3[(unsigned)(label[i]-'0')];
        for(unsigned dy=0;dy<5;dy++)for(unsigned dx=0;dx<3;dx++)
            if(glyph[dy]&(4U>>dx))pixel(frame,x+(int)(i*4+dx),y+(int)dy,!inverse);
    }
}
static void board_render(const Game2048App *a,uint8_t *frame) {
    const Game2048Animation *m=&a->animation;
    for(unsigned n=0;n<4;n++)for(unsigned i=0;i<64;i++){
        pixel(frame,n*16+15,i,true);pixel(frame,i,n*16+15,true);
    }
    for(unsigned x=0;x<64;x++)pixel(frame,x,0,true);
    if(m->phase==GAME2048_ANIM_SLIDE) {
        unsigned remaining=SLIDE_MS-m->elapsed;
        unsigned progress=256-remaining*remaining*256/(SLIDE_MS*SLIDE_MS);
        for(unsigned pass=0;pass<2;pass++)for(unsigned i=0;i<16;i++)if(m->before[i/4][i%4]) {
            unsigned target=m->target[i];
            int x=(int)(((i%4)*16*(256-progress)+(target%4)*16*progress+128)/256);
            int y=(int)(((i/4)*16*(256-progress)+(target/4)*16*progress+128)/256);
            if(!pass)square(frame,x,y,15,true,false);
            else tile_text(frame,x,y,m->before[i/4][i%4],false);
        }
        return;
    }
    for(unsigned i=0;i<16;i++) {
        uint32_t value=a->cells[i/4][i%4];if(!value)continue;
        int x=(int)(i%4)*16,y=(int)(i/4)*16;uint16_t bit=(uint16_t)(1U<<i);
        if(m->phase!=GAME2048_ANIM_NONE && (m->spawned&bit)) {
            if(m->phase==GAME2048_ANIM_SPAWN) {
                unsigned size=(3+12*m->elapsed/SPAWN_MS)|1U;
                square(frame,x,y,15,true,false);square(frame,x+7-(int)size/2,y+7-(int)size/2,size,false,true);
                if(size>=7)tile_text(frame,x,y,value,false);
            }
            continue;
        }
        if(m->phase==GAME2048_ANIM_MERGE && (m->merged&bit)) {
            bool inverse=m->elapsed<50;
            square(frame,x,y,15,true,inverse);tile_text(frame,x,y,value,inverse);
            if(!inverse) {
                unsigned size=11+4*(MERGE_MS-m->elapsed)/50;
                square(frame,x+7-(int)size/2,y+7-(int)size/2,size,false,true);
            }
        } else tile_text(frame,x,y,value,false);
    }
}
void game2048_render(const Game2048App *a,uint8_t frame[1024]) {
    memset(frame,0,1024);char label[11];
    if(a->page==GAME2048_PLAYING) {
        board_render(a,frame);
        game_text(frame,GAME_LANDSCAPE,68,0,a->save_failed?"SAVE":"2048");
        if(a->save_failed)game_text(frame,GAME_LANDSCAPE,68,8,"FAILED");
        game_text(frame,GAME_LANDSCAPE,68,16,"SCORE");number(a->score,label);game_text(frame,GAME_LANDSCAPE,68,24,label);
        game_text(frame,GAME_LANDSCAPE,68,40,"BEST");number(a->best,label);game_text(frame,GAME_LANDSCAPE,68,48,label);
        game_text(frame,GAME_LANDSCAPE,68,56,"OK MENU");
        return;
    }
    const char *title=a->page==GAME2048_TITLE?"2048":a->page==GAME2048_PAUSED?"PAUSED":a->page==GAME2048_WON?"YOU WIN":"GAME OVER";
    game_text(frame,GAME_LANDSCAPE,(128-(unsigned)strlen(title)*6)/2,0,title);
    game_text(frame,GAME_LANDSCAPE,0,12,"SCORE");number(a->score,label);game_text(frame,GAME_LANDSCAPE,42,12,label);
    game_text(frame,GAME_LANDSCAPE,0,22,"BEST");number(a->best,label);game_text(frame,GAME_LANDSCAPE,42,22,label);
    bool can_continue=a->page==GAME2048_PAUSED || a->page==GAME2048_WON;
    const char *choices[]={"CONTINUE","NEW GAME","EXIT"};
    unsigned first=can_continue?0:1,count=can_continue?3:2;
    for(unsigned i=0;i<count;i++) {
        game_text(frame,GAME_LANDSCAPE,12,32+i*8,i==a->selection?">":" ");
        game_text(frame,GAME_LANDSCAPE,24,32+i*8,choices[first+i]);
    }
    game_text(frame,GAME_LANDSCAPE,0,56,a->save_failed?"SAVE FAILED":"UP/DOWN  OK SELECT");
}
