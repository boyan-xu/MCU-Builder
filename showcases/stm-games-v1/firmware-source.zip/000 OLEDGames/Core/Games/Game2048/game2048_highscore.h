#ifndef GAME2048_HIGHSCORE_H
#define GAME2048_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define GAME2048_HIGHSCORE_BASE 0x0800D800U
#define GAME2048_HIGHSCORE_PAGE 1024U
#define GAME2048_HIGHSCORE_COMMIT 0x2048C0DEU
uint32_t game2048_highscore_load(void);
bool game2048_highscore_save(uint32_t score);
#endif
