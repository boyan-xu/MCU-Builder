#include "game2048_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={GAME2048_HIGHSCORE_BASE,GAME2048_HIGHSCORE_COMMIT,UINT32_MAX};
uint32_t game2048_highscore_load(void) {return score_journal_load(&journal);}
bool game2048_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
