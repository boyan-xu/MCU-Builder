#ifndef GAME2048_H
#define GAME2048_H
#include <stdbool.h>
#include <stdint.h>
#include "buttons.h"
typedef enum { GAME2048_TITLE, GAME2048_PLAYING, GAME2048_PAUSED, GAME2048_WON, GAME2048_OVER } Game2048Page;
typedef enum { GAME2048_ANIM_NONE, GAME2048_ANIM_SLIDE, GAME2048_ANIM_MERGE, GAME2048_ANIM_SPAWN } Game2048AnimPhase;
typedef struct {
    uint32_t before[4][4], tick;
    uint8_t target[16];
    uint16_t merged, spawned, elapsed;
    Game2048AnimPhase phase;
} Game2048Animation;
typedef struct {
    Game2048Animation animation;
    uint32_t cells[4][4], score, best, saved_best, rng;
    Game2048Page page;
    uint8_t selection, gate;
    bool dirty, won, exit_requested, save_requested, save_failed;
} Game2048App;
bool game2048_move(Game2048App *app, uint8_t direction);
bool game2048_has_moves(const Game2048App *app);
bool game2048_spawn(Game2048App *app);
void game2048_app_init(Game2048App *app, uint32_t seed);
void game2048_app_enter(Game2048App *app, uint32_t now);
void game2048_app_update(Game2048App *app, uint8_t pressed, uint8_t held, uint32_t now);
void game2048_render(const Game2048App *app, uint8_t frame[1024]);
#endif
