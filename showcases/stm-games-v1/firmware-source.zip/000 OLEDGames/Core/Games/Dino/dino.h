#ifndef DINO_H
#define DINO_H
#include <stdbool.h>
#include <stdint.h>
#include "buttons.h"
#define DINO_STEP_MS 20U
#define DINO_MAX_SCORE 99999U
#define DINO_MAX_SPEED 896U
typedef enum { DINO_TITLE, DINO_PLAYING, DINO_PAUSED, DINO_OVER } DinoPage;
typedef struct { int32_t x; uint8_t kind, width, height, top; bool active; } DinoObstacle;
typedef struct {
    DinoPage page;
    uint8_t selection, gate;
    bool dirty, duck, exit_requested, save_requested, save_failed;
    bool jump_held, reached_min_height;
    uint32_t rng, last_tick, distance, score, best, steps;
    int32_t height, velocity, spawn_distance;
    uint16_t speed;
    DinoObstacle obstacles[2];
} DinoApp;
void dino_app_init(DinoApp *app, uint32_t seed);
void dino_app_enter(DinoApp *app, uint32_t now);
void dino_app_update(DinoApp *app, uint8_t pressed, uint8_t held, uint32_t now);
void dino_render(const DinoApp *app, uint8_t frame[1024]);
#endif
