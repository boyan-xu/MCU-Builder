#include "dino_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={DINO_HIGHSCORE_BASE,DINO_HIGHSCORE_COMMIT,99999};
uint32_t dino_highscore_load(void) {return score_journal_load(&journal);}
bool dino_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
