#ifndef DINO_GAME_H
#define DINO_GAME_H
#include "game.h"
#include "dino.h"
extern DinoApp dino_game_state;
extern const Game dino_game;
#endif
