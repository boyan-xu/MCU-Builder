#include "dino_game.h"
#include "dino_highscore.h"
#include "display.h"
DinoApp dino_game_state;
static void init(uint32_t seed) {
    dino_app_init(&dino_game_state,seed);dino_game_state.best=dino_highscore_load();
}
static void enter(uint32_t now) { dino_app_enter(&dino_game_state,now); }
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    DinoPage before=dino_game_state.page;
    dino_app_update(&dino_game_state,pressed,held,now);
    if(dino_game_state.exit_requested)return GAME_EXIT;
    return before!=dino_game_state.page?GAME_PAGE_CHANGED:GAME_STAY;
}
static const uint8_t *draw(void) {
    if(!dino_game_state.dirty)return NULL;
    uint8_t *frame=display_frame();
    dino_render(&dino_game_state,frame);dino_game_state.dirty=false;return frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;
    if(!idle || dino_game_state.page==DINO_PLAYING || !dino_game_state.save_requested)return;
    dino_game_state.save_requested=false;
    dino_game_state.save_failed=!dino_highscore_save(dino_game_state.best);
    dino_game_state.dirty=true;
}
const Game dino_game={"DINO RUN",GAME_LANDSCAPE,init,enter,update,draw,service};
