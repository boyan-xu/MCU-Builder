#ifndef DINO_HIGHSCORE_H
#define DINO_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define DINO_HIGHSCORE_BASE 0x0800E000UL
#define DINO_HIGHSCORE_PAGE 1024U
#define DINO_HIGHSCORE_COMMIT 0xD170C0DEUL
uint32_t dino_highscore_load(void);
bool dino_highscore_save(uint32_t score);
#endif
