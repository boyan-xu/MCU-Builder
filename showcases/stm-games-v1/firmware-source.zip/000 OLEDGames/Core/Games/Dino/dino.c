#include "dino.h"
#include "game_menu.h"
#include <string.h>
enum { DINO_BODY_W=14, DINO_BODY_H=15, DINO_DUCK_W=19, DINO_DUCK_H=9, DINO_GROUND=55 };
/* Converted from Chromium's original sprite; see THIRD_PARTY_NOTICES.txt. */
static const uint16_t dino_sprite_jump[]={0x1F00,0x3E80,0x3F80,0x3F80,0x380,0x1FC1,0x3E1,0x7FB,0x3FF,0x3FE,0x1FE,0xFC,0xF8,0x98,0x98};
static const uint16_t dino_sprite_run1[]={0x1F00,0x3E80,0x3F80,0x3F80,0x380,0x1FC1,0x3E1,0x7FB,0x3FF,0x3FE,0x1FE,0xFC,0x1B8,0x18,0x18};
static const uint16_t dino_sprite_run2[]={0x1F00,0x3E80,0x3F80,0x3F80,0x380,0x1FC1,0x3E1,0x7FB,0x3FF,0x3FE,0x1FE,0xFC,0xD8,0xB0,0x80};
static const uint16_t dino_sprite_crash[]={0x1F00,0x3C80,0x3F80,0x3F80,0x3F80,0x1FC1,0x3E1,0x7FB,0x3FF,0x3FE,0x1FE,0xFC,0xF8,0x98,0x98};
static const uint32_t dino_sprite_duck1[]={0x3E001,0x7DFFF,0x7FFFE,0x7FFFC,0xFFF8,0x3E7F8,0x4C0,0x50,0x40};
static const uint32_t dino_sprite_duck2[]={0x3E001,0x7DFFF,0x7FFFE,0x7FFFC,0xFFF8,0x3E7F8,0x5B0,0x10,0x10};
typedef struct { uint8_t x,y,width,height; } DinoBox;
static const DinoBox dino_run_boxes[]={{7,0,6,5},{0,6,10,3},{3,12,5,2},{0,8,10,1},{1,10,7,1},{2,11,6,2}};
static const DinoBox dino_duck_boxes[]={{0,0,19,8}};
static uint32_t random_next(DinoApp *a) {
    uint32_t x=a->rng;x^=x<<13;x^=x>>17;x^=x<<5;return a->rng=x;
}
static void best_update(DinoApp *a) {
    if(a->score>a->best){a->best=a->score;a->save_requested=true;}
    if(a->save_failed)a->save_requested=true;
}
static void page(DinoApp *a,DinoPage next,uint32_t now) {
    a->page=next;a->selection=0;a->gate=31;a->last_tick=now;a->dirty=true;
    a->jump_held=false;
}
void dino_app_enter(DinoApp *a,uint32_t now) {
    a->exit_requested=false;a->height=a->velocity=0;a->duck=false;a->reached_min_height=false;
    page(a,DINO_TITLE,now);
}
void dino_app_init(DinoApp *a,uint32_t seed) {
    memset(a,0,sizeof(*a));a->rng=seed?seed:1;a->speed=512;dino_app_enter(a,0);
}
static void new_run(DinoApp *a,uint32_t now) {
    uint32_t seed=a->rng,best=a->best;bool pending=a->save_requested,failed=a->save_failed;
    dino_app_init(a,seed);a->best=best;a->save_requested=pending;a->save_failed=failed;
    a->spawn_distance=160*256;page(a,DINO_PLAYING,now);
}
static bool hit(const DinoApp *a,const DinoObstacle *o) {
    const DinoBox *boxes=a->duck?dino_duck_boxes:dino_run_boxes;
    unsigned count=a->duck?1U:sizeof(dino_run_boxes)/sizeof(dino_run_boxes[0]);
    int player_top=DINO_GROUND-(a->duck?DINO_DUCK_H:DINO_BODY_H)-a->height/256;
    int obstacle_left=o->x/256;
    for(unsigned i=0;i<count;i++) {
        const DinoBox *b=&boxes[i];
        int left=16+b->x,right=left+b->width,top=player_top+b->y,bottom=top+b->height;
        if(left<obstacle_left)left=obstacle_left;
        if(right>obstacle_left+o->width)right=obstacle_left+o->width;
        if(top<o->top)top=o->top;
        if(bottom>o->top+o->height)bottom=o->top+o->height;
        /* One-pixel contact is a graze; the body must overlap in both axes. */
        if(right-left>1 && bottom-top>1)return true;
    }
    return false;
}
static void step(DinoApp *a,uint8_t held,uint32_t now) {
    a->steps++;a->distance+=a->speed;
    a->score=a->distance/2048U;if(a->score>DINO_MAX_SCORE)a->score=DINO_MAX_SCORE;
    uint32_t speed=512+a->score/4;a->speed=(uint16_t)(speed>DINO_MAX_SPEED?DINO_MAX_SPEED:speed);
    if(a->height || a->velocity) {
        a->height+=a->velocity;a->velocity-=77;
        if(a->height>=11*256)a->reached_min_height=true;
        if(a->height>22*256 && a->velocity>538)a->velocity=538;
        if(a->height<=0){a->height=0;a->velocity=0;a->reached_min_height=false;}
    }
    a->duck=(held&KEY_DOWN) && !a->height && !a->velocity;
    a->spawn_distance-=a->speed;
    for(unsigned i=0;i<2;i++) {
        DinoObstacle *o=&a->obstacles[i];if(!o->active)continue;
        o->x-=a->speed;
        if(o->x+o->width*256<0)o->active=false;
        else if(hit(a,o)){best_update(a);page(a,DINO_OVER,now);return;}
    }
    if(a->spawn_distance<=0)for(unsigned i=0;i<2;i++)if(!a->obstacles[i].active) {
        uint32_t r=random_next(a);unsigned kind=r%(a->score>=60?4U:3U);
        static const uint8_t widths[]={5,8,13,11},heights[]={10,14,12,6};
        DinoObstacle *o=&a->obstacles[i];o->active=true;o->x=128*256;
        o->kind=(uint8_t)kind;o->width=widths[kind];o->height=heights[kind];
        o->top=kind==3?((r&16)?30:40):DINO_GROUND-o->height;
        /* Even at top speed the gap exceeds a full high-jump flight plus obstacle width. */
        a->spawn_distance=(int32_t)(96+(a->speed>>4)+(random_next(a)&31))*256;
        break;
    }
    a->dirty=true;
}
void dino_app_update(DinoApp *a,uint8_t pressed,uint8_t held,uint32_t now) {
    if(a->gate) {
        a->last_tick=now;
        if(held)return;
        a->gate=0;pressed=0;
    }
    if(a->page!=DINO_PLAYING) {
        unsigned count=a->page==DINO_PAUSED?3:2;
        if(pressed==KEY_UP || pressed==KEY_DOWN) {
            a->selection=(uint8_t)(pressed==KEY_UP?(a->selection+count-1)%count:(a->selection+1)%count);
            a->dirty=true;
        } else if(pressed&KEY_OK) {
            if((a->page==DINO_PAUSED && a->selection==2) || (a->page!=DINO_PAUSED && a->selection==1)) {
                best_update(a);a->exit_requested=true;
            } else if(a->page==DINO_PAUSED && a->selection==0)page(a,DINO_PLAYING,now);
            else new_run(a,now);
        }
        return;
    }
    if(pressed&KEY_OK){best_update(a);page(a,DINO_PAUSED,now);return;}
    if((pressed&KEY_UP) && !a->height && !a->velocity && !(held&KEY_DOWN)) {
        a->velocity=1184;a->reached_min_height=false;
    }
    if(a->jump_held && !(held&KEY_UP) && a->reached_min_height && a->velocity>538)a->velocity=538;
    a->jump_held=(held&KEY_UP)!=0;
    uint32_t elapsed=now-a->last_tick;
    if(elapsed>5*DINO_STEP_MS){elapsed=5*DINO_STEP_MS;a->last_tick=now-elapsed;}
    while(elapsed>=DINO_STEP_MS && a->page==DINO_PLAYING) {
        a->last_tick+=DINO_STEP_MS;elapsed-=DINO_STEP_MS;step(a,held,now);
    }
}
static void pixel(uint8_t *f,int x,int y,bool on) {
    if(x<0 || x>=128 || y<0 || y>=64)return;
    uint8_t mask=(uint8_t)(1U<<(y&7));uint8_t *out=&f[(y/8)*128+x];
    if(on)*out|=mask;else *out&=(uint8_t)~mask;
}
static void line(uint8_t *f,int x,int y,int length) {
    for(int i=0;i<length;i++)pixel(f,x+i,y,true);
}
static void cactus(uint8_t *f,int x,int y,unsigned width,unsigned height) {
    for(unsigned row=0;row<height;row++) {
        line(f,x+(int)width/2-1,y+(int)row,3);
        if(row>height/3 && row<height*2/3) {
            pixel(f,x,y+(int)row,true);pixel(f,x+(int)width-1,y+(int)row-2,true);
        }
        if(row==height*2/3-1)line(f,x,y+(int)row,(int)width);
    }
}
static void dinosaur(uint8_t *f,const DinoApp *a) {
    bool duck=a->duck && a->page!=DINO_OVER && a->page!=DINO_TITLE;
    unsigned width=duck?DINO_DUCK_W:DINO_BODY_W,height=duck?DINO_DUCK_H:DINO_BODY_H;
    int top=DINO_GROUND-(int)height-a->height/256;
    const uint16_t *pose=dino_sprite_jump;
    if(a->page==DINO_OVER)pose=dino_sprite_crash;
    else if(!a->height && !a->velocity && a->page!=DINO_TITLE)
        pose=((a->steps*12U/50U)&1U)?dino_sprite_run2:dino_sprite_run1;
    const uint32_t *crouch=((a->steps*8U/50U)&1U)?dino_sprite_duck2:dino_sprite_duck1;
    for(unsigned y=0;y<height;y++) {
        uint32_t row=duck?crouch[y]:pose[y];
        for(unsigned x=0;x<width;x++)if(row&(1U<<x))pixel(f,16+(int)x,top+(int)y,true);
    }
}
static void number(uint8_t *f,unsigned x,uint32_t value) {
    char out[6];out[5]=0;
    for(int i=4;i>=0;i--){out[i]=(char)('0'+value%10);value/=10;}
    game_text(f,GAME_LANDSCAPE,x,0,out);
}
static void choice(uint8_t *f,unsigned x,unsigned y,const char *s,bool selected) {
    game_text(f,GAME_LANDSCAPE,x,y,selected?">":" ");game_text(f,GAME_LANDSCAPE,x+12,y,s);
}
void dino_render(const DinoApp *a,uint8_t f[1024]) {
    memset(f,0,1024);
    uint32_t scroll=a->distance/256;
    for(unsigned c=0;c<2;c++) {
        int x=(int)((c*73+150-scroll/4)%160)-20,y=12+(int)c*7;
        line(f,x+5,y,5);line(f,x+3,y+1,2);pixel(f,x+10,y+1,true);
        line(f,x+1,y+2,3);line(f,x+11,y+2,4);
        pixel(f,x,y+3,true);line(f,x+15,y+3,3);line(f,x,y+4,18);
    }
    line(f,0,DINO_GROUND+1,128);
    for(unsigned i=0;i<12;i++) {
        int x=(int)((i*29U+256-scroll)%128);line(f,x,58+(int)(i%3),(int)(i%3+1));
    }
    dinosaur(f,a);
    for(unsigned i=0;i<2;i++) {
        const DinoObstacle *o=&a->obstacles[i];if(!o->active)continue;int x=o->x/256;
        if(o->kind==3) {
            line(f,x+2,o->top+3,8);line(f,x,o->top+2,4);pixel(f,x+1,o->top+1,true);
            for(int y=0;y<3;y++)line(f,x+5+y/2,o->top+(((a->steps/6)&1)?3+y:2-y),3-y/2);
        } else if(o->kind==2) {
            cactus(f,x,o->top+2,6,o->height-2);cactus(f,x+7,o->top,6,o->height);
        } else cactus(f,x,o->top,o->width,o->height);
    }
    game_text(f,GAME_LANDSCAPE,0,0,"HI");number(f,18,a->best);number(f,92,a->score);
    if(a->page==DINO_TITLE) {
        game_clear(f,GAME_LANDSCAPE,30,10,98,40);
        game_text(f,GAME_LANDSCAPE,39,12,"DINO RUN");
        choice(f,38,27,"START",a->selection==0);choice(f,38,39,"EXIT",a->selection==1);
        game_clear(f,GAME_LANDSCAPE,0,57,128,7);
        game_text(f,GAME_LANDSCAPE,7,57,"UP JUMP DOWN DUCK");
    } else if(a->page==DINO_PAUSED || a->page==DINO_OVER) {
        game_clear(f,GAME_LANDSCAPE,33,10,95,44);
        if(a->page==DINO_PAUSED) {
            game_text(f,GAME_LANDSCAPE,43,11,"PAUSED");
            choice(f,37,22,"RESUME",a->selection==0);choice(f,37,33,"RESTART",a->selection==1);
            choice(f,37,44,"EXIT",a->selection==2);
        } else {
            game_text(f,GAME_LANDSCAPE,39,15,"GAME OVER");
            choice(f,39,30,"RETRY",a->selection==0);choice(f,39,43,"EXIT",a->selection==1);
        }
    }
    if(a->save_failed)game_text(f,GAME_LANDSCAPE,48,57,"SAVE ERROR");
    if(a->page!=DINO_TITLE && (a->score/200)&1U)for(unsigned i=0;i<1024;i++)f[i]^=255;
}
