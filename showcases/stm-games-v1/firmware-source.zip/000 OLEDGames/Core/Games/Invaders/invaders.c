#include "invaders.h"
#include <string.h>
static void wave_begin(Invaders *g) {
    g->alive = INVADERS_ALL;
    g->alien_x = 18; g->alien_y = 12; g->direction = 1;
    g->alien_ms = g->enemy_ms = g->fire_ms = 0;
    g->player.y = -1;
    for (unsigned i = 0; i < 3; i++) {
        g->enemy[i].y = -1;
        for (unsigned x = 0; x < 16; x++) {
            uint8_t bits = x == 0 || x == 15 ? 0xFC : x == 1 || x == 14 ? 0xFE : 0xFF;
            if (x >= 5 && x <= 10) bits &= 0x1F;
            g->shields[i][x] = bits;
        }
    }
}

static void add_ammo(Invaders *g, unsigned amount) {
    unsigned total = g->ammo + amount;
    g->ammo = total > UINT16_MAX ? UINT16_MAX : (uint16_t)total;
}
static void next_wave(Invaders *g) {
    if (g->wave < 999) g->wave++;
    add_ammo(g, 20); wave_begin(g);
}
void invaders_init(Invaders *g, uint32_t seed) {
    memset(g, 0, sizeof(*g));
    g->random = seed ? seed : 1;
    g->lives = 3; g->wave = 1; g->ship_x = 58; g->ammo = 100;
    wave_begin(g);
}

uint16_t invaders_interval(const Invaders *g) {
    unsigned remaining = 0;
    for (unsigned i = 0; i < 24; i++) remaining += (g->alive >> i) & 1U;
    int interval = 1000 - (int)(g->wave - 1) * 80 - (int)(24 - remaining) * 22;
    return interval < 100 ? 100 : (uint16_t)interval;
}

static uint16_t decrease(uint16_t value) { return value > STEP_MS ? value - STEP_MS : 0; }

static bool shield_hit(Invaders *g, int x, int y) {
    if (y < SHIELD_Y || y >= SHIELD_Y + 8) return false;
    for (unsigned i = 0; i < 3; i++) {
        int col = x - (16 + (int)i * 40);
        if (col < 0 || col >= 16 || !(g->shields[i][col] & (1U << (y - SHIELD_Y)))) continue;
        for (int cx = col - 1; cx <= col + 1; cx++) {
            if (cx < 0 || cx >= 16) continue;
            for (int cy = y - SHIELD_Y - 1; cy <= y - SHIELD_Y + 1; cy++)
                if (cy >= 0 && cy < 8) g->shields[i][cx] &= (uint8_t)~(1U << cy);
        }
        return true;
    }
    return false;
}

static bool player_hit(Invaders *g, Bullet *b) {
    if (shield_hit(g, b->x, b->y)) return true;
    for (unsigned i = 0; i < 24; i++) {
        if (!(g->alive & (1UL << i))) continue;
        int x = g->alien_x + (i % 8) * 12;
        int y = g->alien_y + (i / 8) * 8;
        if (b->x >= x && b->x < x + 8 && b->y >= y && b->y < y + 5) {
            g->alive &= ~(1UL << i);
            if (g->score < 999990) g->score += 10;
            add_ammo(g, 1);
            return true;
        }
    }
    return false;
}

static bool enemy_hit(Invaders *g, Bullet *b) {
    if (shield_hit(g, b->x, b->y)) return true;
    if (b->y >= SHIP_Y && b->x >= g->ship_x && b->x < g->ship_x + 11) {
        if (!g->invulnerable_ms) {
            g->lives--; g->invulnerable_ms = 1000; add_ammo(g, 50);
            if (!g->lives) { g->over = true; g->end_reason = END_LIVES; }
        }
        return true;
    }
    return false;
}

static void move_bullet(Invaders *g, Bullet *b, bool player) {
    if (b->y < 0) return;
    /* Check each pixel so a two-pixel move cannot jump through a thin shield. */
    for (unsigned step = 0; step < 2; step++) {
        b->y += player ? -1 : 1;
        if (b->y < 8 || b->y >= 64 || (player ? player_hit(g, b) : enemy_hit(g, b))) {
            b->y = -1; break;
        }
    }
}

static void alien_move(Invaders *g) {
    int min = 128, max = -128;
    for (unsigned i = 0; i < 24; i++) if (g->alive & (1UL << i)) {
        int x = g->alien_x + (i % 8) * 12;
        if (x < min) min = x;
        if (x + 7 > max) max = x + 7;
    }
    int dx = g->direction * 2;
    if (min + dx < 0 || max + dx >= 128) { g->direction = -g->direction; g->alien_y += 2; }
    else g->alien_x += dx;
    for (unsigned i = 0; i < 24; i++) if (g->alive & (1UL << i)) {
        int x = g->alien_x + (i % 8) * 12, y = g->alien_y + (i / 8) * 8;
        for (unsigned shield = 0; shield < 3; shield++) for (int cx = 0; cx < 16; cx++) {
            int sx = 16 + (int)shield * 40 + cx;
            if (sx < x || sx >= x + 8) continue;
            for (int cy = 0; cy < 8; cy++)
                if (SHIELD_Y + cy >= y && SHIELD_Y + cy < y + 5)
                    g->shields[shield][cx] &= (uint8_t)~(1U << cy);
        }
    }
}

static void enemy_fire(Invaders *g) {
    unsigned slot;
    for (slot = 0; slot < 3 && g->enemy[slot].y >= 0; slot++) {}
    if (slot == 3) return;
    g->random ^= g->random << 13; g->random ^= g->random >> 17; g->random ^= g->random << 5;
    for (unsigned tries = 0; tries < 8; tries++) {
        unsigned col = (g->random + tries) % 8;
        for (int row = 2; row >= 0; row--) if (g->alive & (1UL << (row * 8 + col))) {
            g->enemy[slot].x = g->alien_x + col * 12 + 4;
            g->enemy[slot].y = g->alien_y + row * 8 + 5;
            return;
        }
    }
}

void invaders_step(Invaders *g, bool left, bool right, bool fire) {
    if (g->over) return;
    if (!g->alive) { next_wave(g); return; }
    g->invulnerable_ms = decrease(g->invulnerable_ms);
    g->fire_ms = decrease(g->fire_ms);
    if (left != right) {
        if (left) g->ship_x = g->ship_x < 2 ? 0 : g->ship_x - 2;
        else g->ship_x = g->ship_x > 115 ? 117 : g->ship_x + 2;
    }
    g->alien_ms += STEP_MS;
    if (g->alien_ms >= invaders_interval(g)) { g->alien_ms = 0; alien_move(g); }
    for (unsigned i = 0; i < 24; i++) if ((g->alive & (1UL << i)) &&
        g->alien_y + (int)(i / 8) * 8 + 5 >= SHIP_Y) { g->over = true; g->end_reason = END_INVASION; return; }
    move_bullet(g, &g->player, true);
    for (unsigned i = 0; i < 3 && !g->over; i++) move_bullet(g, &g->enemy[i], false);
    if (g->over) return;
    if (!g->alive) { next_wave(g); return; }
    if (fire && g->ammo && !g->fire_ms && g->player.y < 0) {
        g->player.x = g->ship_x + 5; g->player.y = SHIP_Y - 1; g->fire_ms = 240;
        g->ammo--;
    }
    if (!g->ammo && g->player.y < 0) { g->over = true; g->end_reason = END_AMMO; return; }
    g->enemy_ms += STEP_MS;
    int enemy_interval = 1000 - (int)(g->wave - 1) * 50;
    if (enemy_interval < 350) enemy_interval = 350;
    if (g->enemy_ms >= enemy_interval) { g->enemy_ms = 0; enemy_fire(g); }
}
