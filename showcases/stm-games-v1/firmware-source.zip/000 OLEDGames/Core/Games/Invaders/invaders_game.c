#include "invaders_game.h"
#include "invaders_screen.h"
#include "invaders_highscore.h"
#include "game_menu.h"
InvadersApp invaders_game_state;
static uint8_t frame[1024];
static void init(uint32_t seed) { invaders_app_init(&invaders_game_state,seed);invaders_game_state.best=invaders_highscore_load(); }
static void enter(uint32_t now) {
    invaders_game_state.state=INVADERS_APP_TITLE;invaders_game_state.selection=0;
    invaders_game_state.held=0;invaders_game_state.gate=31;
    invaders_game_state.last_tick=now;invaders_game_state.dirty=true;
}
static GameResult update(uint8_t pressed,uint8_t held,uint32_t now) {
    InvadersApp *a=&invaders_game_state;InvadersAppState before=a->state;
    if(a->state==INVADERS_APP_TITLE && (pressed==KEY_UP || pressed==KEY_DOWN)) {
        a->selection=pressed==KEY_UP ? (a->selection+2)%3 : (a->selection+1)%3;
        a->dirty=true;return GAME_STAY;
    }
    if(a->state==INVADERS_APP_TITLE && a->selection==2) {
        if(pressed&KEY_OK)return GAME_EXIT;
        return GAME_STAY;
    }
    invaders_app_input(a,pressed,held,now);invaders_app_tick(a,now);
    return before!=a->state ? GAME_PAGE_CHANGED : GAME_STAY;
}
static const uint8_t *draw(void) {
    InvadersApp *a=&invaders_game_state;if(!a->dirty)return NULL;
    invaders_screen_render(a,frame);
    if(a->state==INVADERS_APP_TITLE)game_text(frame,GAME_LANDSCAPE,16,40,a->selection==2 ? "> EXIT" : "  EXIT");
    a->dirty=false;return frame;
}
static void service(uint32_t now,bool idle) {
    (void)now;
    if(!idle)return;
    if(invaders_game_state.save_requested) {
        invaders_game_state.save_requested=false;
        invaders_game_state.save_failed=!invaders_highscore_save(invaders_game_state.best);
        invaders_game_state.dirty=true;
    }
}
const Game invaders_game={"SPACE INVADERS",GAME_LANDSCAPE,init,enter,update,draw,service};
