#ifndef INVADERS_APP_H
#define INVADERS_APP_H
#include "invaders.h"
#include "buttons.h"
typedef enum { INVADERS_APP_TITLE, INVADERS_APP_PLAY, INVADERS_APP_PAUSE, INVADERS_APP_OVER } InvadersAppState;
typedef struct {
    Invaders game;
    uint32_t last_tick;
    uint32_t best;
    InvadersAppState state;
    uint8_t selection, held, gate;
    bool automatic, dirty;
    bool save_requested, save_failed;
} InvadersApp;
void invaders_app_init(InvadersApp *a, uint32_t now);
void invaders_app_input(InvadersApp *a, uint8_t pressed, uint8_t held, uint32_t now);
void invaders_app_tick(InvadersApp *a, uint32_t now);
#endif
