#ifndef INVADERS_HIGHSCORE_H
#define INVADERS_HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define INVADERS_HIGHSCORE_BASE 0x0800F800UL
#define INVADERS_HIGHSCORE_PAGE 1024U
#define INVADERS_HIGHSCORE_COMMIT 0x51A5C0DEUL
uint32_t invaders_highscore_load(void);
bool invaders_highscore_save(uint32_t score);
#endif
