#ifndef INVADERS_H
#define INVADERS_H
#include <stdbool.h>
#include <stdint.h>
#define INVADERS_ALL 0xFFFFFFUL
#define STEP_MS 20U
#define SHIELD_Y 46
#define SHIP_Y 57
enum { END_NONE, END_LIVES, END_INVASION, END_AMMO };
typedef struct { int8_t x, y; } Bullet;
typedef struct {
    uint32_t alive, score, random;
    uint16_t wave, alien_ms, enemy_ms, fire_ms, invulnerable_ms, ammo;
    uint8_t ship_x, lives;
    int8_t alien_x, alien_y, direction;
    Bullet player, enemy[3];
    uint8_t shields[3][16];
    bool over;
    uint8_t end_reason;
} Invaders;
void invaders_init(Invaders *g, uint32_t seed);
void invaders_step(Invaders *g, bool left, bool right, bool fire);
uint16_t invaders_interval(const Invaders *g);
#endif
