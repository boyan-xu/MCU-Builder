#ifndef INVADERS_GAME_H
#define INVADERS_GAME_H
#include "game.h"
#include "invaders_app.h"
extern InvadersApp invaders_game_state;
extern const Game invaders_game;
#endif
