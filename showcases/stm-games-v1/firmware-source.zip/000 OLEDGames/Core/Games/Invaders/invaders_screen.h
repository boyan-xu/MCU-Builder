#ifndef INVADERS_SCREEN_H
#define INVADERS_SCREEN_H
#include "invaders_app.h"
#define INVADERS_SCREEN_BYTES 1024
void invaders_screen_render(const InvadersApp *a, uint8_t frame[INVADERS_SCREEN_BYTES]);
#endif
