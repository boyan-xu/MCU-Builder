#include "invaders_highscore.h"
#include "score_journal.h"
static const ScoreJournal journal={INVADERS_HIGHSCORE_BASE,INVADERS_HIGHSCORE_COMMIT,999990};
uint32_t invaders_highscore_load(void) {return score_journal_load(&journal);}
bool invaders_highscore_save(uint32_t score) {return score_journal_save(&journal,score);}
