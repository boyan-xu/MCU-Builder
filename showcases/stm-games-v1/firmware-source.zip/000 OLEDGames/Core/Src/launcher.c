#include "game_menu.h"
#include "launcher.h"
#include "buttons.h"
#include "font5x7.h"
#include <string.h>

void launcher_init(Launcher *l, const Game *const *games, size_t count, uint32_t seed) {
    memset(l, 0, sizeof(*l)); l->games=games; l->count=count; l->active=-1;
    l->waiting_release=true; l->dirty=true;
    for (size_t i=0;i<count;i++) games[i]->init(seed+(uint32_t)i);
}

void launcher_update(Launcher *l, uint8_t pressed, uint8_t held, uint32_t now) {
    if (l->waiting_release) {
        if (held) return;
        l->waiting_release=false;
        pressed=0;
    }
    if (l->active>=0) {
        const Game *game=l->games[l->active];
        if (game->orientation==GAME_PORTRAIT) {
            pressed=buttons_portrait(pressed); held=buttons_portrait(held);
        }
        GameResult result=game->update(pressed,held,now);
        if (result==GAME_EXIT) {
            l->active=-1; l->waiting_release=true; l->dirty=true;
        } else if (result==GAME_PAGE_CHANGED) {
            l->waiting_release=true;
        }
        return;
    }
    if (!l->count) return;
    if (pressed&KEY_OK) {
        l->active=(int)l->selection;
        l->games[l->selection]->enter(now);
        l->waiting_release=true;
    } else if (pressed==KEY_UP || pressed==KEY_DOWN) {
        l->selection=pressed==KEY_UP ? (l->selection+l->count-1)%l->count : (l->selection+1)%l->count;
        if (l->selection<l->first) l->first=l->selection;
        if (l->selection>=l->first+4) l->first=l->selection-3;
        l->dirty=true;
    }
}

static void text(uint8_t *frame,unsigned x,unsigned page,const char *label) { game_page_text(frame,(int)x,(int)page,label); }

const uint8_t *launcher_draw(Launcher *l) {
    if (l->active>=0) return l->games[l->active]->draw();
    if (!l->dirty) return NULL;
    uint8_t *frame=display_frame();
    memset(frame,0,SCREEN_BYTES);
    text(frame,30,0,"SELECT GAME");
    if (!l->count) text(frame,0,3,"NO GAMES");
    for (size_t i=l->first;i<l->count && i<l->first+4;i++) {
        text(frame,0,2+(i-l->first),i==l->selection ? ">" : " ");
        text(frame,12,2+(i-l->first),l->games[i]->name);
    }
    text(frame,0,7,"UP/DOWN  OK ENTER");
    l->dirty=false;
    return frame;
}
