#include "oled_i2c_event.h"
static void complete(I2C_HandleTypeDef *bus) {
    __HAL_I2C_DISABLE_IT(bus,I2C_IT_EVT|I2C_IT_BUF|I2C_IT_ERR);
    SET_BIT(bus->Instance->CR1,I2C_CR1_STOP);
    bus->PreviousState=HAL_I2C_MODE_NONE;
    bus->State=HAL_I2C_STATE_READY;bus->Mode=HAL_I2C_MODE_NONE;
#if USE_HAL_I2C_REGISTER_CALLBACKS
    bus->MasterTxCpltCallback(bus);
#else
    HAL_I2C_MasterTxCpltCallback(bus);
#endif
}
void oled_i2c_event_irq(I2C_HandleTypeDef *bus) {
    if(bus->State==HAL_I2C_STATE_READY && bus->Mode==HAL_I2C_MODE_NONE)return;
    uint32_t enabled=READ_REG(bus->Instance->CR2);
    /* Preserve HAL's SR2-before-SR1 order; the opposite order clears ADDR. */
    uint32_t status2=READ_REG(bus->Instance->SR2),status=READ_REG(bus->Instance->SR1);
    /* shortcut: OLED is master-TX only; add and verify a general path before new bus uses. */
    if(bus->Mode!=HAL_I2C_MODE_MASTER || bus->State!=HAL_I2C_STATE_BUSY_TX ||
       bus->Init.AddressingMode!=I2C_ADDRESSINGMODE_7BIT || bus->XferOptions!=0xFFFF0000U ||
       bus->hdmatx || bus->hdmarx || (enabled&I2C_CR2_DMAEN)) {
        __HAL_I2C_DISABLE_IT(bus,I2C_IT_EVT|I2C_IT_BUF|I2C_IT_ERR|I2C_CR2_DMAEN);
        SET_BIT(bus->Instance->CR1,I2C_CR1_STOP);bus->ErrorCode|=HAL_I2C_ERROR_BERR;
        bus->XferCount=0;bus->PreviousState=HAL_I2C_MODE_NONE;
        bus->State=HAL_I2C_STATE_READY;bus->Mode=HAL_I2C_MODE_NONE;__HAL_UNLOCK(bus);
#if USE_HAL_I2C_REGISTER_CALLBACKS
        bus->ErrorCallback(bus);
#else
        HAL_I2C_ErrorCallback(bus);
#endif
        return;
    }
    if((status&I2C_SR1_SB) && (enabled&I2C_IT_EVT))bus->Instance->DR=bus->Devaddress&~1U;
    else if((status&I2C_SR1_ADDR) && (enabled&I2C_IT_EVT)) {__HAL_I2C_CLEAR_ADDRFLAG(bus);}
    else if(status2&I2C_SR2_TRA) {
        if((status&I2C_SR1_TXE) && (enabled&I2C_IT_BUF) && !(status&I2C_SR1_BTF)) {
            if(!bus->XferSize)complete(bus);
            else if(bus->XferCount){bus->Instance->DR=*bus->pBuffPtr++;bus->XferCount--;}
            else __HAL_I2C_DISABLE_IT(bus,I2C_IT_BUF);
        } else if((status&I2C_SR1_BTF) && (enabled&I2C_IT_EVT)) {
            if(bus->XferCount){bus->Instance->DR=*bus->pBuffPtr++;bus->XferCount--;}
            else complete(bus);
        }
    }
}
