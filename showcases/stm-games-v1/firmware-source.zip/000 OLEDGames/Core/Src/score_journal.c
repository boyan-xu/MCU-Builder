#include "score_journal.h"
#include "main.h"
typedef struct {uint32_t score,inverse,commit;} Record;
_Static_assert(sizeof(Record)==12,"Existing score journal layout");
static const volatile Record *at(uint32_t address) {return (const volatile Record *)address;}
static bool valid(const ScoreJournal *j,const volatile Record *r) {
    return r->commit==j->commit && r->inverse==~r->score && r->score<=j->max_score;
}
static __attribute__((noinline)) uint32_t find_best(const ScoreJournal *j,uint32_t *page) {
    uint32_t best=0;if(page)*page=j->base;
    for(unsigned p=0;p<2;p++)for(unsigned i=0;i<1024/sizeof(Record);i++) {
        uint32_t address=j->base+p*1024+i*sizeof(Record);const volatile Record *r=at(address);
        if(valid(j,r) && r->score>best){best=r->score;if(page)*page=j->base+p*1024;}
    }
    return best;
}
/* Keep one implementation: LTO specialization would duplicate every game's journal again. */
__attribute__((noipa)) uint32_t score_journal_load(const ScoreJournal *j) {return find_best(j,0);}
__attribute__((noipa)) bool score_journal_save(const ScoreJournal *j,uint32_t score) {
    /* Tetris's existing format also requires per-halfword and erased-page readback. */
    bool strict=j->commit==0x54455431U;
    if(score>j->max_score)return false;
    uint32_t page,best=find_best(j,&page),address=0;
    if(score<=best)return true;
    for(unsigned i=0;i<1024/sizeof(Record);i++) {
        uint32_t candidate=page+i*sizeof(Record);const volatile Record *r=at(candidate);
        if(r->score==UINT32_MAX && r->inverse==UINT32_MAX && r->commit==UINT32_MAX){address=candidate;break;}
    }
    if(HAL_FLASH_Unlock()!=HAL_OK){if(!strict)HAL_FLASH_Lock();return false;}
#ifdef __HAL_FLASH_CLEAR_FLAG
    if(strict)__HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
#endif
    bool okay=true;
    if(!address) {
        if(best || strict)page=page==j->base?j->base+1024:j->base;
        FLASH_EraseInitTypeDef erase={0};uint32_t error;
        erase.TypeErase=FLASH_TYPEERASE_PAGES;erase.PageAddress=page;erase.NbPages=1;
        okay=HAL_FLASHEx_Erase(&erase,&error)==HAL_OK;address=page;
        if(strict)for(unsigned i=0;okay && i<256;i++)okay=((const volatile uint32_t *)page)[i]==UINT32_MAX;
    }
    const uint32_t words[3]={score,~score,j->commit};
    for(unsigned i=0;i<6 && okay;i++) {
        uint16_t value=(uint16_t)(words[i/2]>>((i%2)*16));
        okay=HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,address+i*2,value)==HAL_OK;
        if(okay && strict)okay=*(const volatile uint16_t *)(address+i*2)==value;
    }
    if(okay && !strict)for(unsigned i=0;i<3 && okay;i++)okay=((const volatile uint32_t *)address)[i]==words[i];
    HAL_StatusTypeDef locked=HAL_FLASH_Lock();return okay && locked==HAL_OK;
}
