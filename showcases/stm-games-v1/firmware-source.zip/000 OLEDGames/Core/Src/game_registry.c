#include "game.h"
#include "Snake/snake_game.h"
#include "Tetris/tetris_game.h"
#include "Invaders/invaders_game.h"
#include "Dino/dino_game.h"
#include "Game2048/game2048_game.h"
#include "Minesweeper/minesweeper_game.h"
#include "Breakout/breakout_game.h"
#include "TowerDefense/tower_defense_game.h"
#include "Stack/stack_game.h"
#include "Timberman/timberman_game.h"
const Game *const game_registry[] = { &snake_game, &tetris_game, &invaders_game, &dino_game, &game2048_game, &minesweeper_game, &breakout_game, &tower_defense_game, &stack_game, &timberman_game };
const size_t game_count = sizeof(game_registry) / sizeof(game_registry[0]);
