#include "display.h"
uint8_t *display_frame(void) {
    /* Foreground draws share this buffer; OLED submission copies it before transfer. */
    static uint8_t frame[SCREEN_BYTES];
    return frame;
}
