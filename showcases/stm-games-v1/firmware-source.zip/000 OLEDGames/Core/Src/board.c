#include "board.h"
#include "buttons.h"
#include "main.h"
#include "oled.h"
#include "games_service.h"

Launcher launcher;
volatile uint32_t board_loops;
volatile uint8_t board_raw_keys;
static Buttons buttons;
static const uint8_t *frame;
static bool pending;
static uint32_t last_poll;

void board_begin(void) {
    HAL_Delay(100);
    buttons_init(&buttons);
    launcher_init(&launcher, game_registry, game_count, HAL_GetTick());
    last_poll = HAL_GetTick() - 1;
    frame = NULL;
    oled_begin(HAL_GetTick());
}

void board_poll(void) {
    uint32_t now = HAL_GetTick();
    board_loops++;
    if (now != last_poll) {
        last_poll = now;
        board_raw_keys = (uint8_t)((~GPIOB->IDR >> 10) & 31U);
        uint8_t pressed = buttons_update(&buttons, board_raw_keys, now);
        uint8_t held = buttons.stable;
        /* A button held during boot must release before its first debounced event. */
        if (launcher.waiting_release) held |= board_raw_keys;
        launcher_update(&launcher, pressed, held, now);
        const uint8_t *changed = launcher_draw(&launcher);
        if (changed) {
            frame = changed;
            pending = true;
        }
    }
    bool was_online = oled_online;
    oled_service(now);
    if (!was_online && oled_online) pending = true;
    games_service(now,!oled_busy());
    if (pending && frame && oled_submit(frame, now)) pending = false;
}
