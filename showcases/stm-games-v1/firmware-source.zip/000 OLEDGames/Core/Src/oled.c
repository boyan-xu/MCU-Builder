#include "oled.h"
#include "main.h"
#include <string.h>

extern I2C_HandleTypeDef hi2c1;
volatile uint32_t oled_frames, oled_errors;
volatile bool oled_online;
static uint8_t target[SCREEN_BYTES], confirmed[SCREEN_BYTES];
static uint8_t transfer[129];
static uint8_t phase;
static bool valid;
static uint16_t cursor, first, count;
static uint32_t started, retry_at;
static uint8_t position[] = {0x00, 0x21, 0, 127, 0x22, 0, 7};
bool oled_busy(void) { return phase != 0; }

void oled_begin(uint32_t now) {
    static uint8_t init[] = {
        0x00, 0xAE, 0xD5, 0x80, 0xA8, 0x3F, 0xD3, 0x00, 0x40,
        0x8D, 0x14, 0x20, 0x00, 0xA1, 0xC8, 0xDA, 0x12, 0x81, 0x7F,
        0xD9, 0xF1, 0xDB, 0x40, 0xA4, 0xA6, 0x2E, 0xAF
    };
    phase = 0;
    valid = false;
    retry_at = now;
    oled_online = HAL_I2C_IsDeviceReady(&hi2c1, 0x3C << 1, 2, 10) == HAL_OK &&
        HAL_I2C_Master_Transmit(&hi2c1, 0x3C << 1, init, sizeof(init), 50) == HAL_OK;
    if (!oled_online) oled_errors++;
}

static void failed(uint32_t now) {
    oled_errors++;
    oled_online = false;
    phase = 0;
    valid = false;
    retry_at = now;
    /* Release a stuck transaction before a later retry. 清理超时传输。 */
    HAL_I2C_DeInit(&hi2c1);
    HAL_I2C_Init(&hi2c1);
}

static bool next_span(uint32_t now) {
    while (cursor < SCREEN_BYTES && valid && target[cursor] == confirmed[cursor]) cursor++;
    if (cursor == SCREEN_BYTES) return false;
    first = cursor;
    unsigned page_end = (first / 128 + 1) * 128;
    do { cursor++; }
    while (cursor < page_end && (!valid || target[cursor] != confirmed[cursor]));
    count = cursor - first;
    transfer[0] = 0x40;
    memcpy(transfer + 1, target + first, count);
    position[2] = first % 128;
    position[3] = (cursor - 1) % 128;
    position[5] = position[6] = first / 128;
    phase = 1;
    started = now;
    if (HAL_I2C_Master_Transmit_IT(&hi2c1, 0x3C << 1, position, sizeof(position)) != HAL_OK) {
        failed(now);
        return false;
    }
    return true;
}

void oled_service(uint32_t now) {
    if (!oled_online) {
        if ((uint32_t)(now - retry_at) >= 1000) oled_begin(now);
        return;
    }
    if (!phase) return;
    if (HAL_I2C_GetState(&hi2c1) == HAL_I2C_STATE_READY) {
        if (HAL_I2C_GetError(&hi2c1) != HAL_I2C_ERROR_NONE) {
            failed(now);
        } else if (phase == 1) {
            phase = 2;
            started = now;
            if (HAL_I2C_Master_Transmit_IT(&hi2c1, 0x3C << 1, transfer, count + 1) != HAL_OK)
                failed(now);
        } else {
            memcpy(confirmed + first, transfer + 1, count);
            if (!next_span(now) && oled_online) {
                phase = 0;
                valid = true;
                oled_frames++;
            }
        }
    } else if ((uint32_t)(now - started) > 200) {
        failed(now);
    }
}

bool oled_submit(const uint8_t frame[SCREEN_BYTES], uint32_t now) {
    if (!oled_online || phase) return false;
    /* Snapshot stays fixed while interrupts send it. 传输期间帧数据保持不变。 */
    memcpy(target, frame, SCREEN_BYTES);
    cursor = 0;
    next_span(now);
    return oled_online;
}
