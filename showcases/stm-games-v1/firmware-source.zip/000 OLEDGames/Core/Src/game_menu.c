#include "game_menu.h"
#include "font5x7.h"
#include <stdbool.h>
__attribute__((noipa)) char *game_decimal(char *out,uint32_t value) {
    char reverse[10];unsigned n=0;do{reverse[n++]=(char)('0'+value%10);value/=10;}while(value);
    do{*out++=reverse[--n];}while(n);
    *out=0;return out;
}
__attribute__((noipa)) int game_page_text(uint8_t *f,int x,int page,const char *s) {
    if(page<0 || page>=8 || x<0)return x;
    for(;*s && x<=122;s++,x+=6) {
        unsigned char c=(unsigned char)*s;
        if(c<32 || c>126)c='?';
        for(unsigned col=0;col<5;col++)f[page*128+x+col]=oled_font[c-32][col];
    }
    return x;
}
static void pixel(uint8_t *frame,GameOrientation orientation,unsigned x,unsigned y,bool set) {
    if (orientation==GAME_PORTRAIT) { if(x>=64 || y>=128)return;unsigned old=x;x=y;y=63-old; }
    else if(x>=128 || y>=64)return;
    uint8_t mask=1U<<(y%8);uint8_t *p=&frame[(y/8)*128+x];
    if(set)*p|=mask;else *p&=(uint8_t)~mask;
}
void game_text(uint8_t *frame,GameOrientation orientation,unsigned x,unsigned y,const char *label) {
    for(;*label;label++,x+=6) {
        unsigned char c=(unsigned char)*label;if(c<32 || c>126)c='?';
        for(unsigned col=0;col<5;col++)for(unsigned row=0;row<7;row++)
            pixel(frame,orientation,x+col,y+row,(oled_font[c-32][col]&(1U<<row))!=0);
    }
}
void game_clear(uint8_t *f,GameOrientation o,unsigned x,unsigned y,unsigned w,unsigned h) {
    for(unsigned c=0;c<w;c++)for(unsigned r=0;r<h;r++)pixel(f,o,x+c,y+r,false);
}
/* Keep one shared implementation rather than per-game LTO clones. */
__attribute__((noipa)) void game_box(uint8_t *f,GameOrientation o,int x,int y,int w,int h,bool solid) {
    for(int r=0;r<h;r++)for(int c=0;c<w;c++)if(solid || !r || !c || r==h-1 || c==w-1)pixel(f,o,x+c,y+r,true);
}
const uint8_t game_digits3[10][5]={{7,5,5,5,7},{2,6,2,2,7},{7,1,7,4,7},{7,1,7,1,7},{5,5,7,1,1},{7,4,7,1,7},{7,4,7,5,7},{7,1,1,1,1},{7,5,7,5,7},{7,5,7,1,7}};
__attribute__((noipa)) void game_number3(uint8_t *f,GameOrientation o,int x,int y,uint32_t value) {
    char digits[11];game_decimal(digits,value);
    for(const char *p=digits;*p;p++,x+=4) {
        const uint8_t *glyph=game_digits3[(unsigned)(*p-'0')];
        for(unsigned r=0;r<5;r++)for(unsigned c=0;c<3;c++)
            if(glyph[r]&(4U>>c))pixel(f,o,x+(int)c,y+(int)r,true);
    }
}
