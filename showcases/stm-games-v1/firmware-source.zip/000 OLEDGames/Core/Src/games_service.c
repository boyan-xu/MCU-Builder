#include "games_service.h"
#include "game.h"
void games_service(uint32_t now,bool idle) {
    for(size_t i=0;i<game_count;i++)
        if(game_registry[i]->service)game_registry[i]->service(now,idle);
}
