#ifndef APP_H
#define APP_H
#include "tetris.h"
#include "buttons.h"
typedef enum { APP_MENU, APP_PLAY, APP_PAUSE, APP_END } AppState;
typedef struct {
    Tetris tetris;
    AppState state;
    uint32_t last_fall, last_repeat, soft_at, seed;
    uint32_t best_score;
    uint8_t direction;
    bool repeating, soft_held, dirty;
    bool save_pending, save_failed;
} App;
void app_init(App *a, uint32_t seed);
void app_input(App *a, uint8_t pressed, uint8_t held, uint32_t now);
void app_tick(App *a, uint32_t now);
#endif
