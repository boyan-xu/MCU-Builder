#ifndef HIGHSCORE_H
#define HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define HIGHSCORE_BASE 0x0800F800U
#define HIGHSCORE_PAGE_SIZE 1024U
uint32_t highscore_load(void);
bool highscore_save(uint32_t score);
#endif
