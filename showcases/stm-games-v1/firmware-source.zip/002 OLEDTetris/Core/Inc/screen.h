#ifndef SCREEN_H
#define SCREEN_H
#include "app.h"
#define SCREEN_BYTES 1024
typedef struct {
    uint8_t frame[SCREEN_BYTES];
    Tetris previous;
    AppState state;
    bool valid;
} Screen;
void screen_render(const App *a, uint8_t frame[SCREEN_BYTES]);
void screen_update(Screen *s, const App *a);
void screen_pixel(uint8_t frame[SCREEN_BYTES], unsigned x, unsigned y);
#endif
