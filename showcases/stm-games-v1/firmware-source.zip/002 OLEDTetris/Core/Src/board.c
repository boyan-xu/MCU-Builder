#include "board.h"
#include "main.h"
#include "oled.h"
#include "highscore.h"
App game;
volatile uint32_t board_loops;
volatile uint8_t board_raw_keys;
static Buttons buttons;
static Screen screen;
static bool pending;
static uint32_t last_poll;
void board_begin(void) {
    HAL_Delay(100); buttons_init(&buttons);
    app_init(&game,HAL_GetTick()); last_poll=HAL_GetTick()-1;
    game.best_score=highscore_load();screen.valid=false;pending=false;
    oled_begin(HAL_GetTick());
}
void board_poll(void) {
    uint32_t now=HAL_GetTick(); board_loops++;
    if (now!=last_poll) {
        last_poll=now; board_raw_keys=(uint8_t)((~GPIOB->IDR>>10)&31U);
        uint8_t events=buttons_update(&buttons,buttons_portrait(board_raw_keys),now);
        app_input(&game,events,buttons.stable,now); app_tick(&game,now);
    }
    bool was_online=oled_online; oled_service(now);
    if (!was_online && oled_online) pending=true;
    if(game.save_pending && oled_idle()) {
        game.save_pending=false;game.save_failed=!highscore_save(game.best_score);
        game.dirty=true;now=HAL_GetTick();
    }
    if (game.dirty) { screen_update(&screen,&game); game.dirty=false; pending=true; }
    if (pending && oled_submit(screen.frame,now)) pending=false;
}
