#include "screen.h"
#include <string.h>
#include "font5x7.h"
void screen_pixel(uint8_t frame[SCREEN_BYTES],unsigned x,unsigned y) {
    if (x>=64 || y>=128) return;
    unsigned native_y=63U-x;
    frame[(native_y/8U)*128U+y] |= 1U << (native_y%8U);
}
static void text(uint8_t *f,unsigned x,unsigned y,const char *s) {
    for (;*s;s++,x+=6) {
        unsigned char c=(unsigned char)*s;
        if (c<32 || c>126) c='?';
        for (unsigned col=0;col<5;col++) for (unsigned row=0;row<7;row++)
            if (oled_font[c-32][col] & (1U<<row)) screen_pixel(f,x+col,y+row);
    }
}
static void block(uint8_t *f,unsigned x,unsigned y,unsigned size) {
    for (unsigned dx=0;dx<size;dx++) for (unsigned dy=0;dy<size;dy++)
        screen_pixel(f,x+dx,y+dy);
}
static void piece(uint8_t *f,uint8_t p,uint8_t r,int x,int y,unsigned size) {
    uint16_t mask=tetris_mask(p,r);
    for (int row=0;row<4;row++) for (int col=0;col<4;col++)
        if (mask & (1U<<(row*4+col))) block(f,x+col*size,y+row*size,size-1);
}
static void erase(uint8_t *frame,unsigned x,unsigned y,unsigned width,unsigned height) {
    for (unsigned px=x;px<x+width && px<64;px++)
        for (unsigned py=y;py<y+height && py<128;py++) {
            unsigned ny=63-px;frame[(ny/8)*128+py] &= ~(1U<<(ny%8));
        }
}
static void erase_piece(uint8_t *frame,const Tetris *t) {
    uint16_t mask=tetris_mask(t->piece,t->rotation);
    for (int row=0;row<4;row++) for (int col=0;col<4;col++)
        if (mask & (1U<<(row*4+col))) erase(frame,1+(t->x+col)*5,20+(t->y+row)*5,4,4);
}
static char *decimal(char buffer[11],uint32_t value) {
    char *p=buffer+10;*p=0;
    do { *--p=(char)('0'+value%10U);value/=10U; } while(value);
    return p;
}
static void best_line(uint8_t *frame,unsigned y,uint32_t value) {
    char buffer[11];char *digits=decimal(buffer,value);
    text(frame,(64U-6U*strlen(digits))/2U,y,digits);
}
static void score_line(uint8_t *frame,const Tetris *t) {
    char buffer[11];text(frame,0,0,"S:");text(frame,12,0,decimal(buffer,t->score));
}
void screen_render(const App *a,uint8_t frame[SCREEN_BYTES]) {
    memset(frame,0,SCREEN_BYTES);
    if (a->state==APP_MENU) {
        text(frame,20,0,"BEST");best_line(frame,9,a->best_score);
        text(frame,14,20,"TETRIS"); text(frame,11,36,"CLASSIC");
        text(frame,8,56,"OK START"); text(frame,8,80,"L/R MOVE");
        text(frame,5,92,"UP ROTATE"); text(frame,5,104,"DOWN FAST");
        text(frame,8,116,"OK PAUSE"); return;
    }
    char buffer[11]; const Tetris *t=&a->tetris;
    score_line(frame,t);
    char *digits=decimal(buffer,tetris_level(t));
    text(frame,0,9,"L");text(frame,6,9,digits);
    unsigned x=6U+6U*strlen(digits);text(frame,x,9," R");
    text(frame,x+12,9,decimal(buffer,t->lines));
    for (unsigned y=19;y<=120;y++) { screen_pixel(frame,0,y); screen_pixel(frame,51,y); }
    for (unsigned x=0;x<=51;x++) { screen_pixel(frame,x,19); screen_pixel(frame,x,120); }
    for (unsigned y=0;y<TETRIS_ROWS;y++) for (unsigned x=0;x<TETRIS_COLS;x++)
        if (t->rows[y]&(1U<<x)) block(frame,1+x*5,20+y*5,4);
    if (!t->over) piece(frame,t->piece,t->rotation,1+t->x*5,20+t->y*5,5);
    text(frame,56,20,"N"); piece(frame,t->next,0,52,31,3);
    if (a->state==APP_PAUSE) {
        for (unsigned x=2;x<50;x++) for (unsigned y=54;y<91;y++) {
            unsigned ny=63-x; frame[(ny/8)*128+y] &= ~(1U<<(ny%8));
        }
        text(frame,8,62,"PAUSED"); text(frame,11,78,"OK GO");
    } else if(a->state==APP_END) {
        erase(frame,0,48,64,59);
        text(frame,20,50,"GAME");text(frame,20,61,"OVER");
        text(frame,a->save_failed ? 8 : 20,72,a->save_failed ? "SAVE ERR" : "BEST");
        best_line(frame,83,a->best_score);text(frame,8,97,"OK RETRY");
    }
}
void screen_update(Screen *s,const App *a) {
    const Tetris *t=&a->tetris,*old=&s->previous;
    if (!s->valid || s->state!=APP_PLAY || a->state!=APP_PLAY ||
        old->next!=t->next || old->lines!=t->lines || old->over!=t->over ||
        memcmp(old->rows,t->rows,sizeof(t->rows))) {
        screen_render(a,s->frame);
    } else {
        if (old->piece!=t->piece || old->rotation!=t->rotation || old->x!=t->x || old->y!=t->y) {
            /* Settled cells are unchanged, so erase only the old moving piece. */
            erase_piece(s->frame,old);
            piece(s->frame,t->piece,t->rotation,1+t->x*5,20+t->y*5,5);
        }
        if (old->score!=t->score) { erase(s->frame,0,0,64,7);score_line(s->frame,t); }
    }
    s->previous=*t;s->state=a->state;s->valid=true;
}
