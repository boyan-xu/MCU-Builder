#include "highscore.h"
#include "main.h"
typedef struct { uint32_t score, inverse, commit; } Record;
#define COMMIT 0x54455431U
#define SLOTS (HIGHSCORE_PAGE_SIZE / sizeof(Record))
_Static_assert(sizeof(Record)==12,"Flash record layout");
static const volatile Record *page(unsigned p) {
    return (const volatile Record *)(HIGHSCORE_BASE+p*HIGHSCORE_PAGE_SIZE);
}
static bool valid(const volatile Record *r) {
    return r->commit==COMMIT && r->inverse==~r->score;
}
uint32_t highscore_load(void) {
    uint32_t best=0;
    for(unsigned p=0;p<2;p++)for(unsigned i=0;i<SLOTS;i++)
        if(valid(&page(p)[i]) && page(p)[i].score>best)best=page(p)[i].score;
    return best;
}
bool highscore_save(uint32_t score) {
    uint32_t best=0;unsigned active=0;
    for(unsigned p=0;p<2;p++)for(unsigned i=0;i<SLOTS;i++)
        if(valid(&page(p)[i]) && page(p)[i].score>best) {
            best=page(p)[i].score;active=p;
        }
    if(score<=best)return true;
    unsigned slot=0;
    while(slot<SLOTS) {
        const volatile Record *r=&page(active)[slot];
        if(r->score==UINT32_MAX && r->inverse==UINT32_MAX && r->commit==UINT32_MAX)break;
        slot++;
    }
    if(HAL_FLASH_Unlock()!=HAL_OK)return false;
    __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP|FLASH_FLAG_PGERR|FLASH_FLAG_WRPERR);
    bool ok=true;
    if(slot==SLOTS) {
        /* Keep the page with the current best until the new record commits. */
        active^=1;slot=0;
        FLASH_EraseInitTypeDef e={0};uint32_t error;
        e.TypeErase=FLASH_TYPEERASE_PAGES;e.PageAddress=(uint32_t)page(active);e.NbPages=1;
        ok=HAL_FLASHEx_Erase(&e,&error)==HAL_OK;
        for(unsigned i=0;ok && i<HIGHSCORE_PAGE_SIZE/4;i++)
            ok=((const volatile uint32_t *)page(active))[i]==UINT32_MAX;
    }
    uint32_t data[3]={score,~score,COMMIT};
    uint32_t address=(uint32_t)&page(active)[slot];
    /* Program data first, commit last; each halfword is read back. */
    for(unsigned i=0;ok && i<6;i++) {
        uint16_t value=(uint16_t)(data[i/2]>>((i%2)*16));
        ok=HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD,address+i*2,value)==HAL_OK;
        if(ok)ok=*(const volatile uint16_t *)(address+i*2)==value;
    }
    if(HAL_FLASH_Lock()!=HAL_OK)ok=false;
    return ok;
}
