#include "board.h"
#include "main.h"
#include "buttons.h"
#include "oled.h"
#include "Dino/dino_game.h"
volatile uint32_t board_loops,board_raw_keys;
static Buttons buttons;
static uint32_t last_poll;
static const uint8_t *frame;
static bool pending;
void board_begin(void) {
    HAL_Delay(100);buttons_init(&buttons);
    board_raw_keys=(uint8_t)((~GPIOB->IDR>>10)&31U);
    buttons.raw=buttons.stable=(uint8_t)board_raw_keys;
    dino_game.init(HAL_GetTick());dino_game.enter(HAL_GetTick());
    last_poll=HAL_GetTick()-1;frame=NULL;pending=false;oled_begin(HAL_GetTick());
}
void board_poll(void) {
    uint32_t now=HAL_GetTick();board_loops++;
    if(now!=last_poll) {
        last_poll=now;board_raw_keys=(uint8_t)((~GPIOB->IDR>>10)&31U);
        uint8_t pressed=buttons_update(&buttons,(uint8_t)board_raw_keys,now),held=buttons.stable;
        if(dino_game_state.gate)held|=(uint8_t)board_raw_keys;
        if(dino_game.update(pressed,held,now)==GAME_EXIT)dino_game.enter(now);
        const uint8_t *changed=dino_game.draw();
        if(changed){frame=changed;pending=true;}
    }
    bool was_online=oled_online;oled_service(now);
    if(!was_online && oled_online)pending=true;
    dino_game.service(now,!oled_busy());
    if(pending && frame && oled_submit(frame,now))pending=false;
}
