#ifndef BOARD_H
#define BOARD_H
#include <stdint.h>
extern volatile uint32_t board_loops,board_raw_keys;
void board_begin(void);
void board_poll(void);
#endif
