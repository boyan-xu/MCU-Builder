#include "board.h"
#include "main.h"
#include "oled.h"
#include "highscore.h"
App game;
uint8_t board_frame[SCREEN_BYTES];
volatile uint32_t board_loops;
volatile uint8_t board_raw_keys;
static Buttons buttons;
static uint32_t last_poll;
void board_begin(void) {
    HAL_Delay(100);
    buttons_init(&buttons); app_init(&game, HAL_GetTick());
    game.best = highscore_load();
    /* Seed held boot keys as stable; clearing their gate now requires a debounced release. */
    board_raw_keys = (uint8_t)((~GPIOB->IDR >> 10) & 31U);
    buttons.raw = buttons.stable = board_raw_keys;
    last_poll = HAL_GetTick() - 1;
    oled_begin(HAL_GetTick());
}
void board_poll(void) {
    uint32_t now = HAL_GetTick(); board_loops++;
    bool was_online = oled_online;
    oled_service(now);
    if (!was_online && oled_online) game.dirty = true;
    if (now != last_poll) {
        last_poll = now;
        board_raw_keys = (uint8_t)((~GPIOB->IDR >> 10) & 31U);
        uint8_t pressed = buttons_update(&buttons, board_raw_keys, now);
        /* A page-held key needs a full debounced release, even before its first stable press. */
        uint8_t held = buttons.stable;
        for (unsigned i = 0; i < 5; i++) {
            uint8_t bit = 1U << i;
            if ((game.gate & bit) && ((board_raw_keys & bit) || (uint32_t)(now - buttons.changed[i]) < 20)) held |= bit;
        }
        app_input(&game, pressed, held, now); app_tick(&game, now);
    }
    if (!oled_busy() && game.save_requested) {
        game.save_requested = false;
        game.save_failed = !highscore_save(game.best);
        game.dirty = true;
    }
    if (oled_online && !oled_busy() && game.dirty) {
        screen_render(&game, board_frame);
        if (oled_submit(board_frame, now)) game.dirty = false;
    }
}
