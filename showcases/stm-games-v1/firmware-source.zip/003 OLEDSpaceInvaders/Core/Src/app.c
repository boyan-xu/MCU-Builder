#include "app.h"
#include <string.h>
static void page(App *a, AppState state, uint32_t now) {
    a->state = state; a->selection = 0; a->held = 0; a->gate = 31;
    a->last_tick = now; a->dirty = true;
}
static void remember(App *a) {
    if (a->game.score > a->best) a->best = a->game.score;
}
static void request_save(App *a) { remember(a); a->save_requested = true; }
static void start(App *a, uint32_t now) {
    if (a->state != APP_TITLE) request_save(a);
    invaders_init(&a->game, now); page(a, APP_PLAY, now);
}
void app_init(App *a, uint32_t now) {
    memset(a, 0, sizeof(*a)); page(a, APP_TITLE, now);
}
void app_input(App *a, uint8_t pressed, uint8_t held, uint32_t now) {
    held &= 31U; a->gate &= held; pressed &= (uint8_t)~a->gate;
    a->held = held & (uint8_t)~a->gate;
    if (a->state == APP_PLAY) {
        if (pressed & KEY_OK) page(a, APP_PAUSE, now);
        return;
    }
    uint8_t rows = a->state == APP_PAUSE ? 4 : 2;
    if (pressed & KEY_UP) a->selection = a->selection ? a->selection - 1 : rows - 1;
    if (pressed & KEY_DOWN) a->selection = (a->selection + 1) % rows;
    bool fire_row = a->state != APP_OVER && a->selection == 1;
    if (fire_row && (pressed & (KEY_LEFT | KEY_RIGHT | KEY_OK))) a->automatic = !a->automatic;
    else if (pressed & KEY_OK) {
        if (a->state == APP_TITLE || (a->state == APP_OVER && !a->selection) ||
            (a->state == APP_PAUSE && a->selection == 2)) start(a, now);
        else if (a->state == APP_PAUSE && !a->selection) page(a, APP_PLAY, now);
        else { request_save(a); page(a, APP_TITLE, now); }
    }
    if (pressed) a->dirty = true;
}
void app_tick(App *a, uint32_t now) {
    if (a->state != APP_PLAY || (uint32_t)(now - a->last_tick) < STEP_MS) return;
    /* Run one step, never burst old steps after pause or a slow display retry. */
    a->last_tick = now;
    invaders_step(&a->game, (a->held & KEY_LEFT) != 0, (a->held & KEY_RIGHT) != 0,
                  a->automatic || (a->held & KEY_UP) != 0);
    remember(a);
    a->dirty = true;
    if (a->game.over) { request_save(a); page(a, APP_OVER, now); }
}
