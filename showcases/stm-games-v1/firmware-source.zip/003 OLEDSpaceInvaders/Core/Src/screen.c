#include "screen.h"
#include "font5x7.h"
#include <string.h>
static const uint8_t aliens[3][8] = {
    {0x0E,0x13,0x1E,0x0B,0x0B,0x1E,0x13,0x0E},
    {0x16,0x0D,0x1F,0x16,0x16,0x1F,0x0D,0x16},
    {0x0C,0x1E,0x0B,0x1F,0x1F,0x0B,0x1E,0x0C}
};
static const uint8_t ship[11] = {0x30,0x38,0x38,0x38,0x3E,0x3F,0x3E,0x38,0x38,0x38,0x30};
static void point(uint8_t *f, int x, int y) {
    if (x >= 0 && x < 128 && y >= 0 && y < 64) f[(y / 8) * 128 + x] |= 1U << (y % 8);
}
static void sprite(uint8_t *f, int x, int y, const uint8_t *bits, unsigned width, unsigned height) {
    for (unsigned col = 0; col < width; col++) for (unsigned row = 0; row < height; row++)
        if (bits[col] & (1U << row)) point(f, x + col, y + row);
}
static void text(uint8_t *f, unsigned x, unsigned page, const char *s) {
    if (page >= 8) return;
    for (; *s && x <= 122; s++, x += 6) {
        unsigned char c = *s;
        if (c < 32 || c > 126) c = '?';
        for (unsigned col = 0; col < 5; col++) f[page * 128 + x + col] = oled_font[c - 32][col];
    }
}
static void number(uint8_t *f, unsigned x, unsigned page, uint32_t value) {
    char digits[11]; unsigned n = 10; digits[n] = 0;
    do { digits[--n] = '0' + value % 10; value /= 10; } while (value);
    text(f, x, page, digits + n);
}
static void row(uint8_t *f, unsigned page, bool selected, const char *label) {
    text(f, 16, page, selected ? ">" : " "); text(f, 28, page, label);
}
void screen_render(const App *a, uint8_t frame[SCREEN_BYTES]) {
    memset(frame, 0, SCREEN_BYTES);
    const Invaders *g = &a->game;
    if (a->state == APP_PLAY) {
        text(frame, 0, 0, "S:"); number(frame, 12, 0, g->score);
        text(frame, 54, 0, "L:"); number(frame, 66, 0, g->lives);
        text(frame, 78, 0, "A:"); number(frame, 90, 0, g->ammo);
        for (unsigned i = 0; i < 24; i++) if (g->alive & (1UL << i))
            sprite(frame, g->alien_x + (i % 8) * 12, g->alien_y + (i / 8) * 8, aliens[i / 8], 8, 5);
        for (unsigned i = 0; i < 3; i++) sprite(frame, 16 + i * 40, SHIELD_Y, g->shields[i], 16, 8);
        if (!g->invulnerable_ms || (g->invulnerable_ms / 100) % 2 == 0) sprite(frame, g->ship_x, SHIP_Y, ship, 11, 6);
        if (g->player.y >= 0) { point(frame, g->player.x, g->player.y); point(frame, g->player.x, g->player.y + 1); }
        for (unsigned i = 0; i < 3; i++) if (g->enemy[i].y >= 0) {
            point(frame, g->enemy[i].x, g->enemy[i].y); point(frame, g->enemy[i].x, g->enemy[i].y - 1);
        }
    } else if (a->state == APP_TITLE) {
        text(frame, 22, 0, "SPACE INVADERS");
        for (unsigned i = 0; i < 3; i++) sprite(frame, 42 + i * 20, 14, aliens[i], 8, 5);
        row(frame, 3, a->selection == 0, "START");
        row(frame, 4, a->selection == 1, a->automatic ? "FIRE: AUTO" : "FIRE: MANUAL");
        text(frame, 28, 6, "BEST:"); number(frame, 58, 6, a->best);
        text(frame, 28, 7, "ARROWS + OK");
    } else if (a->state == APP_PAUSE) {
        text(frame, 46, 0, "PAUSED");
        text(frame, 0, 1, "B:"); number(frame, 12, 1, a->best);
        text(frame, 78, 1, "W:"); number(frame, 90, 1, g->wave);
        row(frame, 2, a->selection == 0, "RESUME");
        row(frame, 3, a->selection == 1, a->automatic ? "FIRE: AUTO" : "FIRE: MANUAL");
        row(frame, 4, a->selection == 2, "RESTART"); row(frame, 5, a->selection == 3, "TITLE");
        text(frame, 28, 6, "AMMO:"); number(frame, 58, 6, g->ammo);
        text(frame, 22, 7, "L/R CHANGE FIRE");
    } else {
        text(frame, g->end_reason == END_AMMO ? 31 : 37, 0, g->end_reason == END_AMMO ? "OUT OF AMMO" : "GAME OVER");
        text(frame, 28, 2, "SCORE:"); number(frame, 64, 2, g->score);
        text(frame, 28, 3, "BEST:"); number(frame, 64, 3, a->best);
        row(frame, 4, a->selection == 0, "RESTART"); row(frame, 5, a->selection == 1, "TITLE");
    }
    if (a->state != APP_PLAY && a->save_failed) {
        memset(frame + 7 * 128, 0, 128);
        text(frame, 28, 7, "SAVE FAILED");
    }
}
