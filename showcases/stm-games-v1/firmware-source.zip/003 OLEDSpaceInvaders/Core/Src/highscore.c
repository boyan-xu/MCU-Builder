#include "highscore.h"
#include "main.h"
typedef struct { uint32_t score, inverse, commit; } Record;
_Static_assert(sizeof(Record) == 12, "Flash record size");
static const volatile Record *record_at(uint32_t address) { return (const volatile Record *)address; }
static bool valid(const volatile Record *r) {
    return r->commit == HIGHSCORE_COMMIT && r->score <= 999990 && r->inverse == ~r->score;
}
static uint32_t find_best(uint32_t *page) {
    uint32_t best = 0;
    if (page) *page = HIGHSCORE_BASE;
    for (unsigned p = 0; p < 2; p++) for (unsigned i = 0; i < HIGHSCORE_PAGE / sizeof(Record); i++) {
        const volatile Record *r = record_at(HIGHSCORE_BASE + p * HIGHSCORE_PAGE + i * sizeof(Record));
        if (valid(r) && r->score > best) {
            best = r->score;
            if (page) *page = HIGHSCORE_BASE + p * HIGHSCORE_PAGE;
        }
    }
    return best;
}
uint32_t highscore_load(void) { return find_best(0); }
bool highscore_save(uint32_t score) {
    if (score > 999990) return false;
    uint32_t page;
    uint32_t best = find_best(&page);
    if (score <= best) return true;
    uint32_t address = 0;
    for (unsigned i = 0; i < HIGHSCORE_PAGE / sizeof(Record); i++) {
        uint32_t candidate = page + i * sizeof(Record);
        const volatile Record *r = record_at(candidate);
        if (r->score == UINT32_MAX && r->inverse == UINT32_MAX && r->commit == UINT32_MAX) {
            address = candidate; break;
        }
    }
    if (HAL_FLASH_Unlock() != HAL_OK) { HAL_FLASH_Lock(); return false; }
    bool okay = true;
    if (!address) {
        /* Erase the other page while the highest valid record remains untouched. */
        if (best) page = page == HIGHSCORE_BASE ? HIGHSCORE_BASE + HIGHSCORE_PAGE : HIGHSCORE_BASE;
        FLASH_EraseInitTypeDef erase = {0};
        erase.TypeErase = FLASH_TYPEERASE_PAGES; erase.PageAddress = page; erase.NbPages = 1;
        uint32_t error;
        okay = HAL_FLASHEx_Erase(&erase, &error) == HAL_OK;
        address = page;
    }
    const uint32_t words[3] = {score, ~score, HIGHSCORE_COMMIT};
    for (unsigned i = 0; i < 6 && okay; i++) {
        uint16_t halfword = (uint16_t)(words[i / 2] >> ((i % 2) * 16));
        okay = HAL_FLASH_Program(FLASH_TYPEPROGRAM_HALFWORD, address + i * 2, halfword) == HAL_OK;
    }
    if (okay) okay = valid(record_at(address)) && record_at(address)->score == score;
    HAL_StatusTypeDef locked = HAL_FLASH_Lock();
    return okay && locked == HAL_OK;
}
