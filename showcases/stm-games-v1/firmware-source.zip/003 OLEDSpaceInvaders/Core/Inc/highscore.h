#ifndef HIGHSCORE_H
#define HIGHSCORE_H
#include <stdbool.h>
#include <stdint.h>
#define HIGHSCORE_BASE 0x0800F800UL
#define HIGHSCORE_PAGE 1024U
#define HIGHSCORE_COMMIT 0x51A5C0DEUL
uint32_t highscore_load(void);
bool highscore_save(uint32_t score);
#endif
