#ifndef SCREEN_H
#define SCREEN_H
#include "app.h"
#define SCREEN_BYTES 1024
void screen_render(const App *a, uint8_t frame[SCREEN_BYTES]);
#endif
