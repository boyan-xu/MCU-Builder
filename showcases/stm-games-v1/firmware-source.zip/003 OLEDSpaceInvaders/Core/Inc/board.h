#ifndef BOARD_H
#define BOARD_H
#include "app.h"
#include "screen.h"
extern App game;
extern uint8_t board_frame[SCREEN_BYTES];
extern volatile uint32_t board_loops;
extern volatile uint8_t board_raw_keys;
void board_begin(void);
void board_poll(void);
#endif
