#ifndef APP_H
#define APP_H
#include "invaders.h"
#include "buttons.h"
typedef enum { APP_TITLE, APP_PLAY, APP_PAUSE, APP_OVER } AppState;
typedef struct {
    Invaders game;
    uint32_t last_tick;
    uint32_t best;
    AppState state;
    uint8_t selection, held, gate;
    bool automatic, dirty;
    bool save_requested, save_failed;
} App;
void app_init(App *a, uint32_t now);
void app_input(App *a, uint8_t pressed, uint8_t held, uint32_t now);
void app_tick(App *a, uint32_t now);
#endif
